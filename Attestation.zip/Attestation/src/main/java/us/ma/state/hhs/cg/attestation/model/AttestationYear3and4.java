package us.ma.state.hhs.cg.attestation.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
		name = "attyear3and4_2021"
	)
public class AttestationYear3and4 {

	@Id
	@Column(name = "ACCESS_CODE")
	private long accessCode;
		
	/* SECTION - A */
	@Column(name = "SECA_ORGNAME")
	private String orgname;
	
	@Column(name = "SECA_STREET_ADDR")
	private String staddr;
	
	@Column(name = "SECA_CITY")
	private String city;
	
	@Column(name = "SECA_STATE")
	private String state;
	
	@Column(name = "SECA_ZIPCODE")
	private String zipcode;
	
	@Column(name = "SECA_TAXID")
	private String taxid;
	
	@Column(name = "SECA_ORGNPI")
	private String orgnpi;
	
	@Column(name = "SECA_PRACTICE_TYPE")
	private String practicetype;
	
	@Column(name = "SECA_ORGDOMAIN")
	private String orgdomain;
	
    @Column(name = "SECA_PARENTCOMPANY")
	private String parentcompany;
	
	@Column(name = "SECA_SUBORG")
	private String suborg;

	/* SECTION - B */
	
	@Column(name = "SECB_UC_GOAL")
	private String goalusecase;	
	
	@Column(name = "SECB_OTHER_GOAL_UC")
	private String otherusecase;
	
	@Column(name = "SECB_GOAL_EXPAND")
	private String expandgoalusecase;
	
	/* Documentation of the sending usecase */
	
	@Column(name = "SECB_NAME")
	private String nameusecase;
	
	@Column(name = "SECB_UC_DATE")
	private String dateusecase;
	
	@Column(name = "SECB_UC_CATEGORY")
	private String category1usecase;
	
	@Column(name = "SECB_INFOTYPE")
	private String infotype;
	
	@Column(name = "SECB_OTHER_INFOTYPE")
	private String otherinfotype;
	
	@Column(name = "SECB_INFOFORMAT")
	private String infoformat;
	
	@Column(name = "SECB_HL7_INFO_FORMAT")
	private String hl7infoformat;
	
	@Column(name = "SECB_OTHER_INFO_FORMAT")
	private String otherinfoformat;
	
	@Column(name = "SECB_ENTITY")
	private String entityusecase;
	
	@Column(name = "SECB_OTHER_ORG_DOMAIN")
	private String otherorgdomain;
	
	@Column(name = "SECB_SENDER")
	private String cat2ucsender;
	

	@Column(name = "SECB_ENTITY_CATEGORY")
	private String category2usecase;
	
	@Column(name = "SECB_OTHER_CAT2")
	private String othercategory2;
	
	/* Documentation of the receiving usecase */
	
	@Column(name = "SECB_NAME_REC")
	private String nameusecasereceiver;
	
	@Column(name = "SECB_UC_DATE__REC")
	private String dateusecasereceiver;
	
	@Column(name = "SECB_UC_CATEGORY_REC")
	private String category1usecasereceiver;
	
	@Column(name = "SECB_INFOTYPE_REC")
	private String infotypereceiver;
	
	@Column(name = "SECB_OTHER_INFOTYPE_REC")
	private String otherinfotypereceiver;
	
	@Column(name = "SECB_INFOFORMAT_REC")
	private String infoformatreceiver;
	
	@Column(name = "SECB_HL7_INFO_FORMAT_REC")
	private String hl7infoformatreceiver;
	
	@Column(name = "SECB_OTHER_INFO_FORMAT_REC")
	private String otherinfoformatreceiver;
	
	@Column(name = "SECB_ENTITY_REC")
	private String entityusecasereceiver;
	
	@Column(name = "SECB_OTHER_ORG_DOMAIN_REC")
	private String otherorgdomainreceiver;
	
	
	@Column(name = "SECB_REC")
	private String cat2ucreceiver;
	

	@Column(name = "SECB_ENTITY_CATEGORY_REC")
	private String category2usecasereceiver;
	
	@Column(name = "SECB_OTHER_CAT2_REC")
	private String othercategory2receiver;
	
	/* usecase  Transmission methods */
	
	@Column(name = "SECB_PERCENTAGE")
	private String msgpercentage;
	
	@Column(name = "SECB_OTHERMETHOD")
	private String othermethod;
	
	@Column(name = "SECB_LISTMETHOD")
	private String listothermethod;
	
	//gone
	
	
	@Column(name = "SECB_TRANSACTION")
	private String transac_no;
	
	@Column(name = "SECB_FREE_ASSISTANCE")
	private String freeassistance;
	
	/* SECTION - C  EMR/ EHR Systems*/
	
	
	@Column(name = "SECC_ISEMREHRSYSTEM")
	private String ehremrsystem;
	
	@Column(name = "SECC_NAMEEMR")
	private String nameemr;
	
	@Column(name = "SECC_VERSIONEMR")
	private String versionemr;
	
	@Column(name = "SECC_CONNECTINGEMR")
	private String connectingemr;
	
	@Column(name = "SECC_EHR_EMR_RECEIVING")
	private String receivingusecase;
	
	@Column(name = "SECC_CONCCERTIFIED")
	private String onccertified;
	
	@Column(name = "SECC_CONNECTINGPROVIDER")
	private String connectingprovider;
	
	@Column(name = "SECC_OTHER_CONN_PROVIDER")
	private String otherconnprovider;
	
//	/* SECTION - D */
//	@Column(name = "SECD_ISEMREHRSYSTEM")
//	private String adtfeeds;
//	
//	@Column(name = "SECCD_ENSINTIATIVE")
//	private String ensinitiative;
//	
//	@Column(name = "SECD_INFOONADTFEEDS")
//	private String  infoonadtfeeds;
//	
//	@Column(name = "SECD_DATEOFSUBMISSION")
//	private String dateofsubmission;
		
	
	/* SECTION - D */
	@Column(name = "SECD_AA_NAME")
	private String aaname;
	
	@Column(name = "SECD_AA_TITLE")
	private String aatitle;
	
	@Column(name = "SECD_AA_EMAIL")
	private String aaemail;
	
	@Column(name = "SECD_AA_PHONE")
	private String aaphone;
	
	@Column(name = "SECD_TC_NAME")
	private String tcname;
	
	@Column(name = "SECD_TC_TITLE")
	private String tctitle;
	
	@Column(name = "SECD_TC_EMAIL")
	private String tcemail;
	
	@Column(name = "SECD_TC_PHONE")
	private String tcphone;
	
	@Column(name = "SECD_TC_SPECIFY")
	private String tcrole;
	
	@Column(name = "SECD_BC_NAME")
	private String bcname;
	
	@Column(name = "SECD_BC_TITLE")
	private String bctitle;
	
	@Column(name = "SECD_BC_EMAIL")
	private String bcemail;
	
	@Column(name = "SECD_BC_PHONE")
	private String bcphone;
	
	@Column(name = "SECD_BC_SPECIFY")
	private String bcrole;
	
	@Column(name = "SECD_OC_NAME")
	private String ocname;
	
	@Column(name = "SECD_OC_TITLE")
	private String octitle;
	
	@Column(name = "SECD_OC_EMAIL")
	private String ocemail;
	
	@Column(name = "SECD_OC_PHONE")
	private String ocphone;
	
	/* SECTION - E */
	@Column(name = "SECE_SIG_NAME")
	private String signame;
	
	@Column(name = "SECE_SIG_TITLE")
	private String sigtitle;
	
	@Column(name = "SECE_SIG_DATE")
	private Date sigdt;
	
	@Column(name = "SECE_SIG_PHONE")
	private String sigphone;
	
	@Column(name = "SECE_SIG_EMAIL")
	private String sigemail;
	
	@Column(name = "SECE_SIG_EXT")
	private String sigext;
	
	@Column(name = "SECE_SUGGESTIONS")
	private String sigsuggestion;
	
	@Column(name = "SUBMITION_FLAG")
	private String submitionflag;
	
	//11
	//@Column(name = "SECB_SEND_RECEIVE")
	//private String send_receiveusecase;
	
	

	
	public AttestationYear3and4() {
		super();
	}
	
	

	public AttestationYear3and4(long accessCode, String orgname, String staddr, String city, String state, String zipcode,
			String taxid, String orgnpi, String practicetype, String orgdomain, String parentcompany, String suborg,
			String goalusecase, String otherusecase, String expandgoalusecase, String nameusecase, String dateusecase,
			String category1usecase, String infotype, String otherinfotype, String infoformat, String hl7infoformat,
			String otherinfoformat, String entityusecase, String otherorgdomain, String cat2ucsender,
			String category2usecase, String othercategory2, String nameusecasereceiver, String dateusecasereceiver,
			String category1usecasereceiver, String infotypereceiver, String otherinfotypereceiver,
			String infoformatreceiver, String hl7infoformatreceiver, String otherinfoformatreceiver,
			String entityusecasereceiver, String otherorgdomainreceiver, String cat2ucreceiver,
			String category2usecasereceiver, String othercategory2receiver, String msgpercentage,
			String othermethod, String listothermethod, String transac_no,
			String freeassistance, String ehremrsystem, String nameemr, String versionemr, String connectingemr,
			String receivingusecase, String onccertified, String connectingprovider, String otherconnprovider,
			String adtfeeds, String ensinitiative, String infoonadtfeeds, String dateofsubmission, String aaname,
			String aatitle, String aaemail, String aaphone, String tcname, String tctitle, String tcemail,
			String tcphone, String tcrole, String bcname, String bctitle, String bcemail, String bcphone, String bcrole,
			String ocname, String octitle, String ocemail, String ocphone, String signame, String sigtitle, Date sigdt,
			String sigphone, String sigemail, String sigext, String sigsuggestion, String submitionflag) {
		super();
		this.accessCode = accessCode;
		this.orgname = orgname;
		this.staddr = staddr;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.taxid = taxid;
		this.orgnpi = orgnpi;
		this.practicetype = practicetype;
		this.orgdomain = orgdomain;
		this.parentcompany = parentcompany;
		this.suborg = suborg;
		this.goalusecase = goalusecase;
		this.otherusecase = otherusecase;
		this.expandgoalusecase = expandgoalusecase;
		this.nameusecase = nameusecase;
		this.dateusecase = dateusecase;
		this.category1usecase = category1usecase;
		this.infotype = infotype;
		this.otherinfotype = otherinfotype;
		this.infoformat = infoformat;
		this.hl7infoformat = hl7infoformat;
		this.otherinfoformat = otherinfoformat;
		this.entityusecase = entityusecase;
		this.otherorgdomain = otherorgdomain;
		this.cat2ucsender = cat2ucsender;
		this.category2usecase = category2usecase;
		this.othercategory2 = othercategory2;
		this.nameusecasereceiver = nameusecasereceiver;
		this.dateusecasereceiver = dateusecasereceiver;
		this.category1usecasereceiver = category1usecasereceiver;
		this.infotypereceiver = infotypereceiver;
		this.otherinfotypereceiver = otherinfotypereceiver;
		this.infoformatreceiver = infoformatreceiver;
		this.hl7infoformatreceiver = hl7infoformatreceiver;
		this.otherinfoformatreceiver = otherinfoformatreceiver;
		this.entityusecasereceiver = entityusecasereceiver;
		this.otherorgdomainreceiver = otherorgdomainreceiver;
		this.cat2ucreceiver = cat2ucreceiver;
		this.category2usecasereceiver = category2usecasereceiver;
		this.othercategory2receiver = othercategory2receiver;
		this.msgpercentage = msgpercentage;
		//this.solelyhiway = solelyhiway;
		this.othermethod = othermethod;
		this.listothermethod = listothermethod;
		//this.informationusecase = informationusecase;
		this.transac_no = transac_no;
		this.freeassistance = freeassistance;
		this.ehremrsystem = ehremrsystem;
		this.nameemr = nameemr;
		this.versionemr = versionemr;
		this.connectingemr = connectingemr;
		this.receivingusecase = receivingusecase;
		this.onccertified = onccertified;
		this.connectingprovider = connectingprovider;
		this.otherconnprovider = otherconnprovider;
//		this.adtfeeds = adtfeeds;
//		this.ensinitiative = ensinitiative;
//		this.infoonadtfeeds = infoonadtfeeds;
//		this.dateofsubmission = dateofsubmission;
		this.aaname = aaname;
		this.aatitle = aatitle;
		this.aaemail = aaemail;
		this.aaphone = aaphone;
		this.tcname = tcname;
		this.tctitle = tctitle;
		this.tcemail = tcemail;
		this.tcphone = tcphone;
		this.tcrole = tcrole;
		this.bcname = bcname;
		this.bctitle = bctitle;
		this.bcemail = bcemail;
		this.bcphone = bcphone;
		this.bcrole = bcrole;
		this.ocname = ocname;
		this.octitle = octitle;
		this.ocemail = ocemail;
		this.ocphone = ocphone;
		this.signame = signame;
		this.sigtitle = sigtitle;
		this.sigdt = sigdt;
		this.sigphone = sigphone;
		this.sigemail = sigemail;
		this.sigext = sigext;
		this.sigsuggestion = sigsuggestion;
		this.submitionflag = submitionflag;
	}



	public long getAccessCode() {
		return accessCode;
	}

	public void setAccessCode(long accessCode) {
		this.accessCode = accessCode;
	}

	public String getOrgname() {
		return orgname;
	}

	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}

	public String getStaddr() {
		return staddr;
	}

	public void setStaddr(String staddr) {
		this.staddr = staddr;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getTaxid() {
		return taxid;
	}

	public void setTaxid(String taxid) {
		this.taxid = taxid;
	}

	public String getOrgnpi() {
		return orgnpi;
	}

	public void setOrgnpi(String orgnpi) {
		this.orgnpi = orgnpi;
	}

	public String getPracticetype() {
		return practicetype;
	}

	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}

	public String getOrgdomain() {
		return orgdomain;
	}

	public void setOrgdomain(String orgdomain) {
		this.orgdomain = orgdomain;
	}

	public String getParentcompany() {
		return parentcompany;
	}

	public void setParentcompany(String parentcompany) {
		this.parentcompany = parentcompany;
	}

	public String getSuborg() {
		return suborg;
	}

	public void setSuborg(String suborg) {
		suborg = suborg.replaceAll("\t", " ");
		suborg = suborg.replaceAll("”", "\"");
		suborg = suborg.replaceAll("’", "'");
	    suborg = suborg.replaceAll("[^\\x00-\\x7F]", " ");
		this.suborg = suborg;
	}

	public String getGoalusecase() {
		return goalusecase;
	}

	public void setGoalusecase(String goalusecase) {
		this.goalusecase = goalusecase;
	}

	public String getOtherusecase() {
		return otherusecase;
	}

	public void setOtherusecase(String otherusecase) {
		this.otherusecase = otherusecase;
	}

	public String getExpandgoalusecase() {
		return expandgoalusecase;
	}

	public void setExpandgoalusecase(String expandgoalusecase) {
		expandgoalusecase = expandgoalusecase.replaceAll("\t", " ");
		expandgoalusecase = expandgoalusecase.replaceAll("”", "\"");
		expandgoalusecase = expandgoalusecase.replaceAll("’", "'");
		expandgoalusecase = expandgoalusecase.replaceAll("[^\\x00-\\x7F]", " ");
		this.expandgoalusecase = expandgoalusecase;
	}

	public String getNameusecase() {
		return nameusecase;
	}

	public void setNameusecase(String nameusecase) {
		this.nameusecase = nameusecase;
	}

	public String getDateusecase() {
		return dateusecase;
	}

	public void setDateusecase(String dateusecase) {
		this.dateusecase = dateusecase;
	}

	public String getCategory1usecase() {
		return category1usecase;
	}

	public void setCategory1usecase(String category1usecase) {
		this.category1usecase = category1usecase;
	}

	public String getInfotype() {
		return infotype;
	}

	public void setInfotype(String infotype) {
		this.infotype = infotype;
	}

	public String getOtherinfotype() {
		return otherinfotype;
	}

	public void setOtherinfotype(String otherinfotype) {
		this.otherinfotype = otherinfotype;
	}

	public String getInfoformat() {
		return infoformat;
	}

	public void setInfoformat(String infoformat) {
		this.infoformat = infoformat;
	}

	public String getHl7infoformat() {
		return hl7infoformat;
	}

	public void setHl7infoformat(String hl7infoformat) {
		this.hl7infoformat = hl7infoformat;
	}

	public String getOtherinfoformat() {
		return otherinfoformat;
	}

	public void setOtherinfoformat(String otherinfoformat) {
		this.otherinfoformat = otherinfoformat;
	}

	public String getEntityusecase() {
		return entityusecase;
	}

	public void setEntityusecase(String entityusecase) {
		entityusecase = entityusecase.replaceAll("\t", " ");
		entityusecase = entityusecase.replaceAll("”", "\"");
		entityusecase = entityusecase.replaceAll("’", "'");
		entityusecase = entityusecase.replaceAll("[^\\x00-\\x7F]", " ");
		this.entityusecase = entityusecase;
	}

	public String getOtherorgdomain() {
		return otherorgdomain;
	}

	public void setOtherorgdomain(String otherorgdomain) {
		otherorgdomain = otherorgdomain.replaceAll("\t", " ");
		otherorgdomain = otherorgdomain.replaceAll("”", "\"");
		otherorgdomain = otherorgdomain.replaceAll("’", "'");
		otherorgdomain = otherorgdomain.replaceAll("[^\\x00-\\x7F]", " ");
		this.otherorgdomain = otherorgdomain;
	}

	public String getCat2ucsender() {
		return cat2ucsender;
	}

	public void setCat2ucsender(String cat2ucsender) {
		this.cat2ucsender = cat2ucsender;
	}

	public String getCategory2usecase() {
		return category2usecase;
	}

	public void setCategory2usecase(String category2usecase) {
		this.category2usecase = category2usecase;
	}

	public String getOthercategory2() {
		return othercategory2;
	}

	public void setOthercategory2(String othercategory2) {
		this.othercategory2 = othercategory2;
	}

	public String getNameusecasereceiver() {
		return nameusecasereceiver;
	}

	public void setNameusecasereceiver(String nameusecasereceiver) {
		this.nameusecasereceiver = nameusecasereceiver;
	}

	public String getDateusecasereceiver() {
		return dateusecasereceiver;
	}

	public void setDateusecasereceiver(String dateusecasereceiver) {
		this.dateusecasereceiver = dateusecasereceiver;
	}

	public String getCategory1usecasereceiver() {
		return category1usecasereceiver;
	}

	public void setCategory1usecasereceiver(String category1usecasereceiver) {
		this.category1usecasereceiver = category1usecasereceiver;
	}

	public String getInfotypereceiver() {
		return infotypereceiver;
	}

	public void setInfotypereceiver(String infotypereceiver) {
		this.infotypereceiver = infotypereceiver;
	}

	public String getOtherinfotypereceiver() {
		return otherinfotypereceiver;
	}

	public void setOtherinfotypereceiver(String otherinfotypereceiver) {
		this.otherinfotypereceiver = otherinfotypereceiver;
	}

	public String getInfoformatreceiver() {
		return infoformatreceiver;
	}

	public void setInfoformatreceiver(String infoformatreceiver) {
		this.infoformatreceiver = infoformatreceiver;
	}

	public String getHl7infoformatreceiver() {
		return hl7infoformatreceiver;
	}

	public void setHl7infoformatreceiver(String hl7infoformatreceiver) {
		this.hl7infoformatreceiver = hl7infoformatreceiver;
	}

	public String getOtherinfoformatreceiver() {
		return otherinfoformatreceiver;
	}

	public void setOtherinfoformatreceiver(String otherinfoformatreceiver) {
		this.otherinfoformatreceiver = otherinfoformatreceiver;
	}

	public String getEntityusecasereceiver() {
		return entityusecasereceiver;
	}

	public void setEntityusecasereceiver(String entityusecasereceiver) {
		entityusecasereceiver = entityusecasereceiver.replaceAll("\t", " ");
		entityusecasereceiver = entityusecasereceiver.replaceAll("”", "\"");
		entityusecasereceiver = entityusecasereceiver.replaceAll("’", "'");
		entityusecasereceiver = entityusecasereceiver.replaceAll("[^\\x00-\\x7F]", " ");
		this.entityusecasereceiver = entityusecasereceiver;
	}

	public String getOtherorgdomainreceiver() {
		return otherorgdomainreceiver;
	}

	public void setOtherorgdomainreceiver(String otherorgdomainreceiver) {
		otherorgdomainreceiver = otherorgdomainreceiver.replaceAll("\t", " ");
		otherorgdomainreceiver = otherorgdomainreceiver.replaceAll("”", "\"");
		otherorgdomainreceiver = otherorgdomainreceiver.replaceAll("’", "'");
		otherorgdomainreceiver = otherorgdomainreceiver.replaceAll("[^\\x00-\\x7F]", " ");
		this.otherorgdomainreceiver = otherorgdomainreceiver;
	}

	public String getCat2ucreceiver() {
		return cat2ucreceiver;
	}

	public void setCat2ucreceiver(String cat2ucreceiver) {
		this.cat2ucreceiver = cat2ucreceiver;
	}

	public String getCategory2usecasereceiver() {
		return category2usecasereceiver;
	}

	public void setCategory2usecasereceiver(String category2usecasereceiver) {
		this.category2usecasereceiver = category2usecasereceiver;
	}

	public String getOthercategory2receiver() {
		return othercategory2receiver;
	}

	public void setOthercategory2receiver(String othercategory2receiver) {
		this.othercategory2receiver = othercategory2receiver;
	}

	public String getMsgpercentage() {
		return msgpercentage;
	}

	public void setMsgpercentage(String msgpercentage) {
		this.msgpercentage = msgpercentage;
	}

	public String getOthermethod() {
		return othermethod;
	}

	public void setOthermethod(String othermethod) {
		this.othermethod = othermethod;
	}

	public String getListothermethod() {
		return listothermethod;
	}

	public void setListothermethod(String listothermethod) {
		this.listothermethod = listothermethod;
	}


	public String getTransac_no() {
		return transac_no;
	}

	public void setTransac_no(String transac_no) {
		this.transac_no = transac_no;
	}

	public String getFreeassistance() {
		return freeassistance;
	}

	public void setFreeassistance(String freeassistance) {
		this.freeassistance = freeassistance;
	}

	public String getEhremrsystem() {
		return ehremrsystem;
	}

	public void setEhremrsystem(String ehremrsystem) {
		this.ehremrsystem = ehremrsystem;
	}

	public String getNameemr() {
		return nameemr;
	}

	public void setNameemr(String nameemr) {
		this.nameemr = nameemr;
	}

	public String getVersionemr() {
		return versionemr;
	}

	public void setVersionemr(String versionemr) {
		this.versionemr = versionemr;
	}

	public String getConnectingemr() {
		return connectingemr;
	}

	public void setConnectingemr(String connectingemr) {
		this.connectingemr = connectingemr;
	}

	public String getReceivingusecase() {
		return receivingusecase;
	}

	public void setReceivingusecase(String receivingusecase) {
		this.receivingusecase = receivingusecase;
	}

	public String getOnccertified() {
		return onccertified;
	}

	public void setOnccertified(String onccertified) {
		this.onccertified = onccertified;
	}

	public String getConnectingprovider() {
		return connectingprovider;
	}

	public void setConnectingprovider(String connectingprovider) {
		this.connectingprovider = connectingprovider;
	}

	public String getOtherconnprovider() {
		return otherconnprovider;
	}

	public void setOtherconnprovider(String otherconnprovider) {
		this.otherconnprovider = otherconnprovider;
	}

//	public String getAdtfeeds() {
//		return adtfeeds;
//	}
//
//	public void setAdtfeeds(String adtfeeds) {
//		this.adtfeeds = adtfeeds;
//	}
//
//	public String getEnsinitiative() {
//		return ensinitiative;
//	}
//
//	public void setEnsinitiative(String ensinitiative) {
//		ensinitiative = ensinitiative.replaceAll("\t", " ");
//		ensinitiative = ensinitiative.replaceAll("”", "\"");
//		ensinitiative = ensinitiative.replaceAll("’", "'");
//		ensinitiative = ensinitiative.replaceAll("[^\\x00-\\x7F]", " ");
//		this.ensinitiative = ensinitiative;
//	}

//	public String getInfoonadtfeeds() {
//		return infoonadtfeeds;
//	}
//
//	public void setInfoonadtfeeds(String infoonadtfeeds) {
//		this.infoonadtfeeds = infoonadtfeeds;
//	}
//
//	public String getDateofsubmission() {
//		return dateofsubmission;
//	}
//
//	public void setDateofsubmission(String dateofsubmission) {
//		this.dateofsubmission = dateofsubmission;
//	}

	public String getAaname() {
		return aaname;
	}

	public void setAaname(String aaname) {
		this.aaname = aaname;
	}

	public String getAatitle() {
		return aatitle;
	}

	public void setAatitle(String aatitle) {
		this.aatitle = aatitle;
	}

	public String getAaemail() {
		return aaemail;
	}

	public void setAaemail(String aaemail) {
		this.aaemail = aaemail;
	}

	public String getAaphone() {
		return aaphone;
	}

	public void setAaphone(String aaphone) {
		this.aaphone = aaphone;
	}

	public String getTcname() {
		return tcname;
	}

	public void setTcname(String tcname) {
		this.tcname = tcname;
	}

	public String getTctitle() {
		return tctitle;
	}

	public void setTctitle(String tctitle) {
		this.tctitle = tctitle;
	}

	public String getTcemail() {
		return tcemail;
	}

	public void setTcemail(String tcemail) {
		this.tcemail = tcemail;
	}

	public String getTcphone() {
		return tcphone;
	}

	public void setTcphone(String tcphone) {
		this.tcphone = tcphone;
	}

	public String getTcrole() {
		return tcrole;
	}

	public void setTcrole(String tcrole) {
		this.tcrole = tcrole;
	}

	public String getBcname() {
		return bcname;
	}

	public void setBcname(String bcname) {
		this.bcname = bcname;
	}

	public String getBctitle() {
		return bctitle;
	}

	public void setBctitle(String bctitle) {
		this.bctitle = bctitle;
	}

	public String getBcemail() {
		return bcemail;
	}

	public void setBcemail(String bcemail) {
		this.bcemail = bcemail;
	}

	public String getBcphone() {
		return bcphone;
	}

	public void setBcphone(String bcphone) {
		this.bcphone = bcphone;
	}

	public String getBcrole() {
		return bcrole;
	}

	public void setBcrole(String bcrole) {
		this.bcrole = bcrole;
	}

	public String getOcname() {
		return ocname;
	}

	public void setOcname(String ocname) {
		this.ocname = ocname;
	}

	public String getOctitle() {
		return octitle;
	}

	public void setOctitle(String octitle) {
		this.octitle = octitle;
	}

	public String getOcemail() {
		return ocemail;
	}

	public void setOcemail(String ocemail) {
		this.ocemail = ocemail;
	}

	public String getOcphone() {
		return ocphone;
	}

	public void setOcphone(String ocphone) {
		this.ocphone = ocphone;
	}

	public String getSigname() {
		return signame;
	}

	public void setSigname(String signame) {
		this.signame = signame;
	}

	public String getSigtitle() {
		return sigtitle;
	}

	public void setSigtitle(String sigtitle) {
		this.sigtitle = sigtitle;
	}

	public Date getSigdt() {
		return sigdt;
	}

	public void setSigdt(Date sigdt) {
		this.sigdt = sigdt;
	}

	public String getSigphone() {
		return sigphone;
	}

	public void setSigphone(String sigphone) {
		this.sigphone = sigphone;
	}

	public String getSigemail() {
		return sigemail;
	}

	public void setSigemail(String sigemail) {
		this.sigemail = sigemail;
	}

	public String getSigext() {
		return sigext;
	}

	public void setSigext(String sigext) {
		this.sigext = sigext;
	}

	public String getSigsuggestion() {
		return sigsuggestion;
	}

	public void setSigsuggestion(String sigsuggestion) {
		sigsuggestion = sigsuggestion.replaceAll("\t", " ");
		sigsuggestion = sigsuggestion.replaceAll("”", "\"");
		sigsuggestion = sigsuggestion.replaceAll("’", "'");
		sigsuggestion = sigsuggestion.replaceAll("[^\\x00-\\x7F]", " ");
		this.sigsuggestion = sigsuggestion;
	}

	public String getSubmitionflag() {
		return submitionflag;
	}

	public void setSubmitionflag(String submitionflag) {
		this.submitionflag = submitionflag;
	}
}
