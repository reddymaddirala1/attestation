package us.ma.state.hhs.cg.attestation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class MailContentBuilder {
	 
	@Value("${activate.url}")
	private String activateURL;
	
    @Autowired
    private TemplateEngine templateEngine;

    public String buildTemplateForAccessCode(String email, String accessCode) {
       
    	String email1= email.split("@")[0];
    	Context context = new Context();
        context.setVariable("accessCode1", accessCode);
        context.setVariable("activateURL", activateURL);
       // context.setVariable("email", email);
        context.setVariable("accessCode", accessCode+"_"+email1);
        return templateEngine.process("accessCodeMailTemplate", context);
    } 
    
    public String buildTemplateForPDFRpt(String form) {
        Context context = new Context();
        context.setVariable("form", form);
        return templateEngine.process("pdfMailTemplate", context);
    } 
}