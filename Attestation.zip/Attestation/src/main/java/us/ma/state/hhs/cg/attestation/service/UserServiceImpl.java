package us.ma.state.hhs.cg.attestation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import us.ma.state.hhs.cg.attestation.model.AttestationUser;
import us.ma.state.hhs.cg.attestation.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public boolean saveUser(AttestationUser user) {
		
		AttestationUser savedUser = userRepository.save(user);
		
		if(savedUser != null) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean checkAccessCodeExists(long accessCode) {
		return userRepository.existsById(accessCode);
	}

	@Override
	public String getEmail(long accessCode) {
		return userRepository.findById(accessCode).get().getEmailAddr();
	}

	@Override
	public String getStatus(long accessCode) {
		return userRepository.findById(accessCode).get().getStatus();
	}

	@Override
	public AttestationUser getUser(long accessCode) {
		return userRepository.findById(accessCode).get();
	}
}
