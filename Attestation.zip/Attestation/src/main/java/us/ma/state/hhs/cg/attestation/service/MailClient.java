package us.ma.state.hhs.cg.attestation.service;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service
public class MailClient {
 
	private static final Logger logger = LoggerFactory.getLogger(MailClient.class);
	
    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private MailContentBuilder mailContentBuilder;
  
	@Value("${email.acc.from}")
	private String FROM_ACC_EMAIL;
	
	@Value("${email.pdf.from}")
	private String FROM_PDF_EMAIL;
	
	@Value("${email.cc}")
	private String CC_EMAIL;
	
    public boolean sendAccessCode(String recipient, String accessCode) {
   	
        MimeMessagePreparator messagePreparator = mimeMessage -> {
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
            messageHelper.setFrom(FROM_ACC_EMAIL);
            messageHelper.setTo(recipient);
            messageHelper.setSubject("Attestation Form Link & Access Code");
            String content = mailContentBuilder.buildTemplateForAccessCode(recipient, accessCode);
            messageHelper.setText(content, true);
        };
        try {
            mailSender.send(messagePreparator);
            return true;
        } catch (MailException e) {
            // runtime exception; compiler will not force you to handle it
    		//return false;
        	e.printStackTrace();
        	return false;
        }
    }
 
    
  public boolean sendPDFasAttachment(String recipient, String pdfPath, String pdfFilename, String form) {

	  	logger.debug("recipient : " + recipient);
	  	logger.debug("pdfPath : " + pdfPath);
	  	logger.debug("form : " + form);
	  	
	  	File pdfPathFile = new File(pdfPath);
	  	
	  	logger.debug("exists : " + pdfPathFile.exists());
	  	logger.debug("Absolute path : " + pdfPathFile.getAbsolutePath());
	  	
      MimeMessagePreparator messagePreparator = mimeMessage -> {
          MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
          messageHelper.setFrom(FROM_PDF_EMAIL);
          messageHelper.setTo(recipient);
          messageHelper.setCc(CC_EMAIL);
          messageHelper.setSubject("Mass HIway Attestation Form Received and Attached");
          messageHelper.addAttachment(pdfFilename, pdfPathFile);
          String content = mailContentBuilder.buildTemplateForPDFRpt(form);
          messageHelper.setText(content, true);
      };
      try {
          mailSender.send(messagePreparator);
          return true;
      } catch (MailException e) {
      	e.printStackTrace();
      	return false;
      }
  }
}