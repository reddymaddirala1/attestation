package us.ma.state.hhs.cg.attestation.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import us.ma.state.hhs.cg.attestation.model.AttestationYear3and4;

public interface FormYear3and4Repository extends JpaRepository<AttestationYear3and4, Long>{

}
