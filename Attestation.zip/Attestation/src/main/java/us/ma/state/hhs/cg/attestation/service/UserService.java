package us.ma.state.hhs.cg.attestation.service;

import us.ma.state.hhs.cg.attestation.model.AttestationUser;

public interface UserService {

	public boolean saveUser(AttestationUser user);
	
	public boolean checkAccessCodeExists(long accessCode);	
	
	public AttestationUser getUser(long accessCode);
	
	public String getEmail(long accessCode);	
	public String getStatus(long accessCode);
}
