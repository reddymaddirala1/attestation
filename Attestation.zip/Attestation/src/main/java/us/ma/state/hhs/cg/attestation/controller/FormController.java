package us.ma.state.hhs.cg.attestation.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDNonTerminalField;
import org.apache.pdfbox.pdmodel.interactive.form.PDRadioButton;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import us.ma.state.hhs.cg.attestation.model.AjaxResponse;
import us.ma.state.hhs.cg.attestation.model.AttestationException;
import us.ma.state.hhs.cg.attestation.model.AttestationUser;
import us.ma.state.hhs.cg.attestation.model.AttestationYear3and4;
import us.ma.state.hhs.cg.attestation.model.AttestationYear5;
import us.ma.state.hhs.cg.attestation.service.FormYearService;
import us.ma.state.hhs.cg.attestation.service.MailClient;
import us.ma.state.hhs.cg.attestation.service.PdfService;
import us.ma.state.hhs.cg.attestation.service.UserService;

@Controller
@RequestMapping("/Year")
public class FormController {
	
	private static final Logger logger = LoggerFactory.getLogger(FormController.class);
	
	@Autowired
    private FormYearService yearService;
	
	@Autowired
    private UserService userService;
	
	@Autowired
    private PdfService pdfService;
	
	@Autowired
	private MailClient mailClient;
	
	@Value("${pdfGenPrefixY3and4}")
	private String pdfPrefixYear3and4;
	
	@Value("${pdfGenPrefixY5}")
	private String pdfPrefixYear5;
	
	@Value("${pdfGenPrefixException}")
	private String pdfPrefixException;
	
	@Value("${pdfTemplateNameY3and4}")
	private String pdfTemplateNameY3and4;
	
	@Value("${pdfTemplateNameY5}")
	private String pdfTemplateNameY5;
	
	@Value("${pdfTemplateNameException}")
	private String pdfTemplateNameException;
	
	@Value("${pdfPathToSave}")
	private String pdfPathToSave;
	
	@Value("${pdfTemplatePath}")
	private String pdfTemplatePath;


    
    @RequestMapping(value = "/Year3and4/savedata", method = RequestMethod.POST)
    public ResponseEntity<?> saveYear3and4Data(@RequestBody AttestationYear3and4 yearForm, Model model){

    	logger.info("Y3 Form saved for " + yearForm.getAccessCode());
    	
    	AjaxResponse result = new AjaxResponse();
    	
    	AttestationYear3and4 savedForm = yearService.saveYear3and4Data(yearForm);
    	
    	if(savedForm != null) {
    		AttestationUser user = userService.getUser(yearForm.getAccessCode());
    		if(user.getAssociatedForm() == null || user.getAssociatedForm().equalsIgnoreCase("")) {
	    		user.setAssociatedForm("year3and4");
	    		userService.saveUser(user);
    		}
    	}
    	
    	if(savedForm == null) {
            result.setMsg("Save Failed!");
    	}else {
            result.setMsg("success");
    	}
    	
        return ResponseEntity.ok(result);
    }

    
    @RequestMapping(value = "/Year3and4/insertmasterdata", method = RequestMethod.POST)
    public ResponseEntity<?>  insertYear3MasterData(@RequestBody AttestationYear3and4 yearForm, Model model){
    	
    	logger.info("Y3&4 Form submitted for " + yearForm.getAccessCode());
    	
    	AjaxResponse result = new AjaxResponse();
    	
    	yearForm.setSigdt(new Date());
    	AttestationYear3and4 savedForm = yearService.saveYear3and4Data(yearForm);
    	
    	if(savedForm != null) {
    		AttestationUser user = userService.getUser(yearForm.getAccessCode());
    		user.setStatus("Submitted");
    		user.setAssociatedForm("year3and4");
    		user.setSubmissionDt(new Date());
    		userService.saveUser(user);
    	}
    	
    	boolean isMailSuccess = false;
    	try {
    		String pdfFileName = pdfPrefixYear3and4 + savedForm.getAccessCode() + ".pdf";
            String pdfSaveAbPath = pdfPathToSave + pdfFileName;
            String pdfAbTemplatePath = pdfTemplatePath + pdfTemplateNameY3and4;
            
            logger.info("pdfFileName : " + pdfFileName);
            logger.info("pdfSaveAbPath : " + pdfSaveAbPath);
            logger.info("pdfAbTemplatePath : " + pdfAbTemplatePath);
            
            // Generate PDF
			boolean isPDFGenerated = pdfService.generatePDFY3and4(savedForm, pdfSaveAbPath, pdfAbTemplatePath);
			
    		logger.info("PDF status : " + isPDFGenerated);

			//Obtain email Id
			String emailId = userService.getEmail(savedForm.getAccessCode());
			
    		//Send email with access code
    		isMailSuccess = mailClient.sendPDFasAttachment(emailId, pdfSaveAbPath, pdfFileName, "Year 3/4");
    		
    		logger.info("Mail status : " + isMailSuccess);
    		
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	if(!isMailSuccess) {
            result.setMsg("Save Failed!");
    	}else {
            result.setMsg("success");
    	}
    	
        return ResponseEntity.ok(result);
    }
    
    
    
    
    @RequestMapping(value = "/Year5/savedata", method = RequestMethod.POST)
    public ResponseEntity<?> saveYear5Data(@RequestBody AttestationYear5 yearForm, Model model){

    	logger.info("Y5 Form saved for " + yearForm.getAccessCode());
    	
    	AjaxResponse result = new AjaxResponse();
    	
    	AttestationYear5 savedForm = yearService.saveYear5Data(yearForm);
    	
    	if(savedForm != null) {
    		AttestationUser user = userService.getUser(yearForm.getAccessCode());
    		if(user.getAssociatedForm() == null || user.getAssociatedForm().equalsIgnoreCase("")) {
	    		user.setAssociatedForm("year5");
	    		userService.saveUser(user);
    		}
    	}
    	
    	if(savedForm == null) {
            result.setMsg("Save Failed!");
    	}else {
            result.setMsg("success");
    	}
    	
        return ResponseEntity.ok(result);
    }

    
    @RequestMapping(value = "/Year5/insertmasterdata", method = RequestMethod.POST)
    public ResponseEntity<?>  insertYear5MasterData(@RequestBody AttestationYear5 yearForm, Model model){
    	
    	logger.info("Y5 Form submitted for " + yearForm.getAccessCode());
    	
    	AjaxResponse result = new AjaxResponse();
    	
    	yearForm.setSigdt(new Date());
    	AttestationYear5 savedForm = yearService.saveYear5Data(yearForm);
    	
    	if(savedForm != null) {
    		AttestationUser user = userService.getUser(yearForm.getAccessCode());
    		user.setStatus("Submitted");
    		user.setAssociatedForm("year5");
    		user.setSubmissionDt(new Date());
    		userService.saveUser(user);
    	}
    	
    	boolean isMailSuccess = false;
    	try {
    		String pdfFileName = pdfPrefixYear5 + savedForm.getAccessCode() + ".pdf";
            String pdfSaveAbPath = pdfPathToSave + pdfFileName;
            String pdfAbTemplatePath = pdfTemplatePath + pdfTemplateNameY5;
            
            logger.info("pdfFileName : " + pdfFileName);
            logger.info("pdfSaveAbPath : " + pdfSaveAbPath);
            logger.info("pdfAbTemplatePath : " + pdfAbTemplatePath);
            
            // Generate PDF
			boolean isPDFGenerated = pdfService.generatePDFY5(savedForm, pdfSaveAbPath, pdfAbTemplatePath);
			
    		logger.info("PDF status : " + isPDFGenerated);

			//Obtain email Id
			String emailId = userService.getEmail(savedForm.getAccessCode());
			
    		//Send email with access code
    		isMailSuccess = mailClient.sendPDFasAttachment(emailId, pdfSaveAbPath, pdfFileName, "Year 5");
    		
    		logger.info("Mail status : " + isMailSuccess);
    		
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	if(!isMailSuccess) {
            result.setMsg("Save Failed!");
    	}else {
            result.setMsg("success");
    	}
    	
        return ResponseEntity.ok(result);
    }
    
      
    
    
    @RequestMapping(value = "/YearException/savedata", method = RequestMethod.POST)
    public ResponseEntity<?> saveYearExceptionData(@RequestBody AttestationException yearForm, Model model){

    	logger.info("Exception Form saved for " + yearForm.getAccessCode());
    	
    	AjaxResponse result = new AjaxResponse();
    	
    	AttestationException savedForm = yearService.saveExceptionData(yearForm);
    	
    	if(savedForm != null) {
    		AttestationUser user = userService.getUser(yearForm.getAccessCode());
    		if(user.getAssociatedForm() == null || user.getAssociatedForm().equalsIgnoreCase("")) {
	    		user.setAssociatedForm("exception");
	    		userService.saveUser(user);
    		}
    	}
    	
    	if(savedForm == null) {
            result.setMsg("Save Failed!");
    	}else {
            result.setMsg("success");
    	}
    	
        return ResponseEntity.ok(result);
    }
	
    @RequestMapping(value = "/YearException/insertmasterdata", method = RequestMethod.POST)
    public ResponseEntity<?>  insertExceptionMasterData(@RequestBody AttestationException yearForm, Model model){
    	
    	logger.info("Exception Form submitted for " + yearForm.getAccessCode());
    	
    	AjaxResponse result = new AjaxResponse();
    	
    	AttestationException savedForm = yearService.saveExceptionData(yearForm);
    	
    	if(savedForm != null) {
    		AttestationUser user = userService.getUser(yearForm.getAccessCode());
    		user.setStatus("Submitted");
    		user.setAssociatedForm("exception");
    		user.setSubmissionDt(new Date());
    		userService.saveUser(user);
    	}
    	
    	boolean isMailSuccess = false;
    	try {
    		String pdfFileName = pdfPrefixException + savedForm.getAccessCode() + ".pdf";
            String pdfSaveAbPath = pdfPathToSave + pdfFileName;
            String pdfAbTemplatePath = pdfTemplatePath + pdfTemplateNameException;
            
            logger.info("pdfFileName : " + pdfFileName);
            logger.info("pdfSaveAbPath : " + pdfSaveAbPath);
            logger.info("pdfAbTemplatePath : " + pdfAbTemplatePath);
            
            // Generate PDF
			boolean isPDFGenerated = pdfService.generatePDFEx(savedForm, pdfSaveAbPath, pdfAbTemplatePath);
			
    		logger.info("PDF status : " + isPDFGenerated);
    		
			//Obtain email Id
			String emailId = userService.getEmail(savedForm.getAccessCode());
			
    		//Send email with access code
    		isMailSuccess = mailClient.sendPDFasAttachment(emailId, pdfSaveAbPath, pdfFileName, "Exception");
    		
    		logger.info("Mail status : " + isMailSuccess);
    		
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	if(!isMailSuccess) {
            result.setMsg("Save Failed!");
    	}else {
            result.setMsg("success");
    	}
    	
        return ResponseEntity.ok(result);
    }    
    
}
