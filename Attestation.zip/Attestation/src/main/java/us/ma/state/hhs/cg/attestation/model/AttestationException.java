package us.ma.state.hhs.cg.attestation.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
		name = "attexception_2021"
	)
public class AttestationException {

	@Id
	@Column(name = "ACCESS_CODE")
	private long accessCode;
		
	/* SECTION - A */
	@Column(name = "SECA_ORGNAME")
	private String orgname;
	
	@Column(name = "SECA_STREET_ADDR")
	private String staddr;
	
	@Column(name = "SECA_CITY")
	private String city;
	
	@Column(name = "SECA_STATE")
	private String state;
	
	@Column(name = "SECA_ZIPCODE")
	private String zipcode;
	
	@Column(name = "SECA_PRACTICE_TYPE")
	private String practicetype;
	
	@Column(name = "SECA_EXPLAINATION")
	private String explaination;
	
	@Column(name = "SECA_PRIMARYREASONA")
	private String plana;
	
	@Column(name = "SECA_PRIMARYREASONB")
	private String planb;
	
	@Column(name = "SECA_UNABLETOMEETHIWAYREQ")
	private String unabletomeethiwayreq;
	
	@Column(name = "SECA_PLANTOMEETHIWAYREQ")
	private String plantomeethiwayreq;
	
	@Column(name = "SECA_PPORGASSISTANCE")
	private String pporgassisstance;
	
	
	
	/* SECTION - B */
	@Column(name = "SECB_ISEMREHRSYSTEM")
	private String ehremrsystem;
	
	@Column(name = "SECB_NAMEEMR")
	private String nameemr;
	
	@Column(name = "SECB_VERSIONEMR")
	private String versionemr;
	
	
	/* SECTION -C */
	
	@Column(name = "SECC_ISEMREHRSYSTEM")
	private String adtfeeds;
	
	@Column(name = "SECC_ENSINTIATIVE")
	private String ensintiative;
	
	@Column(name = "SECC_INFOONADTFEEDS")
	private String infoonadtfeeds;
	
	@Column(name = "SECC_DATEOFSUBMISSION")
	private String dateofsubmission;
   
	
	/* SECTION - D */
	@Column(name = "SECD_AA_NAME")
	private String aaname;
	
	@Column(name = "SECD_AA_TITLE")
	private String aatitle;
	
	@Column(name = "SECD_AA_EMAIL")
	private String aaemail;
	
	@Column(name = "SECD_AA_PHONE")
	private String aaphone;
	
	@Column(name = "SECD_AA_EXT")
	private String aaext;
	
	@Column(name = "SECD_OC_NAME")
	private String ocname;
	
	@Column(name = "SECD_OC_TITLE")
	private String octitle;
	
	@Column(name = "SECD_OC_EMAIL")
	private String ocemail;
	
	@Column(name = "SECD_OC_PHONE")
	private String ocphone;
	
	@Column(name = "SECD_OC_EXT")
	private String ocext;
	
	@Column(name = "SUGGESSTIONS")
	private String suggestions;
		
	@Column(name = "SUBMITION_FLAG")
	private String submitionflag;
	
	
	public AttestationException() {
		super();
	}

	public AttestationException(long accessCode, String orgname, String staddr, String city, String state,
			String zipcode, String practicetype, String explaination, String plana, String planb,
			String unabletomeethiwayreq, String plantomeethiwayreq, String pporgassisstance, String ehremrsystem,
			String nameemr, String versionemr, String adtfeeds, String ensintiative, String infoonadtfeeds,
			String dateofsubmission, String aaname, String aatitle, String aaemail, String aaphone, String aaext,
			String ocname, String octitle, String ocemail, String ocphone, String suggestions, String submitionflag) {
		super();
		this.accessCode = accessCode;
		this.orgname = orgname;
		this.staddr = staddr;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.practicetype = practicetype;
		this.explaination = explaination;
		this.plana = plana;
		this.planb = planb;
		this.unabletomeethiwayreq = unabletomeethiwayreq;
		this.plantomeethiwayreq = plantomeethiwayreq;
		this.pporgassisstance = pporgassisstance;
		this.ehremrsystem = ehremrsystem;
		this.nameemr = nameemr;
		this.versionemr = versionemr;
		this.adtfeeds = adtfeeds;
		this.ensintiative = ensintiative;
		this.infoonadtfeeds = infoonadtfeeds;
		this.dateofsubmission = dateofsubmission;
		this.aaname = aaname;
		this.aatitle = aatitle;
		this.aaemail = aaemail;
		this.aaphone = aaphone;
		this.aaext = aaext;
		this.ocname = ocname;
		this.octitle = octitle;
		this.ocemail = ocemail;
		this.ocphone = ocphone;
		this.suggestions = suggestions;
		this.submitionflag = submitionflag;
	}




	public long getAccessCode() {
		return accessCode;
	}




	public void setAccessCode(long accessCode) {
		this.accessCode = accessCode;
	}




	public String getOrgname() {
		return orgname;
	}




	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}




	public String getStaddr() {
		return staddr;
	}




	public void setStaddr(String staddr) {
		this.staddr = staddr;
	}




	public String getCity() {
		return city;
	}




	public void setCity(String city) {
		this.city = city;
	}




	public String getState() {
		return state;
	}




	public void setState(String state) {
		this.state = state;
	}




	public String getZipcode() {
		return zipcode;
	}




	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}




	public String getPracticetype() {
		return practicetype;
	}




	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}




	public String getExplaination() {
		return explaination;
	}




	public void setExplaination(String explaination) {
		explaination = explaination.replaceAll("\t", " ");
		explaination = explaination.replaceAll("”", "\"");
		explaination = explaination.replaceAll("’", "'");
		explaination = explaination.replaceAll("[^\\x00-\\x7F]", " ");
		this.explaination = explaination;
	}




	public String getPlana() {
		return plana;
	}




	public void setPlana(String plana) {
		this.plana = plana;
	}




	public String getPlanb() {
		return planb;
	}




	public void setPlanb(String planb) {
		this.planb = planb;
	}




	public String getUnabletomeethiwayreq() {
		return unabletomeethiwayreq;
	}




	public void setUnabletomeethiwayreq(String unabletomeethiwayreq) {
		unabletomeethiwayreq = unabletomeethiwayreq.replaceAll("\t", " ");
		unabletomeethiwayreq = unabletomeethiwayreq.replaceAll("”", "\"");
		unabletomeethiwayreq = unabletomeethiwayreq.replaceAll("’", "'");
		unabletomeethiwayreq = unabletomeethiwayreq.replaceAll("[^\\x00-\\x7F]", " ");
		this.unabletomeethiwayreq = unabletomeethiwayreq;
	}




	public String getPlantomeethiwayreq() {
		return plantomeethiwayreq;
	}




	public void setPlantomeethiwayreq(String plantomeethiwayreq) {
		plantomeethiwayreq = plantomeethiwayreq.replaceAll("\t", " ");
		plantomeethiwayreq = plantomeethiwayreq.replaceAll("”", "\"");
		plantomeethiwayreq = plantomeethiwayreq.replaceAll("’", "'");
		plantomeethiwayreq = plantomeethiwayreq.replaceAll("[^\\x00-\\x7F]", " ");
		this.plantomeethiwayreq = plantomeethiwayreq;
	}




	public String getPporgassisstance() {
		return pporgassisstance;
	}




	public void setPporgassisstance(String pporgassisstance) {
		this.pporgassisstance = pporgassisstance;
	}




	public String getEhremrsystem() {
		return ehremrsystem;
	}




	public void setEhremrsystem(String ehremrsystem) {
		this.ehremrsystem = ehremrsystem;
	}




	public String getNameemr() {
		return nameemr;
	}




	public void setNameemr(String nameemr) {
		this.nameemr = nameemr;
	}




	public String getVersionemr() {
		return versionemr;
	}




	public void setVersionemr(String versionemr) {
		this.versionemr = versionemr;
	}




	public String getAdtfeeds() {
		return adtfeeds;
	}




	public void setAdtfeeds(String adtfeeds) {
		this.adtfeeds = adtfeeds;
	}




	public String getEnsintiative() {
		return ensintiative;
	}




	public void setEnsintiative(String ensintiative) {
		ensintiative = ensintiative.replaceAll("\t", " ");
		ensintiative = ensintiative.replaceAll("”", "\"");
		ensintiative = ensintiative.replaceAll("’", "'");
		ensintiative = ensintiative.replaceAll("[^\\x00-\\x7F]", " ");
		this.ensintiative = ensintiative;
	}




	public String getInfoonadtfeeds() {
		return infoonadtfeeds;
	}




	public void setInfoonadtfeeds(String infoonadtfeeds) {
		this.infoonadtfeeds = infoonadtfeeds;
	}




	public String getDateofsubmission() {
		return dateofsubmission;
	}




	public void setDateofsubmission(String dateofsubmission) {
		this.dateofsubmission = dateofsubmission;
	}




	public String getAaname() {
		return aaname;
	}




	public void setAaname(String aaname) {
		this.aaname = aaname;
	}




	public String getAatitle() {
		return aatitle;
	}




	public void setAatitle(String aatitle) {
		this.aatitle = aatitle;
	}




	public String getAaemail() {
		return aaemail;
	}




	public void setAaemail(String aaemail) {
		this.aaemail = aaemail;
	}




	public String getAaphone() {
		return aaphone;
	}




	public void setAaphone(String aaphone) {
		this.aaphone = aaphone;
	}




	public String getAaext() {
		return aaext;
	}




	public void setAaext(String aaext) {
		this.aaext = aaext;
	}




	public String getOcname() {
		return ocname;
	}




	public void setOcname(String ocname) {
		this.ocname = ocname;
	}




	public String getOctitle() {
		return octitle;
	}




	public void setOctitle(String octitle) {
		this.octitle = octitle;
	}




	public String getOcemail() {
		return ocemail;
	}




	public void setOcemail(String ocemail) {
		this.ocemail = ocemail;
	}




	public String getOcphone() {
		return ocphone;
	}




	public void setOcphone(String ocphone) {
		this.ocphone = ocphone;
	}




	public String getOcext() {
		return ocext;
	}

	public void setOcext(String ocext) {
		this.ocext = ocext;
	}

	public String getSuggestions() {
		return suggestions;
	}




	public void setSuggestions(String suggestions) {
		suggestions = suggestions.replaceAll("\t", " ");
		suggestions = suggestions.replaceAll("”", "\"");
		suggestions = suggestions.replaceAll("’", "'");
		suggestions = suggestions.replaceAll("[^\\x00-\\x7F]", " ");
		this.suggestions = suggestions;
	}




	public String getSubmitionflag() {
		return submitionflag;
	}




	public void setSubmitionflag(String submitionflag) {
		this.submitionflag = submitionflag;
	}

	
	
	

	
	
}
