package us.ma.state.hhs.cg.attestation.service;

import us.ma.state.hhs.cg.attestation.model.AttestationException;
import us.ma.state.hhs.cg.attestation.model.AttestationYear3and4;
import us.ma.state.hhs.cg.attestation.model.AttestationYear5;

public interface FormYearService {
	
	public AttestationYear3and4 saveYear3and4Data(AttestationYear3and4 yearForm);
	public AttestationYear5 saveYear5Data(AttestationYear5 yearForm);
	public AttestationException saveExceptionData(AttestationException yearForm);
		
	public AttestationYear3and4 getYear3and4FormData(long id);
	public AttestationYear5 getYear5FormData(long id);
	public AttestationException getExceptionFormData(long id);

	public boolean checkAccCodeExistsY3and4(long accessCode);
	public boolean checkAccCodeExistsY5(long accessCode);
	public boolean checkAccCodeExistsEx(long accessCode);	

}
