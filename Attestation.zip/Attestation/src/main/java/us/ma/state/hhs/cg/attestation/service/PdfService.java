package us.ma.state.hhs.cg.attestation.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDComboBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDListBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDNonTerminalField;
import org.apache.pdfbox.pdmodel.interactive.form.PDRadioButton;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import us.ma.state.hhs.cg.attestation.model.AttestationException;
import us.ma.state.hhs.cg.attestation.model.AttestationYear3and4;
import us.ma.state.hhs.cg.attestation.model.AttestationYear5;

@Service
public class PdfService {

	@Value("${fontPath}")
	private String fontPath;

	
	public boolean generatePDFY3and4(AttestationYear3and4 form, String pathToSave, String templatePath) throws IOException {
		PDDocument finalDoc = new PDDocument();
		File yearFormTemplate = new File(templatePath);

		PDDocument doc = new PDDocument().load(yearFormTemplate);
		doc.setAllSecurityToBeRemoved(true);

		PDDocumentCatalog docCatalog = doc.getDocumentCatalog();
		PDAcroForm acroForm = docCatalog.getAcroForm();

		acroForm.setXFA(null);
		
		Iterator<PDField> fieldIterator = acroForm.getFieldIterator();

		while (fieldIterator.hasNext()) {
			PDField pdField = fieldIterator.next();

			System.out.println("pdfFieldName" +pdField.getPartialName());
			String pdfFieldName = pdField.getPartialName().replace("[0]", "");
			//System.out.println("pdfFieldName" +pdfFieldName);

			if (pdField instanceof PDTextField) {

				/* SECTION A */
				if (pdfFieldName.equalsIgnoreCase("Q1")) {
					((PDTextField) pdField).setValue(form.getOrgname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2A")) {
					((PDTextField) pdField).setValue(form.getStaddr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2B")) {
					((PDTextField) pdField).setValue(form.getCity());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2C")) {
					((PDTextField) pdField).setValue(form.getState());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2D")) {
					((PDTextField) pdField).setValue(form.getZipcode());
				}

				if (pdfFieldName.equalsIgnoreCase("Q3")) {
					((PDTextField) pdField).setValue(form.getTaxid());
				}

				if (pdfFieldName.equalsIgnoreCase("Q5")) {
					((PDTextField) pdField).setValue(form.getOrgnpi());
				}

				if (pdfFieldName.equalsIgnoreCase("Q5[1]")) {
					((PDTextField) pdField).setValue(form.getOrgdomain());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q6")) {
					((PDTextField) pdField).setValue(form.getParentcompany());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q7")) {
					((PDTextField) pdField).setValue(form.getSuborg());
				}
				

				/* SECTION B */

				// 8a

				if (pdfFieldName.equalsIgnoreCase("Q8AA")) {
					((PDTextField) pdField).setValue(form.getExpandgoalusecase());
				}

				// 9 SendDescriptiveName
				if (pdfFieldName.equalsIgnoreCase("Q9")) {
					((PDTextField) pdField).setValue(form.getNameusecase());
				}

				// 17 SendDescriptiveName
				if (pdfFieldName.equalsIgnoreCase("Q17")) {
					((PDTextField) pdField).setValue(form.getNameusecasereceiver());
				}

				// 10
				if (pdfFieldName.equalsIgnoreCase("Q10")) {
					((PDTextField) pdField).setValue(form.getDateusecase());
				}

				// 18
				if (pdfFieldName.equalsIgnoreCase("Q18")) {
					((PDTextField) pdField).setValue(form.getDateusecasereceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q8F2")) {
					((PDTextField) pdField).setValue(form.getOtherusecase());
				}

				// 14
				if (pdfFieldName.equalsIgnoreCase("Q14")) {
					((PDTextField) pdField).setValue(form.getEntityusecase());
				}

				// 22
				if (pdfFieldName.equalsIgnoreCase("Q22")) {
					((PDTextField) pdField).setValue(form.getEntityusecasereceiver());
				}

				// 14a
				if (pdfFieldName.equalsIgnoreCase("Q14A")) {
					((PDTextField) pdField).setValue(form.getOtherorgdomain());
				}

				// 22 a
				if (pdfFieldName.equalsIgnoreCase("Q22A")) {
					((PDTextField) pdField).setValue(form.getOtherorgdomainreceiver());
				}
                 //16
				if (pdfFieldName.equalsIgnoreCase("Q16W2")) {
					((PDTextField) pdField).setValue(form.getOthercategory2());
				}
              //24other
				if (pdfFieldName.equalsIgnoreCase("Q24W2")) {
					((PDTextField) pdField).setValue(form.getOthercategory2receiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q12F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfotype());
				}
				if (pdfFieldName.equalsIgnoreCase("Q20F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfotypereceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q13E2")) {
					((PDTextField) pdField).setValue(form.getHl7infoformat());
				}

				if (pdfFieldName.equalsIgnoreCase("Q21E2")) {
					((PDTextField) pdField).setValue(form.getHl7infoformatreceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q13F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfoformat());
				}

				if (pdfFieldName.equalsIgnoreCase("Q21F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfoformatreceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q26B")) {
					((PDTextField) pdField).setValue(form.getListothermethod());
				}

				/* SECTION C */
				if (pdfFieldName.equalsIgnoreCase("Q30")) {
					((PDTextField) pdField).setValue(form.getNameemr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q31")) {
					((PDTextField) pdField).setValue(form.getVersionemr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q35B2")) {
					((PDTextField) pdField).setValue(form.getOtherconnprovider());
				}
				
//				if (pdfFieldName.equalsIgnoreCase("Q36A")) {
//					((PDTextField) pdField).setValue(form.getEnsinitiative());
//				}
//				
//				if (pdfFieldName.equalsIgnoreCase("Q37")) {
//					((PDTextField) pdField).setValue(form.getInfoonadtfeeds());
//				}
//				if (pdfFieldName.equalsIgnoreCase("Q38")) {
//					((PDTextField) pdField).setValue(form.getDateofsubmission());
//				}

				/* SECTION D */
				if (pdfFieldName.equalsIgnoreCase("Q39A")) {
					((PDTextField) pdField).setValue(form.getAaname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q39B")) {
					((PDTextField) pdField).setValue(form.getAatitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q39C")) {
					((PDTextField) pdField).setValue(form.getAaphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q39D")) {
					((PDTextField) pdField).setValue(form.getAaemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40A")) {
					((PDTextField) pdField).setValue(form.getTcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40B")) {
					((PDTextField) pdField).setValue(form.getTctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40C")) {
					((PDTextField) pdField).setValue(form.getTcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40D")) {
					((PDTextField) pdField).setValue(form.getTcemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41A")) {
					((PDTextField) pdField).setValue(form.getBcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41B")) {
					((PDTextField) pdField).setValue(form.getBctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41C")) {
					((PDTextField) pdField).setValue(form.getBcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41D")) {
					((PDTextField) pdField).setValue(form.getBcemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42A")) {
					((PDTextField) pdField).setValue(form.getOcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42B")) {
					((PDTextField) pdField).setValue(form.getOctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42C")) {
					((PDTextField) pdField).setValue(form.getOcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42D")) {
					((PDTextField) pdField).setValue(form.getOcemail());
				}

				/* SECTION E */
				if (pdfFieldName.equalsIgnoreCase("Q43A")) {
					((PDTextField) pdField).setValue(form.getSigname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43B")) {
					((PDTextField) pdField).setValue(form.getSigtitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43C")) {
					((PDTextField) pdField).setValue(form.getSigphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43D")) {
					((PDTextField) pdField).setValue(form.getSigext());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43E")) {
					((PDTextField) pdField).setValue(form.getSigemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43G")) {
					((PDTextField) pdField).setValue(form.getSigdt().toString());
				}

				if (pdfFieldName.equalsIgnoreCase("Q44")) {
					((PDTextField) pdField).setValue(form.getSigsuggestion());
				}
			}

			if (pdField instanceof PDComboBox) {

				// 4a
				if (pdfFieldName.equalsIgnoreCase("Q4")) {
					((PDComboBox) pdField).setValue(form.getPracticetype());
				}

				// 16a
				/*if (pdfFieldName.equalsIgnoreCase("YesNo1")) {
					((PDComboBox) pdField).setValue(form.getSolelyhiway());
				}*/

				// 17
				if (pdfFieldName.equalsIgnoreCase("Q26A")) {
					((PDComboBox) pdField).setValue(form.getOthermethod());
				}

				/*// 17b
				if (pdfFieldName.equalsIgnoreCase("YesNo3")) {
					((PDComboBox) pdField).setValue(form.getInformationusecase());
				}*/

				// 19
				if (pdfFieldName.equalsIgnoreCase("Q29")) {
					((PDComboBox) pdField).setValue(form.getEhremrsystem());
				}
				
				// 36
//				if (pdfFieldName.equalsIgnoreCase("Q36")) {
//					((PDComboBox) pdField).setValue(form.getAdtfeeds());
//				}

				// 34
				if (pdfFieldName.equalsIgnoreCase("Q34")) {
					((PDComboBox) pdField).setValue(form.getOnccertified());
				}
				
				// 37
				/*if (pdfFieldName.equalsIgnoreCase("Q37")) {
					((PDComboBox) pdField).setValue(form.getInfoonadtfeeds());
				}*/

			}

			if (pdField instanceof PDCheckBox) {
				
				// 8
				if (pdfFieldName.equalsIgnoreCase("Q8A")
						&& form.getGoalusecase().contains("Reduce hospital readmissions")) {
					((PDCheckBox) pdField).check();
				}


				if (pdfFieldName.equalsIgnoreCase("Q8C")
						&& form.getGoalusecase().contains("Facilitate care coordination")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8B")
						&& form.getGoalusecase().contains("Reduce unnecessary testing")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8E")
						&& form.getGoalusecase().contains("Improve administrative efficiency")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8D") && 
						form.getGoalusecase().contains("Reduce costs")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8F1")
						&& form.getGoalusecase().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 11
				if (pdfFieldName.equalsIgnoreCase("Q11")) {

					((PDCheckBox) pdField).check();

				}
				
				if (pdfFieldName.equalsIgnoreCase("Q19")) {

					((PDCheckBox) pdField).check();

				}

				// 16
				
				
				if (pdfFieldName.equalsIgnoreCase("Q16A")
						&& form.getCategory2usecase().contains("Accountable Care Organization")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16H")
						&& form.getCategory2usecase().contains("Large Federally Qualified Health Center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16O")
						&& form.getCategory2usecase().contains("Skilled nursing facility")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16B")
						&& form.getCategory2usecase().contains("Ambulance and emergency response")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16I")
						&& form.getCategory2usecase().contains("Large hospital/health system**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16P")
						&& form.getCategory2usecase().contains("Small ambulatory practice (3-9)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16C")
						&& form.getCategory2usecase().contains("Ambulatory surgery center")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16J")
						&& form.getCategory2usecase().contains("Large long-term care facility (500+ beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16Q")
						&& form.getCategory2usecase().contains("Small behavioral health (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16D")
						&& form.getCategory2usecase().contains("Home health, LTSS")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16K")
						&& form.getCategory2usecase().contains("MassHealth Behavioral Health Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16R")
						&& form.getCategory2usecase().contains("Small Community health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16E")
						&& form.getCategory2usecase().contains("Large ambulatory practice (50+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16L")
						&& form.getCategory2usecase().contains("MassHealth Community Service Agency")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16S")
						&& form.getCategory2usecase().contains("Small Federally qualified health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16F")
						&& form.getCategory2usecase().contains("Large behavioral health (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16M")
						&& form.getCategory2usecase().contains("MassHealth LTSS Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16T")
						&& form.getCategory2usecase().contains("Small hospital**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16G")
						&& form.getCategory2usecase().contains("Large community health center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16N")
						&& form.getCategory2usecase().contains("Medium ambulatory practice (10-49)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16U")
						&& form.getCategory2usecase().contains("Small long-term care facility (<500 beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16W1")
						&& form.getCategory2usecase().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16V")
						&& form.getCategory2usecase().contains("Very small ambulatory practice (1-2)*")) {
					((PDCheckBox) pdField).check();
				}

				
				// 24
				if (pdfFieldName.equalsIgnoreCase("Q24A")
						&& form.getCategory2usecasereceiver().contains("Accountable Care Organization")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24H")
						&& form.getCategory2usecasereceiver().contains("Large Federally Qualified Health Center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24O")
						&& form.getCategory2usecasereceiver().contains("Skilled nursing facility")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24B")
						&& form.getCategory2usecasereceiver().contains("Ambulance and emergency response")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24I")
						&& form.getCategory2usecasereceiver().contains("Large hospital/health system**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24P")
						&& form.getCategory2usecasereceiver().contains("Small ambulatory practice (3-9)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24C")
						&& form.getCategory2usecasereceiver().contains("Ambulatory surgery center")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24J")
						&& form.getCategory2usecasereceiver().contains("Large long-term care facility (500+ beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24Q")
						&& form.getCategory2usecasereceiver().contains("Small behavioral health (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24D")
						&& form.getCategory2usecasereceiver().contains("Home health, LTSS")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24K")
						&& form.getCategory2usecasereceiver().contains("MassHealth Behavioral Health Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24R")
						&& form.getCategory2usecasereceiver().contains("Small Community health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24E")
						&& form.getCategory2usecasereceiver().contains("Large ambulatory practice (50+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24L")
						&& form.getCategory2usecasereceiver().contains("MassHealth Community Service Agency")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24S")
						&& form.getCategory2usecasereceiver().contains("Small Federally qualified health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24F")
						&& form.getCategory2usecasereceiver().contains("Large behavioral health (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24M")
						&& form.getCategory2usecasereceiver().contains("MassHealth LTSS Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24T")
						&& form.getCategory2usecasereceiver().contains("Small hospital**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24G")
						&& form.getCategory2usecasereceiver().contains("Large community health center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24N")
						&& form.getCategory2usecasereceiver().contains("Medium ambulatory practice (10-49)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24U")
						&& form.getCategory2usecasereceiver().contains("Small long-term care facility (<500 beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24W1")
						&& form.getCategory2usecasereceiver().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24V")
						&& form.getCategory2usecasereceiver().contains("Very small ambulatory practice (1-2)*")) {
					((PDCheckBox) pdField).check();
				}
				
				// 15
				if (pdfFieldName.equalsIgnoreCase("Q15") && form.getCat2ucsender().contains("Sending")) {
					((PDCheckBox) pdField).check();
				}

				// 23
				if (pdfFieldName.equalsIgnoreCase("Q23")
						&& form.getCat2ucreceiver().contains("Receiving")) {
					((PDCheckBox) pdField).check();
				}

				// 12
				
				
				if (pdfFieldName.equalsIgnoreCase("Q12A")
						&& form.getInfotype().contains("Discharge Summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12B")
						&& form.getInfotype().contains("Admission, Discharge, Transfer (ADT)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12C") && form.getInfotype().contains("Referral summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12D") && form.getInfotype().contains("Summary of care")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12E")
						&& form.getInfotype().contains("General assessment")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12F1")
						&& form.getInfotype().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 20
				if (pdfFieldName.equalsIgnoreCase("Q20A")
						&& form.getInfotypereceiver().contains("Discharge Summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20B")
						&& form.getInfotypereceiver().contains("Admission, Discharge, Transfer (ADT)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20C")
						&& form.getInfotypereceiver().contains("Referral summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20D")
						&& form.getInfotypereceiver().contains("Summary of care")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20E")
						&& form.getInfotypereceiver().contains("General assessment")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20F1")
						&& form.getInfotypereceiver().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 13
				
				if (pdfFieldName.equalsIgnoreCase("Q13A")
						&& form.getInfoformat().contains("CCD")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13B") && form.getInfoformat().contains("C-CDA/CDA")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13D")
						&& form.getInfoformat().contains("Secure message")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13C") && form.getInfoformat().contains("PDF")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13E1")
						&& form.getInfoformat().contains("HL7 message (specify type)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13F1")
						&& form.getInfoformat().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 21
				if (pdfFieldName.equalsIgnoreCase("Q21A") && form.getInfoformatreceiver().contains("CCD")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21B") && form.getInfoformatreceiver().contains("C-CDA/CDA")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21D")
						&& form.getInfoformatreceiver().contains("Secure message")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21C") && form.getInfoformatreceiver().contains("PDF")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21E1")
						&& form.getInfoformatreceiver().contains("HL7 message (specify type)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21F1")
						&& form.getInfoformatreceiver().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 24
				if (pdfFieldName.equalsIgnoreCase("Q35A")
						&& form.getConnectingprovider().contains("via Mass HIway Webmail")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q35B1")
						&& form.getConnectingprovider().contains("Via some other method (please specify)")) {
					((PDCheckBox) pdField).check();
				}
			}

			if (pdField instanceof PDRadioButton) {

				// 25
				if (pdfFieldName.equalsIgnoreCase("Q25")) {
					String value0 = "0-24%";
					String value1 = "25-49%";
					String value2 = "50-74%";
					String value3 = "75-99%";
					String value4 = "100%";
					
				 if (form.getMsgpercentage().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getMsgpercentage().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getMsgpercentage().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
					
					if (form.getMsgpercentage().equalsIgnoreCase(value3)) {
						((PDRadioButton) pdField).setValue("3");
					}
					
					if (form.getMsgpercentage().equalsIgnoreCase(value4)) {
						((PDRadioButton) pdField).setValue("4");
					}
				}

				// 27
				if (pdfFieldName.equalsIgnoreCase("Q27")) {
					String value0 = "Less than 100 Direct Messages";
					String value1 = "Between 100 and 1,000 Direct Messages";
					String value2 = "Over 1,000 Direct Messages";

					if (form.getTransac_no().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getTransac_no().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getTransac_no().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
				}

				// 28
				if (pdfFieldName.equalsIgnoreCase("Q28")) {
					String value0 = "Yes";
					String value1 = "No";

					if (form.getFreeassistance().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getFreeassistance().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}

				// 32
				if (pdfFieldName.equalsIgnoreCase("Q32")) {
					String value0 = "Directly to the Mass HIway";
					String value1 = "via a HISP other than the Mass HIway";

					if (form.getConnectingemr().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getConnectingemr().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}

				// 33

				if (pdfFieldName.equalsIgnoreCase("Q33")) {
					String value0 = "Directly to the Mass HIway";
					String value1 = "via a HISP other than the Mass HIway";

					if (form.getReceivingusecase().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getReceivingusecase().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}
				//
				/*if (pdfFieldName.equalsIgnoreCase("Q33")) {
					String value0 = "Directly to the Mass HIway";
					String value1 = "via a HISP other than the Mass HIway";

					if (form.getReceivingusecase().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getReceivingusecase().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}*/
				//37
//				if (pdfFieldName.equalsIgnoreCase("Q37")) {
//					String value0 = "Vendor1";
//					String value1 = "Vendor2";
//					String value2 = "Vendor3";
//
//					if (form.getInfoonadtfeeds().equalsIgnoreCase(value0)) {
//						((PDRadioButton) pdField).setValue("0");
//					}
//
//					if (form.getInfoonadtfeeds().equalsIgnoreCase(value1)) {
//						((PDRadioButton) pdField).setValue("1");
//					}
//
//					if (form.getInfoonadtfeeds().equalsIgnoreCase(value2)) {
//						((PDRadioButton) pdField).setValue("2");
//					}
//				}

				// SecD - TC
				if (pdfFieldName.equalsIgnoreCase("Q40E")) {
					String value0 = "In-house";
					String value1 = "Technical integrator";

					if (form.getTcrole().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getTcrole().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}

				// SecD - BC
				if (pdfFieldName.equalsIgnoreCase("Q41E")) 
				{
					String value0 = "Clinical leadership";
					String value1 = "Operations leadership";
					String value2 = "HIE leadership / owner";

					if (form.getBcrole().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getBcrole().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getBcrole().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
				}
			}
		}

		//Flatten the document
		acroForm.flatten();
		
		// Saving the document
		doc.save(pathToSave);

		// Closing the document
		doc.close();

		return true;

	}
	
	
	
	
	
	
	public boolean generatePDFY5(AttestationYear5 form, String pathToSave, String templatePath) throws IOException {
		PDDocument finalDoc = new PDDocument();
		File yearFormTemplate = new File(templatePath);

		PDDocument doc = new PDDocument().load(yearFormTemplate);
		doc.setAllSecurityToBeRemoved(true);

		PDDocumentCatalog docCatalog = doc.getDocumentCatalog();
		PDAcroForm acroForm = docCatalog.getAcroForm();

		acroForm.setXFA(null);
		
		Iterator<PDField> fieldIterator = acroForm.getFieldIterator();

		while (fieldIterator.hasNext()) {
			PDField pdField = fieldIterator.next();

			System.out.println("pdfFieldName" +pdField.getPartialName());
			String pdfFieldName = pdField.getPartialName().replace("[0]", "");
			//System.out.println("pdfFieldName" +pdfFieldName);

			if (pdField instanceof PDTextField) {

				/* SECTION A */
				if (pdfFieldName.equalsIgnoreCase("Q1")) {
					((PDTextField) pdField).setValue(form.getOrgname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2A")) {
					((PDTextField) pdField).setValue(form.getStaddr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2B")) {
					((PDTextField) pdField).setValue(form.getCity());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2C")) {
					((PDTextField) pdField).setValue(form.getState());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2D")) {
					((PDTextField) pdField).setValue(form.getZipcode());
				}

				if (pdfFieldName.equalsIgnoreCase("Q3")) {
					((PDTextField) pdField).setValue(form.getTaxid());
				}

				if (pdfFieldName.equalsIgnoreCase("Q4")) {
					((PDTextField) pdField).setValue(form.getOrgnpi());
				}

				if (pdfFieldName.equalsIgnoreCase("Q5")) {
					((PDTextField) pdField).setValue(form.getOrgdomain());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q6")) {
					((PDTextField) pdField).setValue(form.getParentcompany());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q7")) {
					((PDTextField) pdField).setValue(form.getSuborg());
				}
				

				/* SECTION B */

				// 8a

				if (pdfFieldName.equalsIgnoreCase("Q8AA")) {
					((PDTextField) pdField).setValue(form.getExpandgoalusecase());
				}

				// 9 SendDescriptiveName
				if (pdfFieldName.equalsIgnoreCase("Q9")) {
					((PDTextField) pdField).setValue(form.getNameusecase());
				}

				// 17 SendDescriptiveName
				if (pdfFieldName.equalsIgnoreCase("Q17")) {
					((PDTextField) pdField).setValue(form.getNameusecasereceiver());
				}

				// 10
				if (pdfFieldName.equalsIgnoreCase("Q10")) {
					((PDTextField) pdField).setValue(form.getDateusecase());
				}

				// 18
				if (pdfFieldName.equalsIgnoreCase("Q18")) {
					((PDTextField) pdField).setValue(form.getDateusecasereceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q8F2")) {
					((PDTextField) pdField).setValue(form.getOtherusecase());
				}

				// 14
				if (pdfFieldName.equalsIgnoreCase("Q14")) {
					((PDTextField) pdField).setValue(form.getEntityusecase());
				}

				// 22
				if (pdfFieldName.equalsIgnoreCase("Q22")) {
					((PDTextField) pdField).setValue(form.getEntityusecasereceiver());
				}

				// 14a
				if (pdfFieldName.equalsIgnoreCase("Q14A")) {
					((PDTextField) pdField).setValue(form.getOtherorgdomain());
				}

				// 22 a
				if (pdfFieldName.equalsIgnoreCase("Q22A")) {
					((PDTextField) pdField).setValue(form.getOtherorgdomainreceiver());
				}
                 //16
				if (pdfFieldName.equalsIgnoreCase("Q16W2")) {
					((PDTextField) pdField).setValue(form.getOthercategory2());
				}
              //24other
				if (pdfFieldName.equalsIgnoreCase("Q24W2")) {
					((PDTextField) pdField).setValue(form.getOthercategory2receiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q12F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfotype());
				}
				if (pdfFieldName.equalsIgnoreCase("Q20F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfotypereceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q13E2")) {
					((PDTextField) pdField).setValue(form.getHl7infoformat());
				}

				if (pdfFieldName.equalsIgnoreCase("Q21E2")) {
					((PDTextField) pdField).setValue(form.getHl7infoformatreceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q13F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfoformat());
				}

				if (pdfFieldName.equalsIgnoreCase("Q21F2")) {
					((PDTextField) pdField).setValue(form.getOtherinfoformatreceiver());
				}

				if (pdfFieldName.equalsIgnoreCase("Q26B")) {
					((PDTextField) pdField).setValue(form.getListothermethod());
				}

				/* SECTION C */
				if (pdfFieldName.equalsIgnoreCase("Q30")) {
					((PDTextField) pdField).setValue(form.getNameemr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q31")) {
					((PDTextField) pdField).setValue(form.getVersionemr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q35B2")) {
					((PDTextField) pdField).setValue(form.getOtherconnprovider());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q36A")) {
					((PDTextField) pdField).setValue(form.getEnsinitiative());
				}
				
//				if (pdfFieldName.equalsIgnoreCase("Q37")) {
//					((PDTextField) pdField).setValue(form.getInfoonadtfeeds());
//				}
				if (pdfFieldName.equalsIgnoreCase("Q38")) {
					((PDTextField) pdField).setValue(form.getDateofsubmission());
				}

				/* SECTION D */
				if (pdfFieldName.equalsIgnoreCase("Q39A")) {
					((PDTextField) pdField).setValue(form.getAaname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q39B")) {
					((PDTextField) pdField).setValue(form.getAatitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q39C")) {
					((PDTextField) pdField).setValue(form.getAaphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q39D")) {
					((PDTextField) pdField).setValue(form.getAaemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40A")) {
					((PDTextField) pdField).setValue(form.getTcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40B")) {
					((PDTextField) pdField).setValue(form.getTctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40C")) {
					((PDTextField) pdField).setValue(form.getTcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q40D")) {
					((PDTextField) pdField).setValue(form.getTcemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41A")) {
					((PDTextField) pdField).setValue(form.getBcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41B")) {
					((PDTextField) pdField).setValue(form.getBctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41C")) {
					((PDTextField) pdField).setValue(form.getBcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q41D")) {
					((PDTextField) pdField).setValue(form.getBcemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42A")) {
					((PDTextField) pdField).setValue(form.getOcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42B")) {
					((PDTextField) pdField).setValue(form.getOctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42C")) {
					((PDTextField) pdField).setValue(form.getOcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q42D")) {
					((PDTextField) pdField).setValue(form.getOcemail());
				}

				/* SECTION E */
				if (pdfFieldName.equalsIgnoreCase("Q43A")) {
					((PDTextField) pdField).setValue(form.getSigname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43B")) {
					((PDTextField) pdField).setValue(form.getSigtitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43C")) {
					((PDTextField) pdField).setValue(form.getSigphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43D")) {
					((PDTextField) pdField).setValue(form.getSigext());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43E")) {
					((PDTextField) pdField).setValue(form.getSigemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q43G")) {
					((PDTextField) pdField).setValue(form.getSigdt().toString());
				}

				if (pdfFieldName.equalsIgnoreCase("Q44")) {
					((PDTextField) pdField).setValue(form.getSigsuggestion());
				}
			}

			if (pdField instanceof PDComboBox) {

				// 4a
				if (pdfFieldName.equalsIgnoreCase("Q4A")) {
					((PDComboBox) pdField).setValue(form.getPracticetype());
				}

				// 17
				if (pdfFieldName.equalsIgnoreCase("Q26A")) {
					((PDComboBox) pdField).setValue(form.getOthermethod());
				}

				// 19
				if (pdfFieldName.equalsIgnoreCase("Q29")) {
					((PDComboBox) pdField).setValue(form.getEhremrsystem());
				}
				
				// 36
				if (pdfFieldName.equalsIgnoreCase("Q36")) {
					((PDComboBox) pdField).setValue(form.getAdtfeeds());
				}

				// 34
				if (pdfFieldName.equalsIgnoreCase("Q34")) {
					((PDComboBox) pdField).setValue(form.getOnccertified());
				}
				
				// 37
				if (pdfFieldName.equalsIgnoreCase("Q37")) {
					((PDComboBox) pdField).setValue(form.getInfoonadtfeeds());
				}

			}

			if (pdField instanceof PDCheckBox) {
			
				// 8
				if (pdfFieldName.equalsIgnoreCase("Q8A")
						&& form.getGoalusecase().contains("Reduce hospital readmissions")) {
					((PDCheckBox) pdField).check();
				}


				if (pdfFieldName.equalsIgnoreCase("Q8C")
						&& form.getGoalusecase().contains("Facilitate care coordination")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8B")
						&& form.getGoalusecase().contains("Reduce unnecessary testing")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8E")
						&& form.getGoalusecase().contains("Improve administrative efficiency")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8D") && 
						form.getGoalusecase().contains("Reduce costs")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q8F1")
						&& form.getGoalusecase().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 11
				if (pdfFieldName.equalsIgnoreCase("Q11")) {

					((PDCheckBox) pdField).check();

				}
				
				if (pdfFieldName.equalsIgnoreCase("Q19")) {

					((PDCheckBox) pdField).check();

				}

				// 16			
				
				if (pdfFieldName.equalsIgnoreCase("Q16A")
						&& form.getCategory2usecase().contains("Accountable Care Organization")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16H")
						&& form.getCategory2usecase().contains("Large Federally Qualified Health Center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16O")
						&& form.getCategory2usecase().contains("Skilled nursing facility")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16B")
						&& form.getCategory2usecase().contains("Ambulance and emergency response")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16I")
						&& form.getCategory2usecase().contains("Large hospital/health system**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16P")
						&& form.getCategory2usecase().contains("Small ambulatory practice (3-9)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16C")
						&& form.getCategory2usecase().contains("Ambulatory surgery center")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16J")
						&& form.getCategory2usecase().contains("Large long-term care facility (500+ beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16Q")
						&& form.getCategory2usecase().contains("Small behavioral health (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16D")
						&& form.getCategory2usecase().contains("Home health, LTSS")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16K")
						&& form.getCategory2usecase().contains("MassHealth Behavioral Health Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16R")
						&& form.getCategory2usecase().contains("Small Community health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16E")
						&& form.getCategory2usecase().contains("Large ambulatory practice (50+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16L")
						&& form.getCategory2usecase().contains("MassHealth Community Service Agency")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16S")
						&& form.getCategory2usecase().contains("Small Federally qualified health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16F")
						&& form.getCategory2usecase().contains("Large behavioral health (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16M")
						&& form.getCategory2usecase().contains("MassHealth LTSS Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16T")
						&& form.getCategory2usecase().contains("Small hospital**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16G")
						&& form.getCategory2usecase().contains("Large community health center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16N")
						&& form.getCategory2usecase().contains("Medium ambulatory practice (10-49)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16U")
						&& form.getCategory2usecase().contains("Small long-term care facility (<500 beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16W1")
						&& form.getCategory2usecase().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q16V")
						&& form.getCategory2usecase().contains("Very small ambulatory practice (1-2)*")) {
					((PDCheckBox) pdField).check();
				}

				
				// 24
				if (pdfFieldName.equalsIgnoreCase("Q24A")
						&& form.getCategory2usecasereceiver().contains("Accountable Care Organization")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24H")
						&& form.getCategory2usecasereceiver().contains("Large Federally Qualified Health Center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24O")
						&& form.getCategory2usecasereceiver().contains("Skilled nursing facility")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24B")
						&& form.getCategory2usecasereceiver().contains("Ambulance and emergency response")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24I")
						&& form.getCategory2usecasereceiver().contains("Large hospital/health system**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24P")
						&& form.getCategory2usecasereceiver().contains("Small ambulatory practice (3-9)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24C")
						&& form.getCategory2usecasereceiver().contains("Ambulatory surgery center")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24J")
						&& form.getCategory2usecasereceiver().contains("Large long-term care facility (500+ beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24Q")
						&& form.getCategory2usecasereceiver().contains("Small behavioral health (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24D")
						&& form.getCategory2usecasereceiver().contains("Home health, LTSS")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24K")
						&& form.getCategory2usecasereceiver().contains("MassHealth Behavioral Health Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24R")
						&& form.getCategory2usecasereceiver().contains("Small Community health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24E")
						&& form.getCategory2usecasereceiver().contains("Large ambulatory practice (50+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24L")
						&& form.getCategory2usecasereceiver().contains("MassHealth Community Service Agency")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24S")
						&& form.getCategory2usecasereceiver().contains("Small Federally qualified health center (<10)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24F")
						&& form.getCategory2usecasereceiver().contains("Large behavioral health (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24M")
						&& form.getCategory2usecasereceiver().contains("MassHealth LTSS Community Partner")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24T")
						&& form.getCategory2usecasereceiver().contains("Small hospital**")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24G")
						&& form.getCategory2usecasereceiver().contains("Large community health center (10+)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24N")
						&& form.getCategory2usecasereceiver().contains("Medium ambulatory practice (10-49)*")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24U")
						&& form.getCategory2usecasereceiver().contains("Small long-term care facility (<500 beds)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24W1")
						&& form.getCategory2usecasereceiver().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q24V")
						&& form.getCategory2usecasereceiver().contains("Very small ambulatory practice (1-2)*")) {
					((PDCheckBox) pdField).check();
				}
				
				// 15
				if (pdfFieldName.equalsIgnoreCase("Q15") && form.getCat2ucsender().contains("Sending")) {
					((PDCheckBox) pdField).check();
				}

				// 23
				if (pdfFieldName.equalsIgnoreCase("Q23")
						&& form.getCat2ucreceiver().contains("Receiving")) {
					((PDCheckBox) pdField).check();
				}

				// 12
				
				
				if (pdfFieldName.equalsIgnoreCase("Q12A")
						&& form.getInfotype().contains("Discharge Summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12B")
						&& form.getInfotype().contains("Admission, Discharge, Transfer (ADT)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12C") && form.getInfotype().contains("Referral summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12D") && form.getInfotype().contains("Summary of care")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12E")
						&& form.getInfotype().contains("General assessment")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q12F1")
						&& form.getInfotype().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 20
				if (pdfFieldName.equalsIgnoreCase("Q20A")
						&& form.getInfotypereceiver().contains("Discharge Summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20B")
						&& form.getInfotypereceiver().contains("Admission, Discharge, Transfer (ADT)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20C")
						&& form.getInfotypereceiver().contains("Referral summary")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20D")
						&& form.getInfotypereceiver().contains("Summary of care")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20E")
						&& form.getInfotypereceiver().contains("General assessment")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q20F1")
						&& form.getInfotypereceiver().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 13
				
				if (pdfFieldName.equalsIgnoreCase("Q13A")
						&& form.getInfoformat().contains("CCD")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13B") && form.getInfoformat().contains("C-CDA/CDA")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13D")
						&& form.getInfoformat().contains("Secure message")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13C") && form.getInfoformat().contains("PDF")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13E1")
						&& form.getInfoformat().contains("HL7 message (specify type)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q13F1")
						&& form.getInfoformat().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 21
				if (pdfFieldName.equalsIgnoreCase("Q21A") && form.getInfoformatreceiver().contains("CCD")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21B") && form.getInfoformatreceiver().contains("C-CDA/CDA")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21D")
						&& form.getInfoformatreceiver().contains("Secure message")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21C") && form.getInfoformatreceiver().contains("PDF")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21E1")
						&& form.getInfoformatreceiver().contains("HL7 message (specify type)")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q21F1")
						&& form.getInfoformatreceiver().contains("Other (please specify)")) {
					((PDCheckBox) pdField).check();
				}

				// 24
				if (pdfFieldName.equalsIgnoreCase("Q35A")
						&& form.getConnectingprovider().contains("via Mass HIway Webmail")) {
					((PDCheckBox) pdField).check();
				}

				if (pdfFieldName.equalsIgnoreCase("Q35B1")
						&& form.getConnectingprovider().contains("Via some other method (please specify)")) {
					((PDCheckBox) pdField).check();
				}
			}

			if (pdField instanceof PDRadioButton) {

				// 25
				if (pdfFieldName.equalsIgnoreCase("Q25")) {
					String value0 = "0-24%";
					String value1 = "25-49%";
					String value2 = "50-74%";
					String value3 = "75-99%";
					String value4 = "100%";
					
				 if (form.getMsgpercentage().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getMsgpercentage().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getMsgpercentage().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
					
					if (form.getMsgpercentage().equalsIgnoreCase(value3)) {
						((PDRadioButton) pdField).setValue("3");
					}
					
					if (form.getMsgpercentage().equalsIgnoreCase(value4)) {
						((PDRadioButton) pdField).setValue("4");
					}
				}

				// 27
				if (pdfFieldName.equalsIgnoreCase("Q27")) {
					String value0 = "Less than 100 Direct Messages";
					String value1 = "Between 100 and 1,000 Direct Messages";
					String value2 = "Over 1,000 Direct Messages";

					if (form.getTransac_no().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getTransac_no().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getTransac_no().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
				}

				// 28
				if (pdfFieldName.equalsIgnoreCase("Q28")) {
					String value0 = "Yes";
					String value1 = "No";

					if (form.getFreeassistance().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getFreeassistance().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}

				// 32
				if (pdfFieldName.equalsIgnoreCase("Q32")) {
					String value0 = "Directly to the Mass HIway";
					String value1 = "via a HISP other than the Mass HIway";

					if (form.getConnectingemr().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getConnectingemr().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}

				// 33

				if (pdfFieldName.equalsIgnoreCase("Q33")) {
					String value0 = "Directly to the Mass HIway";
					String value1 = "via a HISP other than the Mass HIway";

					if (form.getReceivingusecase().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getReceivingusecase().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}
				//
				/*if (pdfFieldName.equalsIgnoreCase("Q33")) {
					String value0 = "Directly to the Mass HIway";
					String value1 = "via a HISP other than the Mass HIway";

					if (form.getReceivingusecase().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getReceivingusecase().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}*/
				//37
				if (pdfFieldName.equalsIgnoreCase("Q37")) {
					String value0 = "Vendor1";
					String value1 = "Vendor2";
					String value2 = "Vendor3";

					if (form.getInfoonadtfeeds().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getInfoonadtfeeds().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getInfoonadtfeeds().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
				}

				// SecD - TC
				if (pdfFieldName.equalsIgnoreCase("Q40E")) {
					String value0 = "In-house";
					String value1 = "Technical integrator";

					if (form.getTcrole().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getTcrole().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
				}

				// SecD - BC
				if (pdfFieldName.equalsIgnoreCase("Q41E")) 
				{
					String value0 = "Clinical leadership";
					String value1 = "Operations leadership";
					String value2 = "HIE leadership / owner";

					if (form.getBcrole().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}

					if (form.getBcrole().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}

					if (form.getBcrole().equalsIgnoreCase(value2)) {
						((PDRadioButton) pdField).setValue("2");
					}
				}
			}
		}

		//Flatten the document
		acroForm.flatten();
		
		// Saving the document
		doc.save(pathToSave);

		// Closing the document
		doc.close();

		return true;

	}

	public boolean generatePDFEx(AttestationException form, String pathToSave, String templatePath) throws IOException {
		PDDocument finalDoc = new PDDocument();
		File yearFormTemplate = new File(templatePath);

		PDDocument doc = new PDDocument().load(yearFormTemplate);
		doc.setAllSecurityToBeRemoved(true);

		PDDocumentCatalog docCatalog = doc.getDocumentCatalog();
		PDAcroForm acroForm = docCatalog.getAcroForm();

		acroForm.setXFA(null);

		Iterator<PDField> fieldIterator = acroForm.getFieldIterator();

		while (fieldIterator.hasNext()) {
			PDField pdField = fieldIterator.next();

			String pdfFieldName = pdField.getPartialName().replace("[0]", "");
			
			System.out.println("PDF field NAME : " + pdfFieldName);
			
			if (pdField instanceof PDTextField) {

				/* SECTION A */
				if (pdfFieldName.equalsIgnoreCase("Q1")) {
					((PDTextField) pdField).setValue(form.getOrgname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2A")) {
					((PDTextField) pdField).setValue(form.getStaddr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2B")) {
					((PDTextField) pdField).setValue(form.getCity());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2C")) {
					((PDTextField) pdField).setValue(form.getState());
				}

				if (pdfFieldName.equalsIgnoreCase("Q2D")) {
					((PDTextField) pdField).setValue(form.getZipcode());
				}

				if (pdfFieldName.equalsIgnoreCase("Q4")) {
					((PDTextField) pdField).setValue(form.getExplaination());
				}
				if (pdfFieldName.equalsIgnoreCase("Q6")) {
					((PDTextField) pdField).setValue(form.getUnabletomeethiwayreq());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q7")) {
					((PDTextField) pdField).setValue(form.getPlantomeethiwayreq());
				}
				

				/* SECTION B */
				if (pdfFieldName.equalsIgnoreCase("Q10")) {
					((PDTextField) pdField).setValue(form.getNameemr());
				}

				if (pdfFieldName.equalsIgnoreCase("Q11")) {
					((PDTextField) pdField).setValue(form.getVersionemr());
				}
				
				/* SECTION C */
				
				if (pdfFieldName.equalsIgnoreCase("Q12A")) {
					((PDTextField) pdField).setValue(form.getEnsintiative());
				}
				
//				if (pdfFieldName.equalsIgnoreCase("Q13")) {
//					((PDTextField) pdField).setValue(form.getInfoonadtfeeds());
//				}
				
				if (pdfFieldName.equalsIgnoreCase("Q14")) {
					((PDTextField) pdField).setValue(form.getDateofsubmission());
				}

				/* SECTION D */
				if (pdfFieldName.equalsIgnoreCase("Q15A")) {
					((PDTextField) pdField).setValue(form.getAaname());
				}
				if (pdfFieldName.equalsIgnoreCase("Q15B")) {
					((PDTextField) pdField).setValue(form.getAatitle());
				}
				if (pdfFieldName.equalsIgnoreCase("Q15C")) {
					((PDTextField) pdField).setValue(form.getAaphone());
				}
				if (pdfFieldName.equalsIgnoreCase("Q15D")) {
					((PDTextField) pdField).setValue(form.getAaext());
				}
				if (pdfFieldName.equalsIgnoreCase("Q15E")) {
					((PDTextField) pdField).setValue(form.getAaemail());
				}

				if (pdfFieldName.equalsIgnoreCase("Q16A")) {
					((PDTextField) pdField).setValue(form.getOcname());
				}

				if (pdfFieldName.equalsIgnoreCase("Q16B")) {
					((PDTextField) pdField).setValue(form.getOctitle());
				}

				if (pdfFieldName.equalsIgnoreCase("Q16C")) {
					((PDTextField) pdField).setValue(form.getOcphone());
				}

				if (pdfFieldName.equalsIgnoreCase("Q16E")) {
					((PDTextField) pdField).setValue(form.getOcemail());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q17")) {
					((PDTextField) pdField).setValue(form.getSuggestions());
				}
			}

			if (pdField instanceof PDComboBox) {

				// 3
				if (pdfFieldName.equalsIgnoreCase("Q3")) {
					((PDComboBox) pdField).setValue(form.getPracticetype());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q5A")) {
					((PDComboBox) pdField).setValue(form.getPlana());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q9")) {
					((PDComboBox) pdField).setValue(form.getEhremrsystem());
				}
				if (pdfFieldName.equalsIgnoreCase("Q12")) {
					((PDComboBox) pdField).setValue(form.getAdtfeeds());
				}
				
				if (pdfFieldName.equalsIgnoreCase("Q13")) {
					((PDComboBox) pdField).setValue(form.getInfoonadtfeeds());
				}

				
			}
			
			if (pdField instanceof PDRadioButton) 
			{
				if (pdfFieldName.equalsIgnoreCase("Q8")) 
				{
					String value0 = "Yes";
					String value1 = "No";
					
					if (form.getPporgassisstance().equalsIgnoreCase(value0)) {
						((PDRadioButton) pdField).setValue("0");
					}
	
					if (form.getPporgassisstance().equalsIgnoreCase(value1)) {
						((PDRadioButton) pdField).setValue("1");
					}
	
					
				}
			}
			
			if (pdField instanceof PDCheckBox) {
							
				// 5b
				if (pdfFieldName.equalsIgnoreCase("CheckBox1")
						&& form.getPlanb().contains("Engaged in Direct exchange, but not via the HIway")) {
					((PDCheckBox) pdField).check();
				}
				if (pdfFieldName.equalsIgnoreCase("CheckBox2")
						&& form.getPlanb().contains("Technical issue")) {
					((PDCheckBox) pdField).check();
				}
				if (pdfFieldName.equalsIgnoreCase("CheckBox3")
						&& form.getPlanb().contains("Unable to identify benefical use case")) {
					((PDCheckBox) pdField).check();
				}
				if (pdfFieldName.equalsIgnoreCase("CheckBox4")
						&& form.getPlanb().contains("Resources diverted to EMR transition")) {
					((PDCheckBox) pdField).check();
				}
				if (pdfFieldName.equalsIgnoreCase("CheckBox5")
						&& form.getPlanb().contains("Unable to identify benefical trading partner")) {
					((PDCheckBox) pdField).check();
				}
				if (pdfFieldName.equalsIgnoreCase("CheckBox6")
						&& form.getPlanb().contains("Unaware of requirement")) {
					((PDCheckBox) pdField).check();
				}
				
			}
			
			
			if (pdField instanceof PDListBox) {
				
				//5A
				if (pdfFieldName.equalsIgnoreCase("Q5A")) 
				{
					((PDListBox) pdField).setValue(form.getPlana());
				}
				
				//5B
				if (pdfFieldName.equalsIgnoreCase("Q5B")) 
				{
					System.out.println(form.getPlanb());
					List<String> list = Arrays.asList("Technical issue", "Unaware of requirement", "Unaware of requirement");
					((PDListBox) pdField).setValue(list);
				}
				
			}
		}

		//Flatten the document
		acroForm.flatten();
		
		// Saving the document
		doc.save(pathToSave);

		// Closing the document
		doc.close();

		return true;
	}
}
