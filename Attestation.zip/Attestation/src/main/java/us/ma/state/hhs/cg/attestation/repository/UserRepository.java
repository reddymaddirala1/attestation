package us.ma.state.hhs.cg.attestation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import us.ma.state.hhs.cg.attestation.model.AttestationUser;

public interface UserRepository extends JpaRepository<AttestationUser, Long>{

}
