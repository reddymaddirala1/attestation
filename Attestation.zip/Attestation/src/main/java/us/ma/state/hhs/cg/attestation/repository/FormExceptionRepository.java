package us.ma.state.hhs.cg.attestation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import us.ma.state.hhs.cg.attestation.model.AttestationException;

public interface FormExceptionRepository extends JpaRepository<AttestationException, Long>{

}
