package us.ma.state.hhs.cg.attestation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import us.ma.state.hhs.cg.attestation.model.AttestationYear5;

public interface FormYear5Repository extends JpaRepository<AttestationYear5, Long>{

}
