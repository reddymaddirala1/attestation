package us.ma.state.hhs.cg.attestation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import us.ma.state.hhs.cg.attestation.model.AttestationException;
import us.ma.state.hhs.cg.attestation.model.AttestationYear3and4;
import us.ma.state.hhs.cg.attestation.model.AttestationYear5;
import us.ma.state.hhs.cg.attestation.repository.FormExceptionRepository;
import us.ma.state.hhs.cg.attestation.repository.FormYear3and4Repository;
import us.ma.state.hhs.cg.attestation.repository.FormYear5Repository;

@Service
public class FormYearServiceImpl implements FormYearService{
	
	@Autowired
	private FormYear3and4Repository year3and4Repository;
	
	@Autowired
	private FormYear5Repository year5Repository;
	
	@Autowired
	private FormExceptionRepository exceptionRepository;

	@Override
	public AttestationYear3and4 saveYear3and4Data(AttestationYear3and4 yearForm) {
		return year3and4Repository.save(yearForm);
	}

	@Override
	public AttestationYear3and4 getYear3and4FormData(long id) {
		return year3and4Repository.findById(id).get();
	}

	@Override
	public boolean checkAccCodeExistsY3and4(long accessCode) {
		return year3and4Repository.existsById(accessCode);
	}

	
	
	@Override
	public AttestationYear5 saveYear5Data(AttestationYear5 yearForm) {
		return year5Repository.save(yearForm);
	}

	@Override
	public AttestationYear5 getYear5FormData(long id) {
		return year5Repository.findById(id).get();
	}

	@Override
	public boolean checkAccCodeExistsY5(long accessCode) {
		return year5Repository.existsById(accessCode);
	}

	
	
	
	@Override
	public AttestationException saveExceptionData(AttestationException yearForm) {
		return exceptionRepository.save(yearForm);
	}

	@Override
	public AttestationException getExceptionFormData(long id) {
		return exceptionRepository.findById(id).get();
	}
	
	@Override
	public boolean checkAccCodeExistsEx(long accessCode) {
		return exceptionRepository.existsById(accessCode);
	}

}
