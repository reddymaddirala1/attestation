package us.ma.state.hhs.cg.attestation.model;

import java.util.List;

public class AjaxResponse {
    String msg;
    List<String> result;
    
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public List<String> getResult() {
		return result;
	}
	public void setResult(List<String> result) {
		this.result = result;
	}
    
    
}
