package us.ma.state.hhs.cg.attestation.controller;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.LongStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import us.ma.state.hhs.cg.attestation.model.AttestationUser;
import us.ma.state.hhs.cg.attestation.service.MailClient;
import us.ma.state.hhs.cg.attestation.service.UserService;
 
@Controller
public class RequestController {
	
	private static final Logger logger = LoggerFactory.getLogger(RequestController.class);
		
	private final long MIN_RANGE = 100000;
	private final long MAX_RANGE = 999999;
	private final String STAUTS_PENDING = "Pending";
	
	@Autowired
    private UserService userService;
	
	@Autowired
	private MailClient mailClient;
    
	@Value("${google.recaptcha.site}")
	private String recaptchaSiteKey;
	
	@Value("${google.recaptcha.enable}")
	private boolean enableRecaptcha;
	
	@Value("${google.tag.manage.id}")
	private String tagmanagerId;
	
	/*
	 * Landing page controller
	 */
    @RequestMapping("/request")
    String request(Model model){
    	
    	logger.info("Requesting Attestation Access code");
    	model.addAttribute("gtagid",tagmanagerId);
        return "request";
    }
    
    /*
	 * Landing page controller
	 */
    @RequestMapping("/")
    String root(Model model){
    	
    	logger.info("requesting attestation context path");
    	model.addAttribute("gtagid",tagmanagerId);
        return "request";
    }

	/*
	 * activate page controller
	 */
    @RequestMapping("/activate")
    String activate(Model model){
    	
    	logger.info("Activate Page");
    	
    	model.addAttribute("gtagid",tagmanagerId);

    	if(enableRecaptcha){
    		model.addAttribute("captchaSiteKey",recaptchaSiteKey);
    		model.addAttribute("captchaEnable",true);
    	}else{
    		model.addAttribute("captchaSiteKey","");
    		model.addAttribute("captchaEnable",false);

    	}
        return "activate";
    }
    
	/*
	 * register controller
	 */
    @RequestMapping("/register")
    String register(@RequestParam("name") String name, 
    		@RequestParam("email") String email,
    		Model model){

    	logger.info("Registering for : ");
    	logger.info("User : " + name);
    	logger.info("Email : " + email);
    	
    	model.addAttribute("gtagid",tagmanagerId);

    	//Generate random number - access code
    	long randomNum = ThreadLocalRandom.current().nextLong(MIN_RANGE, MAX_RANGE);
    	
    	//Check if randomNum generated already exists
    	boolean isCodeExists = true;
    	while(isCodeExists) {
    		isCodeExists = userService.checkAccessCodeExists(randomNum);
    		
    		//Generate new access code
    		if(isCodeExists) {
    			randomNum = ThreadLocalRandom.current().nextLong(MIN_RANGE, MAX_RANGE);
    		}
    	}
    	
    	logger.info("Access code generated : " + randomNum);
    	
    	//Form the attestation user to be loaded
    	AttestationUser userModel = new AttestationUser(name, email, randomNum, STAUTS_PENDING, new Date(), null, null);
    				
    	//Insert the table
    	boolean isSuccess = userService.saveUser(userModel);
    	
    	logger.info("Save Status : " + isSuccess);

    	if(isSuccess) {
    		
    		//Send email with access code
    		boolean isMailSuccess = mailClient.sendAccessCode(email, Long.toString(randomNum));
    		
        	logger.info("Email Status : " + isMailSuccess);

    		if (isMailSuccess) {
	        	model.addAttribute("email",email);
	            return "regConfirmation";
    		}else {
    			return "error";
    		}
    	}else {
    		return "error";
    	}
    }
    
}