package us.ma.state.hhs.cg.attestation.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import us.ma.state.hhs.cg.attestation.model.AttestationException;
import us.ma.state.hhs.cg.attestation.model.AttestationUser;
import us.ma.state.hhs.cg.attestation.model.AttestationYear3and4;
import us.ma.state.hhs.cg.attestation.model.AttestationYear5;
import us.ma.state.hhs.cg.attestation.service.CaptchaService;
import us.ma.state.hhs.cg.attestation.service.FormYearService;
import us.ma.state.hhs.cg.attestation.service.MailClient;
import us.ma.state.hhs.cg.attestation.service.UserService;

@Controller
public class AccessController {

	private static final Logger logger = LoggerFactory.getLogger(AccessController.class);

	@Autowired
    private UserService userService;
	
	@Autowired
    private FormYearService formService;  
	
	@Autowired
	private CaptchaService captchaService;    
	
	@Value("${google.recaptcha.site}")
	private String recaptchaSiteKey;
	
	@Value("${google.recaptcha.enable}")
	private boolean enableRecaptcha;
	
	@Value("${google.tag.manage.id}")
	private String tagmanagerId;
	
    @RequestMapping("/accessform")
    String accessform(@RequestParam(name="accesscode", required=false) String accesscode, 
    					@RequestParam(name="year", required=false) String year, 
    					@RequestParam(name="g-recaptcha-response", required=false) String recaptchaResponse,
    					HttpServletRequest request, Model model){
    			
    	model.addAttribute("gtagid",tagmanagerId);

    	if(null == accesscode){
			model.addAttribute("isActivateError", false);
	    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);
    		return "redirect:activate";
    	}
    	
    	String copyAccesscode = accesscode;

    	logger.info("** Access Form ***");
     	logger.info("Access Code: " + accesscode);
     	logger.info("Form: " + year);
     	
    	if(enableRecaptcha){
	    	String ip = request.getRemoteAddr();
	    	
	    	logger.info("IP: " + ip);
	
	    	String captchaVerifyMessage = 
	    	      captchaService.verifyRecaptcha(ip, recaptchaResponse);   	
	    	
    		model.addAttribute("captchaEnable",true);

			if ( !captchaVerifyMessage.equalsIgnoreCase("success")) {
				
		    	logger.info("--- Error: Recaptcha Failed  ---- ");

				model.addAttribute("isActivateError", true);
				model.addAttribute("errmsg", captchaVerifyMessage);
		    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);
	
				return "activate";
			}			
    	}else{
    		model.addAttribute("captchaEnable",false);
    	}
		
		// Validate Access Code
		if(accesscode.trim().isEmpty()) {
			
	    	logger.info("--- Error: The Access Code field is required --- ");

			model.addAttribute("isActivateError", true);
			model.addAttribute("errmsg", "The Access Code field is required");
	    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);

			return "activate";
		}
		
		// check for special character
		if(accesscode.length()< 7 || accesscode.charAt(6)!='_')
		{
	    	logger.info("--- Error: The Access Code does not exists --- ");

			model.addAttribute("isActivateError", true);
			model.addAttribute("errmsg", "The Access Code " + copyAccesscode + " does not exists");
	    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);

			return "activate";
		}
		
		String accessCodeEmail= accesscode.substring(7);
		accesscode = accesscode.substring(0,6);
		
		// Check if access code exists
		boolean checkAccExists = userService.checkAccessCodeExists(Long.parseLong(accesscode));
		if(!checkAccExists) {
			
	    	logger.info("--- Error: The Access Code does not exists --- ");

			model.addAttribute("isActivateError", true);
			model.addAttribute("errmsg", "The Access Code " + copyAccesscode + " does not exists");
	    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);

			return "activate";
		}
				
		String email = userService.getEmail(Long.parseLong(accesscode));
		String emailFirstPart= email.split("@")[0];;

		if(!accessCodeEmail.equalsIgnoreCase(emailFirstPart)) {
	    	logger.info("--- Error: The Access Code does not exists --- ");

			model.addAttribute("isActivateError", true);
			model.addAttribute("errmsg", "The Access Code " + copyAccesscode + " does not exists");
	    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);

			return "activate";
		}
		
		AttestationUser user = userService.getUser(Long.parseLong(accesscode));
		
		// Validate Status
		String status = user.getStatus();
		if(status.equalsIgnoreCase("Submitted")) {
			
	    	logger.info("--- Error: Access Code has Expired: Request new Access Code --- ");

			model.addAttribute("isActivateError", true);
			model.addAttribute("errmsg", "Access Code " + copyAccesscode + " has Expired: Request new Access Code");
	    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);

			return "activate";
		}
		
		// Validate Year
		String associatedForm = user.getAssociatedForm();
		logger.info("** associatedForm ***" + associatedForm);
		if(!(associatedForm == null || associatedForm.equalsIgnoreCase(""))) {
			if(!year.equalsIgnoreCase(associatedForm)) {
				
		    	logger.info("--- Error: Wrong form --- ");

				model.addAttribute("isActivateError", true);
				model.addAttribute("errmsg", "Access Code " + copyAccesscode + " is already linked to " + associatedForm + " form");
		    	model.addAttribute("captchaSiteKey",recaptchaSiteKey);

				return "activate";
			}
		}

		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		Date date = new Date();
		String sigDate = sdf.format(date);

		model.addAttribute("sigDate", sigDate);
		model.addAttribute("accCode", accesscode);
		model.addAttribute("isActivateError", false);
				
		String yearForm = "";
		
		if(year.equalsIgnoreCase("year3and4")) 
		{			
            boolean isSavedAlready = formService.checkAccCodeExistsY3and4(Long.parseLong(accesscode));
			AttestationYear3and4 year3and4model = getYear3and4Model(isSavedAlready, Long.parseLong(accesscode));
			model.addAttribute("year3and4model", year3and4model);
			yearForm = "year3and4";
		}else if(year.equalsIgnoreCase("year5"))
		{		
            boolean isSavedAlready = formService.checkAccCodeExistsY5(Long.parseLong(accesscode));
            AttestationYear5 year5model = getYear5Model(isSavedAlready, Long.parseLong(accesscode));
			model.addAttribute("year5model", year5model);
			yearForm = "year5";
		}
		else if(year.equalsIgnoreCase("exception"))
		{		
            boolean isSavedAlready = formService.checkAccCodeExistsEx(Long.parseLong(accesscode));
			AttestationException yearExmodel = getYearExModel(isSavedAlready, Long.parseLong(accesscode));
			model.addAttribute("exceptionmodel", yearExmodel);
			yearForm = "exception";
		}
		else {
			yearForm = "error";
		}
		
		return yearForm;    	
    }
    
    private AttestationYear3and4 getYear3and4Model(boolean isSaved, long accCode) 
    {
		AttestationYear3and4 year3and4model;
		
		if(isSaved) {
			year3and4model = formService.getYear3and4FormData(accCode);
			
			if(year3and4model.getGoalusecase() == null) {
				year3and4model.setGoalusecase("");
			}
			if(year3and4model.getCategory2usecase() == null) {
				year3and4model.setCategory2usecase("");
			}
			if(year3and4model.getInfotype() == null) {
				year3and4model.setInfotype("");
			}			
			if (year3and4model.getInfotypereceiver()== null){
				year3and4model.setInfotypereceiver("");
			}
			if(year3and4model.getInfoformat() == null) {
				year3and4model.setInfoformat("");
			}			
			if(year3and4model.getInfoformatreceiver() == null)
			{
				year3and4model.setInfoformatreceiver("");
			}			
			if(year3and4model.getCategory2usecasereceiver()== null)
			{
				year3and4model.setCategory2usecasereceiver("");
			}			
			if(year3and4model.getConnectingprovider() == null) {
				year3and4model.setConnectingprovider("");
			}							
		}else {
			year3and4model = new AttestationYear3and4();
			year3and4model.setGoalusecase("");
			year3and4model.setCategory2usecase("");
			year3and4model.setInfotypereceiver("");
			year3and4model.setInfotype("");
			year3and4model.setInfoformat("");
			year3and4model.setInfoformatreceiver("");
			year3and4model.setCategory2usecasereceiver("");
			year3and4model.setConnectingprovider("");
		}
		
		return year3and4model;
    }
    
    
    private AttestationYear5 getYear5Model(boolean isSaved, long accCode) 
    {
		AttestationYear5 year5model;
		
		if(isSaved) {
			year5model = formService.getYear5FormData(accCode);
			
			if(year5model.getGoalusecase() == null) {
				year5model.setGoalusecase("");
			}
			if(year5model.getCategory2usecase() == null) {
				year5model.setCategory2usecase("");
			}
			if(year5model.getInfotype() == null) {
				year5model.setInfotype("");
			}			
			if (year5model.getInfotypereceiver()== null){
				year5model.setInfotypereceiver("");
			}
			if(year5model.getInfoformat() == null) {
				year5model.setInfoformat("");
			}			
			if(year5model.getInfoformatreceiver() == null)
			{
				year5model.setInfoformatreceiver("");
			}			
			if(year5model.getCategory2usecasereceiver()== null)
			{
				year5model.setCategory2usecasereceiver("");
			}			
			if(year5model.getConnectingprovider() == null) {
				year5model.setConnectingprovider("");
			}							
		}else {
			year5model = new AttestationYear5();
			year5model.setGoalusecase("");
			year5model.setCategory2usecase("");
			year5model.setInfotypereceiver("");
			year5model.setInfotype("");
			year5model.setInfoformat("");
			year5model.setInfoformatreceiver("");
			year5model.setCategory2usecasereceiver("");
			year5model.setConnectingprovider("");
		}
		
		return year5model;
    }
    
    
    private AttestationException getYearExModel(boolean isSaved, long accCode) 
    {
		AttestationException yearExmodel;
		
		if(isSaved) {
			yearExmodel = formService.getExceptionFormData(accCode);
			
		if(yearExmodel.getPlanb() == null) {
				yearExmodel.setPlanb("");
		}
		if(yearExmodel.getAdtfeeds() == null) {
			yearExmodel.setAdtfeeds("");
	}
		}else {
			yearExmodel = new AttestationException();
			yearExmodel.setPlanb("");
			yearExmodel.setAdtfeeds("");
		}
		
		return yearExmodel;
    }
}
