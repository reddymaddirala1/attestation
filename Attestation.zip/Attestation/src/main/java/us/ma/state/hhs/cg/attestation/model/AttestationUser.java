package us.ma.state.hhs.cg.attestation.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
		name = "attestationuser_2021"
	)
public class AttestationUser {

	@Column(name = "NAME")
	private String userName;

	@Column(name = "EMAILADDRESS")
	private String emailAddr;

	@Id
	@Column(name = "VERIFICATIONCODE")
	private long verificationCode;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "CREATION_DT")
	private Date creationDt;

	@Column(name = "SUBMISSION_DT")
	private Date submissionDt;
	
	@Column(name = "ASSOCIATED_FORM")
	private String associatedForm;
	
	public AttestationUser() {

	}

	public AttestationUser(String userName, String emailAddr, long verificationCode, String status, Date creationDt,
			Date submissionDt, String associatedForm) {
		super();
		this.userName = userName;
		this.emailAddr = emailAddr;
		this.verificationCode = verificationCode;
		this.status = status;
		this.creationDt = creationDt;
		this.submissionDt = submissionDt;
		this.associatedForm = associatedForm;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public long getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(long verificationCode) {
		this.verificationCode = verificationCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreationDt() {
		return creationDt;
	}

	public void setCreationDt(Date creationDt) {
		this.creationDt = creationDt;
	}

	public Date getSubmissionDt() {
		return submissionDt;
	}

	public void setSubmissionDt(Date submissionDt) {
		this.submissionDt = submissionDt;
	}

	
	public String getAssociatedForm() {
		return associatedForm;
	}

	public void setAssociatedForm(String associatedForm) {
		this.associatedForm = associatedForm;
	}

	@Override
	public String toString() {
		return "AttestationUser [userName=" + userName + ", emailAddr=" + emailAddr + ", verificationCode="
				+ verificationCode + ", status=" + status + ", creationDt=" + creationDt + ", submissionDt="
				+ submissionDt + ", associatedForm=" + associatedForm + "]";
	}


}
