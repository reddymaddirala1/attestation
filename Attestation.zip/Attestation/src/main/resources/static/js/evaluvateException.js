$(document).ready(function() {

	// Section A -- 3 -- Practice type
	$('#secA-input-three').change(function() {
		var practiceType = $('#secA-input-three :selected').val();

		if (practiceType == 'Acute Care Hospital') {
			$("#reveal-twelve").css("display", "block");
			$('input[name="secC-radio-twelve"]').prop('checked', false);
			$('#err-msg-twelve').hide();
		} else {
			$("#reveal-twelve").css("display", "none");
			$("#reveal-twelve-a").css("display", "none");
			$("#reveal-thirteen").css("display", "none");
			$('input[name="secC-radio-twelve"]').prop('checked', false);
			$('#secC-input-twelve-a').val('');
			//$('#secC-input-thirteen').val('');
			$("#secC-input-thirteen").prop('selectedIndex', 0);
			$('#secC-input-fourteen').val('');
		}

	})

	// Section B -- 9 -- EHREMR - Yes No
	$('input[type="radio"][name="secB-radio-nine"]').click(function() {

		var inputValue = $('input[name="secB-radio-nine"]:checked').val();

		if (inputValue == 'Yes') {
			$("#reveal-secB").css("display", "block");
		} else if (inputValue == 'No') {
			$("#reveal-secB").css("display", "none");
			$('#secB-input-ten').val('');
			$('#secB-input-eleven').val('');
		}
	})
	
	
	// Section C -- 12 -- ADT Feed - Yes No
	$('input[type="radio"][name="secC-radio-twelve"]').click(function() {

		var inputValue = $('input[name="secC-radio-twelve"]:checked').val();

		if (inputValue == 'Yes') {
			$("#reveal-twelve-a").css("display", "none");
			$("#reveal-thirteen").css("display", "block");
			$('#secC-input-twelve-a').val('');
			//flagsectionc = true;
		} else if (inputValue == 'No') {
			$("#reveal-twelve-a").css("display", "block");
			$("#reveal-thirteen").css("display", "none");
			
			$("#secC-input-thirteen").prop('selectedIndex', 0);
			$('#secC-input-fourteen').val('');
			//flagsectionc = false;
		}

		
//		if (flagsectionc) {
//			$("#reveal2").css("display", "block");
//			$("#reveal1").css("display", "none");
//		} else {
//			$("#reveal1").css("display", "block");
//			$("#reveal2").css("display", "none");
//		}

	})

});
