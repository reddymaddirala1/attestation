$(document).ready(function() {
	$("#err-msg-one").hide();
	$("#err-msg-two").hide();

	$("#name").focus(function() {
		$("#err-msg-one").hide();
	});

	$("#email").focus(function() {
		$("#err-msg-two").hide();
	});

	$("#submit_button").click(function() {
		var namevalue = $("#name").val();
		var emailvalue = $("#email").val();
		var name_regex = /^[a-zA-Z'. -]+$/;
		var email_regex = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

		nameCheck = true;
		emailCheck = true;
		
		if (namevalue.length == 0) {
			$("#err-msg-one").show();
			nameCheck = false;
			//return false;
		}
		// Validating Name Field.
		else if (!namevalue.match(name_regex) || namevalue.length == 0) {
			$("#name").focus();
			$("#err-msg-one").show();
			nameCheck = false;
			//return false;
		}else{
			nameCheck = true;
		}
		
		// Validating Email Field.		
		if (!emailvalue.match(email_regex) || emailvalue.length == 0) {
			$("#err-msg-two").show();
			emailCheck = false;
			//return false;
		} else {
			emailCheck = true;
			//return true;
		}
		
		if(nameCheck && emailCheck){
			//$("#submit_button").prop('disabled', true);
			return true;
		}else{
			return false;
		}
	});
}); // document ready function
