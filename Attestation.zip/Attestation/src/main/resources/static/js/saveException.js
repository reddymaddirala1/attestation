$(document).ready(function() {

	$("#btnSaveTop").click(function(event) {

		event.preventDefault();

		//Call function to form preview content object
		preview_content();
		
		var data = {};

		data = form_data();
		
		$.ajax({

			url : "/attestation/Year/YearException/savedata",
			type : "POST",
			contentType : "application/json",
			data : JSON.stringify(data),
			dataType : 'json',
			cache : false,
			timeout : 600000,
			success : function(data) {
				$('#myModalSave').modal('show');
			},
			error : function(data) {
				$('#myModalSaveErr').modal('show');
			}
		});

		return false;
	});
	
	$("#btnSaveBottom").click(function(event) {

		event.preventDefault();

		//Call function to form preview content object
		preview_content();
		
		var data = {};

		data = form_data();
		
		$.ajax({

			url : "/attestation/Year/YearException/savedata",
			type : "POST",
			contentType : "application/json",
			data : JSON.stringify(data),
			dataType : 'json',
			cache : false,
			timeout : 600000,
			success : function(data) {
				$('#myModalSave').modal('show');
			},
			error : function(data) {
				$('#myModalSaveErr').modal('show');
			}
		});

		return false;
	});
});
