$('input')
		.each(
				function(i, e) {

					var label;

					switch ($(e).attr('id')) {
					case 'secA-input-one':
						label = 'Example : George Washington Hospital';
						break;
					case 'secA-input-two':
						label = 'Number and Street Name';
						break;
					case 'secA-input-three':
						label = 'Suite / Unit if applicable';
						break;
					case 'secA-input-four':
						label = 'City of the Provider Organization';
						break;
					case 'secA-input-five':
						label = 'Default set as MA';
						break;
					case 'secA-input-six':
						label = '5 digits zip code eg. 12345';
						break;
					case 'secA-input-seven1':
						label = '9 digit Tax ID / TIN as eg. 999999999';
						break;
					case 'secA-input-seven':
						label = '10 digits Organization NPI ';
						break;
					case 'secA-input-eight':
						label = 'This is the part of the Direct address to the right of the @ sign, such as "direct.orgname.masshiway.net" or "1234.direct.hispname.com"). Either a Mass HIway or HISP address is acceptable. Please send all domain names currently in use by the Provider Organization. Please use ; when entering multiple domain(s)';
						break;
					case 'secA-input-nine':
						label = 'Example : George Washington Hospital';
						break;

					// Section C
					case 'secC-input-two':
						label = 'Name of EMR / EHR System';
						break;
					case 'secC-input-three':
						label = 'Version of EMR / EHR System';
						break;

					// Section D

					case 'secD-input-one':
						label = 'Contact Person First and Last Name ';
						break;
					case 'secD-input-two':
						label = 'Contact Person Title ';
						break;
					case 'secD-input-three':
						label = 'Name of the Vendor';
						break;
					case 'secD-input-four':
						label = 'Date of Submission';
						break;

					// Section E

					case 'secE-input-two':
						label = 'Authorized person First  and Last Name';
						break;
					case 'secE-input-three':
						label = 'Authorized person Title';

						break;
					case 'secE-input-four':
						label = 'Authorized person Signed Date';

						break;
					case 'secE-input-five':
						label = 'Authorized person phone number';

						break;
					case 'secE-input-six':
						label = 'Authorized person email address';
						break;
					}
					$(e).tooltip({
						'trigger' : 'focus',
						'title' : label
					});
				});
