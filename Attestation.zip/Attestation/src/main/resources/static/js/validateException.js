$(document).ready(function() {

	$('#btnPreview').hide();
	hide_errmsg();
	evaluate_hidden();
	
	$("#secC-input-fourteen").datepicker({
      changeMonth: true,
      changeYear: true
    });
});

// tooltip for Text area
$('textarea[name=Content]').tooltip({
	placement : "top",
	trigger : "focus"
});

$('#closepreview').click(function() {
	$("#previewForm").css("display", "none");
	$("#realForm").css("display", "block");
	$(".text-container").css("display", "block");
});

/* On load hide all error messages */
function hide_errmsg() {

	// hide all general errors
	var errmsgary = $("[id^=err-msg-]");
	var i = 0;
	for (i = 0; i < errmsgary.length; i++) {
		$('#' + errmsgary[i].id).hide()
	}

	// hide all length related errors
	var errlengthary = $("[id^=err-length-]");
	var i = 0;
	for (i = 0; i < errlengthary.length; i++) {
		$('#' + errlengthary[i].id).hide()
	}

	// hide all date related errors
	var errdateary = $("[id^=err-date-]");
	var i = 0;
	for (i = 0; i < errdateary.length; i++) {
		$('#' + errdateary[i].id).hide()
	}

	// hide preview error
	$('#previewerror').hide();
}

function evaluate_hidden() {

	var inputValue = $('input[name="secB-radio-nine"]:checked').val(); // 9,
																		// 10,
																		// 11
																		// (SecB)
	if (inputValue == 'Yes') {
		$("#reveal-secB").css("display", "block");
	} else if (inputValue == 'No') {
		$("#reveal-secB").css("display", "none");
	}

	var inputValue12 = $('input[name="secC-radio-twelve"]:checked').val(); // 3,
																			// 12,
																			// 12a,
																			// 13,
																			// 14
																			// (SecC)
	var practiceType = $('#secA-input-three :selected').val();
	if (practiceType == 'Acute Care Hospital') {
		$("#reveal-twelve").css("display", "block");
		$('#err-msg-twelve').hide();
		if (inputValue12 == 'Yes') {
			$("#reveal-twelve-a").css("display", "none");
			$("#reveal-thirteen").css("display", "block");
		} else if (inputValue12 == 'No') {
			$("#reveal-twelve-a").css("display", "block");
			$("#reveal-thirteen").css("display", "none");
		}
	} else {
		$("#reveal-twelve").css("display", "none");
		$('input[name="secC-radio-twelve"]').prop('checked', false);
		$('#secC-input-twelve-a').val('');
		//$('#secC-input-thirteen').val('');
		$("#secC-input-thirteen").prop('selectedIndex', 0);
		$('#secC-input-fourteen').val('');
	}
}

function form_data() {
	var data = {}

	// Section A
	data["orgname"] = $("#content1").text();
	data["staddr"] = $("#content2").text();
	data["city"] = $("#content4").text();
	data["state"] = $("#content5").text();
	data["zipcode"] = $("#content6").text();
	data["practicetype"] = $('#content0a').text();
	data["explaination"] = $("#content9").text();
	data["plana"] = $("#content5a").text();
	data["planb"] = $("#content5b").text();
	data["unabletomeethiwayreq"] = $("#content10").text();
	data["plantomeethiwayreq"] = $("#content10a").text();
	data["pporgassisstance"] = $("#content11a").text();

	// Section B
	data["ehremrsystem"] = $("#content24").text();
	data["nameemr"] = $("#content25").text();
	data["versionemr"] = $("#content26").text();

	// Section C
	data["adtfeeds"] = $("#content12a").text();
	data["ensintiative"] = $("#content12b").text();
	data["infoonadtfeeds"] = $("#content13a").text();
	data["dateofsubmission"] = $("#content14a").text();

	// Section D
	data["aaname"] = $('#contentd30').text();
	data["aatitle"] = $('#contentd31').text();
	data["aaemail"] = $('#contentd32').text();
	data["aaphone"] = $('#contentd33').text();
	data["aaext"] = $('#contentd33a').text();

	data["ocname"] = $('#contentd45').text();
	data["octitle"] = $('#contentd46').text();
	data["ocemail"] = $('#contentd47').text();
	data["ocphone"] = $('#contentd48').text();
	data["ocext"] = $('#contentd50').text();

	data["suggestions"] = $('#suggestion1').text();

	data["accessCode"] = $("#contentAccCode").text();
	data["attestationYear"] = 'YearException';

	return data;
}

function preview_content() {

	var secBarray5b = [];

	// ------------Section A -------------

	$("#content1").text($("#secA-input-one").val());		// 1 
	$("#content2").text($("#secA-input-two-a").val());		// 2
	$("#content4").text($("#secA-input-two-b").val());
	$("#content5").text($("#secA-input-two-c").val());
	$("#content6").text($("#secA-input-two-d").val());
	
	var e = $('#secA-input-three :selected').val();			// 3
	$("#content0a").text(e);
	
	$("#content9").text($("#secA-input-four").val());		// 4
	
	
	var d = $('#secA-input-five-a :selected').val();		// 5-a
	$("#content5a").text(d);
	
	$.each($('input[name=SecA-check-five-b]:checked'), function() {		// 5b
		secBarray5b.push($(this).val());
		$("#content5b").text(secBarray5b.join(" || "));
	});
	
//	if (!$('input[name=SecA-check-five-b]:checked').val()) {
//		secBarray5b = [];
//		$("#content5b").text(secBarray5b);
//	}
	
	$("#content10").text($("#secA-input-six").val());		// 6

	$("#content10a").text($("#secA-input-seven").val());	// 7
	
	$("#content11a").text($('input[name=secA-radio-eight]:checked').val());		// 8

	// ------------Section A -------------

	
	// ------------Section B -------------

	$("#content24").text($('input[name=secB-radio-nine]:checked').val());
	$("#content25").text($("#secB-input-ten").val());
	$("#content26").text($("#secB-input-eleven").val());

	// .............End of Section B .............

	// .......... Section C ......................
	
	$("#content12a").text('');
	$("#content12a").text($('input[name=secC-radio-twelve]:checked').val());
	$("#content12b").text($("#secC-input-twelve-a").val());
	//$("#content13a").text($('#secC-input-thirteen').val());
	
	if ($('#secC-input-thirteen :selected').val() == "select") {			// 37
		$("#content13a").text('');
	} else {
		$("#content13a").text($('#secC-input-thirteen :selected').val());
	}
	
	$("#content14a").text($("#secC-input-fourteen").val());

	// ..........End of  Section C ......................
	
	// .......... Section D ......................

	$('#contentd30').text($('#secD-input-aa-one').val());
	$('#contentd31').text($('#secD-input-aa-two').val());
	$('#contentd32').text($('#secD-input-aa-three').val());
	$('#contentd33').text($('#secD-input-aa-four').val());
	$('#contentd33a').text($('#secD-input-aa-five').val());

	$('#contentd45').text($('#secD-input-oc-fifteen').val());
	$('#contentd46').text($('#secD-input-oc-sixteen').val());
	$('#contentd47').text($('#secD-input-oc-seventeen').val());
	$('#contentd48').text($('#secD-input-oc-eighteen').val());
	$('#contentd50').text($('#secD-input-oc-nineteen').val());
	
	// .........End of Section D .................

	$("#suggestion1").text($("#secE-input-one").val());

	// Access Code
	$("#contentAccCode").text($('#hiddenaccCode').val());

}

/** ******* Length and Date ********* */



$('#secA-input-two-d').focus(function() {
	$('#secA-input-two-d').css("border-color", "");
	$('#err-length-two-d').hide();
});

$('#secD-input-aa-one').focus(function() {
	$('#secD-input-aa-one').css("border-color", "");
	$('#err-msg-secD-aa-one').hide();
});

$('#secD-input-aa-two').focus(function() {
	$('#secD-input-aa-two').css("border-color", "");
	$('#err-msg-secD-aa-two').hide();
});

$('#secD-input-aa-four').focus(function() {
	$('#secD-input-aa-four').css("border-color", "");
	$('#err-length-secD-aa-four').hide();
});

$('#secC-input-fourteen').focus(function() {
	$('#secC-input-fourteen').css("border-color", "");
	$('#err-date-fourteen').hide();
});

/** ******* CHECKBOX ********* */

// SecA - 5b -- OPTIONAL
// $('input[type=checkbox].chkbox--five-b').click(function() {
// $('#err-msg--five-b').hide();
// });

/** ******* RADIO ********* */

// secA - 8 radio -- OPTIONAL
// $("#secA-radio-eight-div input:radio").click(function() {
// $('#err-msg-secA-eleven').hide();
// });
// Sec B -- 9 EMREHR
$("#secB-radio-nine-div input:radio").click(function() {

	$('#secB-input-ten').css("border-color", "");
	$('#secB-input-eleven').css("border-color", "");

	$('#err-msg-nine').hide();
	$('#err-msg-ten').hide();
	$('#err-msg-eleven').hide();
});

// sec C -- 12
$("#secC-radio-twelve-div input:radio").click(function() {

	$('#secC-input-twelve-a').css("border-color", "");
	$('#secC-input-thirteen').css("border-color", "");
	$('#secC-input-fourteen').css("border-color", "");
	$('#err-msg-twelve').hide();
	$('#err-msg-twelve-a').hide();
	$('#err-msg-thirteen').hide();
	$('#err-msg-fourteen').hide();
	$('#err-date-fourteen').hide();
});

$('#btnValidate').click(
		function() {

			var flagforminlength = false;

			// if (!$('input[name=secA-radio-eight]:checked').val()) { //
			// 8--OPTIONAL
			// $('#err-msg-eight').show();
			// }

			if (!$('input[name=secB-radio-nine]:checked').val()) { // 9
				$('#err-msg-nine').show();
			}

			if (!$('input[name=secC-radio-twelve]:checked').val()) { // 12
				$('#err-msg-twelve').show();
			}

			len1 = $('#secA-input-two-d').val(); // ZIP length
			isValidZip = isValidNum(len1);
			if (len1.length == 5 && isValidZip) {
				$('#err-length-two-d').hide();
				flagforminlength = true;
			} else {
				$('#err-length-two-d').show();
				flagforminlength = false;
			}

			var status1 = secAtextBoxChecking();
			var status2 = secATextAreaChecking();
			var status3 = secADropdownChecking();
			var status3 = secBRadioChecking();
			// var status8 = radioChecking8(); -- OPTIONAL
			var status4 = sectionDonLoadingAA(); // CONTACT
			var status5a = secAcheckboxChecking5a();
			// var status5b = secAcheckBoxChecking5b(); -- OPTIONAL
			var status6 = secCRadiochecking();

			if (status1 && status2 && status3 && status4 && flagforminlength
					&& status5a && status6) {
				$('#previewerror').hide();

				$("#realForm").css("display", "none");
				$(".text-container").css("display", "none");

				// Call function to form content obj for preview
				preview_content();

				var data = {};
				data = form_data();

				$.ajax({
					url : "/attestation/Year/YearException/savedata",
					type : "POST",
					contentType : "application/json",
					data : JSON.stringify(data),
					dataType : 'json',
					cache : false,
					timeout : 600000,
					success : function(data) {
					},
					error : function(data) {
					}
				});

				$("#previewForm").css("display", "block");

			} else {
				$('#previewerror').show();
			}
		});

/*
 * checkbox
 * 
 * 
 */

function secAcheckboxChecking5a() {
	var d = $('#secA-input-five-a :selected').val();

	if (d == 'Select') {
		return false;
	} else {
		return true;
	}
}

// function secAcheckBoxChecking5b() {
//
// var count = 0;
// var sList = "";
// var secAhidden;
// var checkingforclicked2 = false;
//
// // Loop thru all checkboxes
// // checkbox-five-b is class id name for all checkboxes
// $('input[type=checkbox].checkbox-five-b').each(function() {
// if (this.checked) {
// var checkboxvalue = $(this).val();
//
// count = count + 1;
// // Check other text is not empty
//
// checkingforclicked2 = true;
// }
// });
//
// if (true) {
// $('#err-msg-secA-table5b').hide();
// return true;
// }
// /*
// * else { $('#err-msg-secA-table5b').show(); return false; }
// */
//
// }

/* Sec A - dropdowns switches */
function secADropdownChecking() {

	var dropdowncheck = true;
	$('select').each(function(i, e) {
		switch ($(e).attr('id')) {

		case 'secA-input-five-a':
			if (!dropdownforSectionA('#secA-input-five-a')) {
				dropdowncheck = false;
			}
			break;
		case 'secA-input-three':
			if (!dropdownforSectionA('#secA-input-three')) {
				dropdowncheck = false;
			}
			break;
		default:
			// Other dropdown will be ignored here
		}
	});

	return dropdowncheck;
}

/* Sec A - Validate the dropdown is selected */
function dropdownforSectionA(idname) {

	var flag = false;
	var avoid = "#secA-input-";
	var abc = idname.replace(avoid, '');

	$(idname).change(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
	});
	var val = $(idname).val();

	// Select is the default value - treat it as non-selected
	if (val == "Select") {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + abc).show();
		flag = false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
		flag = true;
	}

	return flag;
}

/* All Text areas */
function secATextAreaChecking() {

	var textareacheck = true;
	$('textarea').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secA-input-four':
			if (!forSectionA('#secA-input-four')) {
				textareacheck = false;
			}
			break;
		case 'secA-input-six':
			if (!forSectionA('#secA-input-six')) {
				textareacheck = false;
			}
			break;
		case 'secA-input-seven':
			if (!forSectionA('#secA-input-seven')) {
				textareacheck = false;
			}
			break;
		default:
			// textarea which are optional will be ignored
		}
	});

	return textareacheck;
}

/* Sec A text box */
function secAtextBoxChecking() {

	var check = true;

	$('input').each(function(i, e) {
		switch ($(e).attr('id')) {
		case 'secA-input-one': // SecA - 1
			if (!forSectionA('#secA-input-one')) {
				check = false;
			}
			break;
		case 'secA-input-two-a': // SecA -- 2a
			if (!forSectionA('#secA-input-two-a')) {
				check = false;
			}
			break;
		case 'secA-input-two-b': // SecA -- 2b
			if (!forSectionA('#secA-input-two-b')) {
				check = false;
			}
			break;
		case 'secA-input-two-c': // SecA -- 2c
			if (!forSectionA('#secA-input-two-c')) {
				check = false;
			}
			break;
		case 'secA-input-two-d': // SecA -- 2d
			if (!forSectionA('#secA-input-two-d')) {
				check = false;
			}
			break;
		default:
			// Optional textbox is ignored
			// Sec B, C and D textbox will be ignored here
		}

	});

	return check;
}

/* Vailidate Sec A text to see if its empty */
function forSectionA(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
	});

	var avoid = "#secA-input-";
	var abc = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + abc).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
		return true;
	}
}

// function radioChecking8() {
//
// if (!$('input[name=secA-radio-eight]:checked').val()) {
// return false;
// } else {
// return true;
// }
// }

/* Sec C - top level Check */
function secBRadioChecking() {

	var inputValue = $('input[name="secB-radio-nine"]:checked').val();

	var emrReturn = false;

	if (inputValue == 'Yes') {
		emrReturn = secBTextBoxChecking();
	} else if (inputValue == 'No') {
		$('#secB-input-two').val('');
		$('#secB-input-three').val('');
		emrReturn = true;
	}

	return emrReturn;

}

/* Sec B - textbox checking */
function secBTextBoxChecking() {

	var label;
	var check = true;

	$('input[type=text].secB').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secB-input-ten':
			if (!forSectionB('#secB-input-ten')) {
				check = false;
			}
			break;
		case 'secB-input-eleven':
			if (!forSectionB('#secB-input-eleven')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Vailidate Sec B text to see if its empty */
function forSectionB(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
	});

	var avoid = "#secB-input-";
	var abc = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + abc).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
		return true;
	}
}

// sec C validations
function secCRadiochecking() {

	var inputValueC = $('input[name="secC-radio-twelve"]:checked').val();
	var practiceType = $('#secA-input-three :selected').val();

	if (practiceType == 'Acute Care Hospital') {
		if (inputValueC == 'Yes') {
			$('#secC-input-twelve-a').val('');
			
			var secCTextbox = secCTextBoxChecking();
			var secCDropdown = validateDropdownSecC13();
			
			if (secCTextbox && secCDropdown) {
				return true;
			} else {
				return false;
			}
		} else if (inputValueC == 'No') {

			var secCTextArea = secCTextAreaChecking();
			
			//var secCTextbox = secCTextBoxChecking();
			//var secCDropdown = validateDropdownSecC13();
			
			$("#secC-input-thirteen").prop('selectedIndex', 0);
			$('#secC-input-fourteen').val('');
			
			if (secCTextArea) {
				return true;
			} else {
				return false;
			}
		}
	} else {
		return true;
	}
}

function validateDropdownSecC13() {

	var dropdowncheck = false;
	$('select.secC13').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secC-input-thirteen':
			dropdowncheck = dropdownforSectionC13('#secC-input-thirteen');
			break;
		default:
			return dropdowncheck;
		}
	});
	return dropdowncheck;
}

function dropdownforSectionC13(idname) {

	var avoid = "#secC-input-";
	var section = idname.replace(avoid, '');

	$(idname).change(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();

	});

	var val = $(idname).val();

	if (val == "select") {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}
}

function secCTextBoxChecking() {

	var label;
	var check = true;

	$('input[type=text].secC_doc').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secC-input-fourteen':
			if (!forSectionCDOC('#secC-input-fourteen')) {
				check = false;
			} else {
				var checkDate = isValidDate('#secC-input-fourteen');

				if (checkDate) {
					$('#secC-input-fourteen').css("border-color", "");
					$('#err-date-fourteen').hide();
				} else {
					$('#secC-input-fourteen').css("border-color", "#eb18f3");
					$('#err-date-fourteen').show();
					check = false;
				}
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* All Text areas */
function secCTextAreaChecking() {

	var textareacheck = true;
	$('textarea').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secC-input-twelve-a':
			if (!forSectionCDOC('#secC-input-twelve-a')) {
				textareacheck = false;
			}
			break;
		default:
			// textarea which are optional will be ignored
		}
	});

	return textareacheck;
}

/* Vailidate Sec C Documentation text to see if its empty */
function forSectionCDOC(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
	});

	var avoid = "#secC-input-";
	var abc = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + abc).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
		return true;
	}
}

/* Sec D - AA */
function sectionDonLoadingAA() {
	var label;
	var check = true;

	$('input[type=text].secDaa').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secD-input-aa-one':
			if (!forSectionD('#secD-input-aa-one')) {
				check = false;
			}
			break;
		case 'secD-input-aa-two':
			if (!forSectionD('#secD-input-aa-two')) {
				check = false;
			}
			break;
		case 'secD-input-aa-three':
			if (!validationEmail('#secD-input-aa-three')) {
				check = false;
			}
			break;
		case 'secD-input-aa-four':
			if (!validationPhone('#secD-input-aa-four')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Vailidate Sec D text to see if its empty */
function forSectionD(idname) {

	var avoid = "#secD-input-";
	var abc = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + abc).hide();
	});

	if ($.trim(lengthVal).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + abc).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + abc).hide();
		return true;
	}
}

function validationEmail(idname) {

	var avoid = "#secD-input-";
	var abc = idname.replace(avoid, '');

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + abc).hide();
		$('#err-msg-email-secD-' + abc).hide();
	});

	var sEmail = $(idname).val();

	if ($.trim(sEmail).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + abc).show();
		return false;
	} else if (validateEmail(sEmail)) {
		$(idname).css("border-color", "");
		return true;
	} else {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-email-secD-' + abc).show();
		return false;
	}
}

function validationPhone(idname) {

	var avoid = "#secD-input-";
	var abc = idname.replace(avoid, '');

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + abc).hide();
		$('#err-length-secD-' + abc).hide();
	});

	var sPhone = $(idname).val();

	if ($.trim(sPhone).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + abc).show();
		return false;
	} else if (!isValidNum(sPhone)){
		$(idname).css("border-color", "#eb18f3");
		$('#err-length-secD-' + abc).show();
		return false;
	} else if ($.trim(sPhone).length == 10) {
		$('#err-length-secD-' + abc).hide();
		return true;
	} else {
		$(idname).css("border-color", "#eb18f3");
		$('#err-length-secD-' + abc).show();
		return true;
	}

}

function validateEmail(sEmail) {
	var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if (filter.test(sEmail)) {
		return true;
	} else {
		return false;
	}
}

// Validates that the input string is a valid date formatted as "mm/dd/yyyy"
function isValidDate(idname) {
	var dateString = $(idname).val();

	// First check for the pattern
	if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString))
		return false;

	// Parse the date parts to integers
	var parts = dateString.split("/");
	var day = parseInt(parts[1], 10);
	var month = parseInt(parts[0], 10);
	var year = parseInt(parts[2], 10);

	// Check the ranges of month and year
	if (year < 1000 || year > 3000 || month == 0 || month > 12)
		return false;

	var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

	// Adjust for leap years
	if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
		monthLength[1] = 29;

	// Check the range of the day
	return day > 0 && day <= monthLength[month - 1];

}

// Validates that the input string is a valid Number
function isValidNum(numString) {
	var regex = /^\d+$/;
	
	// Check for the pattern
	if (!regex.test(numString))
		return false;

	return true;

}

function validatenumeric(evt, arg) {
	var id = arg.getAttribute('id');
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /[0-9\b]|\./;

	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}

function validatealphanumeric(evt, arg) {
	var id = arg.getAttribute('id');

	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /^[a-zA-Z0-9._ \b]+$/;

	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}
