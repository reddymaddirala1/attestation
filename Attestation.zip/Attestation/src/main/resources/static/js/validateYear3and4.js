$(document).ready(function() {

	$('#btnPreview').hide();
	hide_errmsg();
	evaluate_hidden();
	
	$("#secB-input-ten").datepicker({
      changeMonth: true,
      changeYear: true
    });
    
    $("#secB-input-eighteen").datepicker({
      changeMonth: true,
      changeYear: true
    });

    $("#secD-input-thirtyeight").datepicker({
      changeMonth: true,
      changeYear: true
    });
});

// tooltip for Text area
$('textarea[name=Content]').tooltip({
	placement : "top",
	trigger : "focus"
});

$('#closepreview').click(function() {
	$("#previewForm").css("display", "none");
	$("#realForm").css("display", "block");
	$(".text-container").css("display", "block");
});

/* On load hide all error messages */
function hide_errmsg() {

	// hide all general errors
	var errmsgary = $("[id^=err-msg-]");
	var i = 0;
	for (i = 0; i < errmsgary.length; i++) {
		$('#' + errmsgary[i].id).hide()
	}

	// hide all length related errors
	var errlengthary = $("[id^=err-length-]");
	var i = 0;
	for (i = 0; i < errlengthary.length; i++) {
		$('#' + errlengthary[i].id).hide()
	}

	// hide all date related errors
	var errdateary = $("[id^=err-date-]");
	var i = 0;
	for (i = 0; i < errdateary.length; i++) {
		$('#' + errdateary[i].id).hide()
	}

	// hide preview error
	$('#previewerror').hide();

}

function evaluate_hidden() {

	// SecB - 8 - Other
	if ($("#inlineCheckbox8-6").is(':checked')) {
		$("#secB-hidden-eight-other").css("display", "block");
	} else {
		$("#secB-hidden-eight-other").css("display", "none");
	}

	// SecB - 12 - Other
	if ($("#inlineCheckbox12-6").is(':checked')) {
		$("#secB-hidden-twelve-other").css("display", "block");
	} else {
		$("#secB-hidden-twelve-other").css("display", "none");
	}

	// SecB - 13 - HL7
	if ($("#inlineCheckbox13-5").is(':checked')) {
		$("#secB-hidden-thirteen-hl7").css("display", "block");
	} else {
		$("#secB-hidden-thirteen-hl7").css("display", "none");
	}

	// SecB - 13 - Other
	if ($("#inlineCheckbox13-6").is(':checked')) {
		$("#secB-hidden-thirteen-other").css("display", "block");
	} else {
		$("#secB-hidden-thirteen-other").css("display", "none");
	}

	// SecB - 16 - Other
	if ($("#inlineCheckbox16-23").is(':checked')) {
		$("#secB-hidden-sixteen-other").css("display", "block");
	} else {
		$("#secB-hidden-sixteen-other").css("display", "none");
	}

	// SecB - 20 - Other
	if ($("#inlineCheckbox20-6").is(':checked')) {
		$("#secB-hidden-twenty-other").css("display", "block");
	} else {
		$("#secB-hidden-twenty-other").css("display", "none");
	}

	// SecB - 21 - HL7
	if ($("#inlineCheckbox21-5").is(':checked')) {
		$("#secB-hidden-twentyone-hl7").css("display", "block");
	} else {
		$("#secB-hidden-twentyone-hl7").css("display", "none");
	}

	// SecB - 21 - Other
	if ($("#inlineCheckbox21-6").is(':checked')) {
		$("#secB-hidden-twentyone-other").css("display", "block");
	} else {
		$("#secB-hidden-twentyone-other").css("display", "none");
	}

	// SecB - 24 - Other
	if ($("#inlineCheckbox24-23").is(':checked')) {
		$("#secB-hidden-twentyfour-other").css("display", "block");
	} else {
		$("#secB-hidden-twentyfour-other").css("display", "none");
	}

	// SecB - 26 - Yes or No
	var inputValue = $('input[name="secB-radio-twentysix"]:checked').val();

	if (inputValue == 'Yes') {
		$("#reveal-twentysix-yes").css("display", "block");
	} else if (inputValue == 'No') {
		$("#reveal-twentysix-yes").css("display", "none");
	}

	// SecC - 29 - Yes or No
	var inputValue = $('input[name="secC-radio-twentynine"]:checked').val();

	if (inputValue == 'Yes') {
		$("#reveal-twentynine-yes").css("display", "block");
		$("#reveal-twentynine-yesandno").css("display", "block");

		// preview section
		$("#sectionctrue").css("display", "block");
		$("#sectioncfalse").css("display", "block");

	} else if (inputValue == 'No') {
		$("#reveal-twentynine-yes").css("display", "none");
		$("#reveal-twentynine-yesandno").css("display", "block");

		// preview section
		$("#sectioncfalse").css("display", "block");
		$("#sectionctrue").css("display", "none");
	}

	// SecC - 35 - via Other Method
	if ($("#inlineCheckbox35-2").is(':checked')) {
		$("#secC-hidden-thirtyfive-other").css("display", "block");
	} else {
		$("#secC-hidden-thirtyfive-other").css("display", "none");
	}

	// Access Admin
	var aaName = $('#secD-input-aa-one').val()
	if ($.trim(aaName) != '') {
		$("#secDaahiddenblock").css("display", "block");
		$("#inlineCheckboxsecDaa").prop("checked", true);
	}

	// Technical Contact
	var tcName = $('#secD-input-tc-five').val()
	if ($.trim(tcName) != '') {
		$("#secDtchiddenblock").css("display", "block");
		$("#inlineCheckboxsecDtc").prop("checked", true);
	}

	// Business Contact
	var bcName = $('#secD-input-bc-ten').val()
	if ($.trim(bcName) != '') {
		$("#secDbchiddenblock").css("display", "block");
		$("#inlineCheckboxsecDbc").prop("checked", true);
	}

	// Other Contact
	var ocName = $('#secD-input-oc-fifteen').val()
	if ($.trim(ocName) != '') {
		$("#secDochiddenblock").css("display", "block");
		$("#inlineCheckboxsecDoc").prop("checked", true);
	}

	/*
	 * var inputValueD = $('input[name="secDoptradio"]:checked').val(); var
	 * practiceType = $('#secA-input-seven-a :selected').val();
	 * 
	 * if (practiceType == 'Acute Care Hospital') {
	 * $("#revealmain").css("display", "block");
	 * $('#err-msg-secDdoc-one').hide(); if (inputValueD == 'Yes') {
	 * $("#revealD38").css("display", "block"); $("#revealD37a").css("display",
	 * "none");
	 * 
	 * $("#sectionddocfalse").css("display", "none");
	 * $("#sectionddoctrue").css("display", "block");
	 *  } else if (inputValueD == 'No') { $("#revealD38").css("display",
	 * "none"); $("#revealD37a").css("display", "block");
	 * 
	 * $("#sectionddocfalse").css("display", "block");
	 * $("#sectionddoctrue").css("display", "none"); } } else {
	 * $("#revealmain").css("display", "none"); $('#secD-inputD-two').val('');
	 * $('#secD-inputD-three').val(''); $('#secD-inputD-four').val('');
	 * $('input[name="secDoptradio"]').prop('checked', false);
	 * $("#sectionddocfalse").css("display", "none");
	 * $("#sectionddoctrue").css("display", "none"); }
	 */

	/*
	 * SecB - 25 - 100% var inputValue = $('#secB-input-ten :selected').val();
	 * 
	 * if (inputValue == "100%") { $("#secBinputhidden4new").css("display",
	 * "none"); }else if (inputValue == "Select") {
	 * $("#secBinputhidden4new").css("display", "none"); } else {
	 * $("#secBinputhidden4new").css("display", "block"); }
	 */
}

// Form Data
function form_data() {
	var data = {}

	// Section A
	data["orgname"] = $("#content1").text();
	data["staddr"] = $("#content2").text();
	data["city"] = $("#content4").text();
	data["state"] = $("#content5").text();
	data["zipcode"] = $("#content6").text();
	data["taxid"] = $("#content7").text();
	data["orgnpi"] = $("#content8").text();
	data["orgdomain"] = $("#content9").text();
	data["parentcompany"] = $("#content10").text();
	data["suborg"] = $("#content11").text();

	// Section B
	data["nameusecase"] = $("#content12").text();
	data["dateusecase"] = $("#content13").text();
	data["category1usecase"] = $("#content14").text();
	data["send_receiveusecase"] = $("#content15").text();
	data["entityusecase"] = $("#content16").text();
	data["category2usecase"] = $("#content17").text();
	data["othercategory2"] = $("#content17-1").text();
	data["cat2ucsender"] = $("#content18").text();
	data["cat2ucreceiver"] = $("#content19").text();
	data["infotype"] = $("#content20").text();
	data["otherinfotype"] = $("#content20-1").text();
	data["infoformat"] = $("#content21").text();
	data["hl7infoformat"] = $("#content21-1").text();
	data["otherinfoformat"] = $("#content21-2").text();
	data["msgpercentage"] = $("#content22").text();
	data["othermethod"] = $("#content22_new1").text();
	data["listothermethod"] = $("#content22_new2").text();
	data["transac_no"] = $("#content23").text();
	data["nameusecasereceiver"] = $("#content12r").text();
	data["dateusecasereceiver"] = $("#content13r").text();
	data["category1usecasereceiver"] = $("#content14r").text();
	data["entityusecasereceiver"] = $("#content16r").text();
	data["infotypereceiver"] = $("#content20r").text();
	data["otherinfotypereceiver"] = $("#content20-1r").text();
	data["infoformatreceiver"] = $("#content21r").text();
	data["hl7infoformatreceiver"] = $("#content21-1r").text();
	data["otherinfoformatreceiver"] = $("#content21-2r").text();
	data["category2usecasereceiver"] = $("#content17r").text();
	data["othercategory2receiver"] = $("#content17-1r").text();
	
	// Section C
	data["ehremrsystem"] = $("#content24").text();
	data["nameemr"] = $("#content25").text();
	data["versionemr"] = $("#content26").text();
	data["connectingemr"] = $("#content27").text();
	data["receivingusecase"] = $("#content27r").text();
	data["onccertified"] = $("#content28").text();
	data["connectingprovider"] = $("#content29").text();
	data["otherconnprovider"] = $("#content29-1").text();

	// Section D
	data["aaname"] = $('#contentd30').text();
	data["aatitle"] = $('#contentd31').text();
	data["aaemail"] = $('#contentd32').text();
	data["aaphone"] = $('#contentd33').text();
	data["tcname"] = $('#contentd35').text();
	data["tctitle"] = $('#contentd36').text();
	data["tcemail"] = $('#contentd37').text();
	data["tcphone"] = $('#contentd38').text();
	data["tcrole"] = $('#contentd39').text();
	data["bcname"] = $('#contentd40').text();
	data["bctitle"] = $('#contentd41').text();
	data["bcemail"] = $('#contentd42').text();
	data["bcphone"] = $('#contentd43').text();
	data["bcrole"] = $('#contentd44').text();
	data["ocname"] = $('#contentd45').text();
	data["octitle"] = $('#contentd46').text();
	data["ocemail"] = $('#contentd47').text();
	data["ocphone"] = $('#contentd48').text();

	data["practicetype"] = $('#content0a').text();
	data["goalusecase"] = $('#content0b').text();
	data["otherusecase"] = $('#content0b-1').text();
	data["expandgoalusecase"] = $('#content0c').text();
	data["otherorgdomain"] = $('#content0d').text();
	data["otherorgdomainreceiver"] = $('#content0dr').text();
	data["freeassistance"] = $('#content0f').text();

	// Section D :Documentation of Market-based ENS Initiative Participation
//	data["adtfeeds"] = $('#contentdoc37').text();
//	data["ensinitiative"] = $('#contentdoc37a').text();
//	data["infoonadtfeeds"] = $('#contentdoc38').text();
//	data["dateofsubmission"] = $('#contentdoc39').text();

	// Section E
	data["sigsuggestion"] = $('#secE-input-one-a').val();

	// Section E
	data["signame"]=$("#content50").text();
	data["sigtitle"]=$("#content51").text();	
	data["sigphone"]=$("#content53").text();
	data["sigemail"]=$("#content54").text();
	data["sigext"]=$("#content55").text();
	
	data["accessCode"] = $("#contentAccCode").text();
	data["attestationYear"] = 'Year3';

	return data;
}

function preview_content() {

	var provider = 'Provider to Provider Communications';
	var favorite = [];
	var secBarray = [];
	var secBarrayr = [];
	var secBarray1 = [];
	var secBarray2 = [];
	var secBarray3 = [];
	var secBarray3r = [];
	var secBarray4 = [];
	var secBarray4r = [];
	var secBarray5 = [];
	var secBarray6 = [];

	$("#content0b-1").text("");
	$("#content17-1").text("");
	$("#content20-1").text("");
	$("#content20-1r").text("");
	$("#content21-1").text("");
	$("#content21-1r").text("");
	$("#content21-2").text("");
	$("#content21-2r").text("");
	$("#content29-1").text("");

	//  SEC-A
	$("#content1").text($("#secA-input-one").val());			// 1
	$("#content2").text($("#secA-input-two-a").val());			// 2-a
	$("#content4").text($("#secA-input-two-b").val());			// 2-b
	$("#content5").text($("#secA-input-two-c").val());			// 2-c
	$("#content6").text($("#secA-input-two-d").val());			// 2-d
	$("#content7").text($("#secA-input-three").val());			// 3
	$("#content8").text($("#secA-input-four").val());			// 4
	$("#content0a").text($("#secA-input-four-a").val());		// 4-a
	$("#content9").text($("#secA-input-five").val());			// 5
	$("#content10").text($("#secA-input-six").val());			// 6
	$("#content11").text($("#secA-input-seven").val());			// 7
	
	//SEC-B
	$("#content0c").text($("#secB-input-eight-a").val());		// 8-a
	$("#content12").text($('#secB-input-nine').val());			// 9
	$("#content13").text($('#secB-input-ten').val());			// 10
	$("#content14").text(provider);								// 11
	$("#content16").text($("#secB-input-fourteen").val());		// 14
	$("#content0d").text($("#secB-input-fourteen-a").val());	// 14-a
	$("#content12r").text($('#secB-input-seventeen').val());	// 17
	$("#content13r").text($('#secB-input-eighteen').val());		// 18
	$("#content14r").text(provider);							// 19
	//$("#content15").text($('#secB-input-four :selected').val());
	$("#content16r").text($("#secB-input-twentytwo").val());	// 22
	$("#content0dr").text($("#secB-input-twentytwo-a").val());	// 22-a

	// Check Box
	$.each($('input[name=SecBgoalcheck]:checked'), function() {			// 8

		secBarray6.push($(this).val());
		$("#content0b").text(secBarray6.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content0b-1").text($('#secB-input-eight-other').val());
		}
	});

	$.each($('input[name=SecBoptcheck]:checked'), function() {			// 16

		secBarray.push($(this).val());
		$("#content17").text(secBarray.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content17-1").text($('#secB-input-sixteen-other').val());
		}

	});

	$.each($('input[name=SecBoptcheckr]:checked'), function() {			// 24

		secBarrayr.push($(this).val());
		$("#content17r").text(secBarrayr.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content17-1r").text($('#secB-input-twentyfour-other').val());
		}

	});

	$("#content18").text('');											// 15
	$.each($('input[name=sendingChk]:checked'), function() {
		if ($(this).val() == "Sending") {
			$("#content18").text($(this).val());
		}
	});

	$("#content19").text('');											// 23
	$.each($('input[name=receivingChk]:checked'), function() {

		if ($(this).val() == "Receiving") {
			$("#content19").text($(this).val());
		}
	});

	$.each($('input[name=SecBoptcheck1]:checked'), function() {			// 12
		secBarray3.push($(this).val());
		$("#content20").text(secBarray3.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content20-1").text($('#secB-input-twelve-other').val());
		}

	});

	$.each($('input[name=SecBoptcheck1r]:checked'), function() {		// 20
		secBarray3r.push($(this).val());
		$("#content20r").text(secBarray3r.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content20-1r").text($('#secB-input-twenty-other').val());
		}

	});

	$.each($('input[name=SecBoptcheck2]:checked'), function() {				// 13

		secBarray4.push($(this).val());
		$("#content21").text(secBarray4.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content21-2").text($('#secB-input-thirteen-other').val());
		} else if ($(this).val() == "HL7 message (specify type)") {
			$("#content21-1").text($('#secB-input-thirteen-hl7').val());
		}

	});

	$.each($('input[name=SecBoptcheck2r]:checked'), function() { 			// 21

		secBarray4r.push($(this).val());
		$("#content21r").text(secBarray4r.join(" || "));

		if ($(this).val() == "Other (please specify)") {
			$("#content21-2r").text($('#secB-input-twentyone-other').val());
		} else if ($(this).val() == "HL7 message (specify type)") {
			$("#content21-1r").text($('#secB-input-twentyone-hl7').val());
		}

	});

	$.each($('input[name=SecBoptcheck3]:checked'), function() {				// 35

		secBarray5.push($(this).val());
		$("#content29").text(secBarray5.join("||"));

		if ($(this).val() == "Via some other method (please specify)") {
			$("#content29-1").text($('#secC-input-thirtyfive-other').val());
		}
	});

	// End Check Box

	
	// Select box
	var secB25 = $('#secB-input-twentyfive :selected').val();				// 25
	$("#content22").text(secB25);

	$("#content22_new1").text($('input[name=secB-radio-twentysix]:checked').val());		// 26
	$("#content22_new2").text($("#secB-input-twentysix-a").val());						// 26a

	$("#content0f").text($('input[name=secB-radio-twentyeight]:checked').val());		// 28

	var secB27 = $('#secB-input-twentyseven :selected').val();				// 27
	$("#content23").text(secB27);

	$("#content24").text($('input[name=secC-radio-twentynine]:checked').val());		// 29
	
	$("#content25").text($("#secC-input-thirty").val());				// 30
	$("#content26").text($("#secC-input-thirtyone").val());				// 31

	if ($('#secC-input-thirtytwo :selected').val() == "select") {			// 32
		$("#content27").text('');
	} else {
		$("#content27").text($('#secC-input-thirtytwo :selected').val());
	}

	if ($('#secC-input-thirtythree :selected').val() == "select") {			// 33
		$("#content27r").text('');
	} else {
		$("#content27r").text($('#secC-input-thirtythree :selected').val());
	}

	if ($('input[name=secC-radio-thirtyfour]:checked').val() == undefined) {		// 34
		$("#content28").text('');
	} else {
		$("#content28").text($('input[name=secC-radio-thirtyfour]:checked').val());
	}

	// .............End of Section C .............


	// .......... Section D .....................
	$('#contentd30').text($('#secD-input-aa-one').val());
	$('#contentd31').text($('#secD-input-aa-two').val());
	$('#contentd32').text($('#secD-input-aa-three').val());
	$('#contentd33').text($('#secD-input-aa-four').val());

	$('#contentd35').text($('#secD-input-tc-five').val());
	$('#contentd36').text($('#secD-input-tc-six').val());
	$('#contentd37').text($('#secD-input-tc-seven').val());
	$('#contentd38').text($('#secD-input-tc-eight').val());

	if ($('#secD-input-tc-nine :selected').val() == "Select") {
		$("#contentd39").text('');
	} else {
		$("#contentd39").text($('#secD-input-tc-nine :selected').val());
	}

	$('#contentd40').text($('#secD-input-bc-ten').val());
	$('#contentd41').text($('#secD-input-bc-eleven').val());
	$('#contentd42').text($('#secD-input-bc-twelve').val());
	$('#contentd43').text($('#secD-input-bc-thirteen').val());

	if ($('#secD-input-bc-fourteen :selected').val() == "Select") {
		$("#contentd44").text('');
	} else {
		$("#contentd44").text($('#secD-input-bc-fourteen :selected').val());
	}

	$('#contentd45').text($('#secD-input-oc-fifteen').val());
	$('#contentd46').text($('#secD-input-oc-sixteen').val());
	$('#contentd47').text($('#secD-input-oc-seventeen').val());
	$('#contentd48').text($('#secD-input-oc-eighteen').val());
	// .........End of Section D .................

	// section E
	$("#content56").text($('#secE-input-one-a').val());		//suggestion
	$("#content50").text($('#secE-input-two').val());		// sig name
	$("#content51").text($('#secE-input-three').val());		// sig title
	$("#content53").text($('#secE-input-five').val());		// sig phone
	$("#content54").text($('#secE-input-six').val());		// sig email
	$("#content55").text($('#secE-input-four-a').val());	// sig ext
	// End of Section E

	// Access Code
	$("#contentAccCode").text($('#hiddenaccCode').val());

}

/** ******* CHECKBOX ********* */

// SecB - 8 -- Goal UC
$('input[type=checkbox].chkbox-eight').click(function() {
	$('#err-msg-eight').hide();
});

// Sec B - 12 -- type of info sender
$('input[type=checkbox].chkbox-twelve').click(function() {
	$('#err-msg-twelve').hide();
});

// Sec B - 13 - format info sender
$('input[type=checkbox].chkbox-thirteen').click(function() {
	$('#err-msg-thirteen').hide();
});

// Sec B -- 15 -- sender
$('input[type=checkbox].chkbox-fifteen').click(function() {
	$('#err-msg-fifteen').hide();
});

// Sec B - 16 -- category UC sender
$('input[type=checkbox].chkbox-sixteen').click(function() {
	$('#err-msg-sixteen').hide();
});

// Sec B - 20 -- type of info receiver
$('input[type=checkbox].chkbox-twenty').click(function() {
	$('#err-msg-twenty').hide();
});

// Sec B - 21 - format info receiver
$('input[type=checkbox].chkbox-twentyone').click(function() {
	$('#err-msg-twentyone').hide();
});

// Sec B -- 23 -- receiver
$('input[type=checkbox].chkbox-twentythree').click(function() {
	$('#err-msg-twentythree').hide();
});

// Sec B - 24 -- category UC receiver
$('input[type=checkbox].chkbox-twentyfour').click(function() {
	$('#err-msg-twentyfour').hide();
});

// Sec C - 35 - connecting provider
$('input[type=checkbox].chkbox-thirtyfive').click(function() {
	$('#err-msg-thirtyfive').hide();
});

// Sec D - Contact
$('input[type=checkbox].chkbox-contact').click(function() {
	$('#err-msg-contact').hide();
});

/** ******* RADIO ********* */

// SecC -- 34 -- onc certified
$("#radio-thirtyfour input:radio").click(function() {
	$('#err-msg-thirtyfour').hide();
});

// SecB - 26 - multiple information channels
$("#secB-input-twentysix input:radio").click(function() {
	$('#err-msg-twentysix').hide();
});

// SecB - 28 -- learning
//$("#secB-input-twentyeight input:radio").click(function() {
//	$('#err-msg-twentyeight').hide();
//});

// SecC -- 29 EMREHR
$("#radio-twentynine input:radio").click(function() {

	$('#secC-input-thirty').css("border-color", "");
	$('#secC-input-thirtyone').css("border-color", "");
	$('#secC-input-thirtytwo').css("border-color", "");
	$('#secC-input-thirtythree').css("border-color", "");

	$('#err-msg-twentynine').hide();
	$('#err-msg-thirty').hide();
	$('#err-msg-thirtyone').hide();
	$('#err-msg-thirtytwo').hide();
	$('#err-msg-thirtythree').hide();
	// $('#err-msg-secC-five').hide();
	$('#err-msg-thirtyfour').hide();

});

/** ******* HIDDEN TextBox (mostly check-box other / hl7) ********* */

// SecB - 8 - Other
$('#secB-input-eight-other').focus(function() {
	$('#secB-input-eight-other').css("border-color", "");
	$('#err-msg-eight-other').hide();
});

// SecB - 12 - Other
$('#secB-input-twelve-other').focus(function() {
	$('#secB-input-twelve-other').css("border-color", "");
	$('#err-msg-twelve-other').hide();
});

// SecB - 13 - hl7
$('#secB-input-thirteen-hl7').focus(function() {
	$('#secB-input-thirteen-hl7').css("border-color", "");
	$('#err-msg-thirteen-hl7').hide();
});

// SecB - 13 - Other
$('#secB-input-thirteen-other').focus(function() {
	$('#secB-input-thirteen-other').css("border-color", "");
	$('#err-msg-thirteen-other').hide();
});

// SecB - 16 - Other
$('#secB-input-sixteen-other').focus(function() {
	$('#secB-input-sixteen-other').css("border-color", "");
	$('#err-msg-sixteen-other').hide();
});

// SecB - 20 - Other
$('#secB-input-twenty-other').focus(function() {
	$('#secB-input-twenty-other').css("border-color", "");
	$('#err-msg-twenty-other').hide();
});

// SecB - 21 - hl7
$('#secB-input-twentyone-hl7').focus(function() {
	$('#secB-input-twentyone-hl7').css("border-color", "");
	$('#err-msg-twentyone-hl7').hide();
});

//SecB - 21 - other
$('#secB-input-twentyone-other').focus(function() {
	$('#secB-input-twentyone-other').css("border-color", "");
	$('#err-msg-twentyone-other').hide();
});

// SecB - 24 - Other
$('#secB-input-twentyfour-other').focus(function() {
	$('#secB-input-twentyfour-other').css("border-color", "");
	$('#err-msg-twentyfour-other').hide();
});

// SecB - 26 - Other method
$('#secB-input-twentysix-a').focus(function() {
	$('#secB-input-twentysix-a').css("border-color", "");
	$('#err-msg-twentysix-a').hide();
});

// SecC - 35 - Other
$('#secC-input-thirtyfive-other').focus(function() {
	$('#secC-input-thirtyfive-other').css("border-color", "");
	$('#err-msg-thirtyfive-other').hide();
});

/** ******* Length and Date ********* */

// SecA - 2 - Zipcode (length)
$('#secA-input-two-d').focus(function() {
	$('#secA-input-two-d').css("border-color", "");
	$('#err-length-two-d').hide();
});

// SecA - 3 - TaxID (length)
$('#secA-input-three').focus(function() {
	$('#secA-input-three').css("border-color", "");
	$('#err-length-three').hide();
});

// SecA - 4 - NPI (length)
$('#secA-input-four').focus(function() {
	$('#secA-input-four').css("border-color", "");
	$('#err-length-four').hide();
});

// SecB - 10 - Date - Sender
$('#secB-input-ten').focus(function() {
	$('#secB-input-ten').css("border-color", "");
	$('#err-date-ten').hide();
});

// SecB - 18 - Date - Receiver
$('#secB-input-eighteen').focus(function() {
	$('#secB-input-eighteen').css("border-color", "");
	$('#err-date-eighteen').hide();
});

// SecD - Contact (phone)
$('#secD-input-aa-four').focus(function() {
	$('#secD-input-aa-four').css("border-color", "");
	$('#err-length-aa-four').hide();
});

$('#secD-input-tc-eight').focus(function() {
	$('#secD-input-tc-eight').css("border-color", "");
	$('#err-length-tc-eight').hide();
});

$('#secD-input-bc-thirteen').focus(function() {
	$('#secD-input-bc-thirteen').css("border-color", "");
	$('#err-length-bc-thirteen').hide();
});

$('#secD-input-oc-eighteen').focus(function() {
	$('#secD-input-oc-eighteen').css("border-color", "");
	$('#err-length-oc-eighteen').hide();
});

// SecE - Signature work phone (length)
$('#secE-input-five').focus(function() {
	$('#secE-input-five').css("border-color", "");
	$('#err-length-secE-five').hide();
});

$('#btnValidate')
		.click(
				function() {

					var flag4length = false;
					var flagZipLength = false;
					var flagTINLength = false;
					var flagNPILength = false;

					/** **** RADIO **** */
					
					
					// SecB - 25 - 100% 
					 var val25 = $('#secB-input-twentyfive :selected').val();
					if (val25 != "100%") {
						// SecB - 26 - Radio check
						if (!$('input[name=secB-radio-twentysix]:checked').val()) {
							$('#err-msg-twentysix').show();
						}
					}

					// SecB - 28 - Radio check
//					if (!$('input[name=secB-radio-twentyeight]:checked').val()) {
//						$('#err-msg-twentyeight').show();
//					}

					// SecB - 29 - Radio check
					if (!$('input[name=secC-radio-twentynine]:checked').val()) {
						$('#err-msg-twentynine').show();
						$('#err-msg-thirtyfour').hide();
					}

					/** **** LENGTH **** */

					// Validate Zip Length (SecA-2d)
					len_zip = $('#secA-input-two-d').val();
					isValidZip = isValidNum(len_zip);
					if (len_zip.length == 5 && isValidZip) {
						$('#err-length-two-d').hide();
						flagZipLength = true;
					} else {
						$('#err-length-two-d').show();
						flagZipLength = false;
					}

					// Validate TIN Length (SecA-3)
					len2 = $('#secA-input-three').val();
					isValidTin = isValidNum(len2);
					if (len2.length == 9 && isValidTin) {
						$('#err-length-three').hide();
						flagTINLength = true;
					} else {
						$('#err-length-three').show();
						flagTINLength = false;
					}

					// Validate NPI Length (SecA-3)
					len3 = $('#secA-input-four').val();
					isValidNPI = isValidNum(len3);
					if (len3.length == 10 && isValidNPI) {
						$('#err-length-four').hide();
						flagNPILength = true;
					} else {
						$('#err-length-four').show();
						flagNPILength = false;
					}

					// Check all Length
					if (flagZipLength && flagTINLength && flagNPILength) {
						flag4length = true;
					} else {
						flag4length = false;
					}

					// Check for Sec A and B -- DROPDOWN
					var statusDropdownAandB = validateDropdownSecAandB();

					// Check for Sec A and B -- TEXTBOX
					var statusTextboxAandB = validateTextboxSecAandB();

					// Check for all Mandatory -- TEXTAREA
					var statusTextarea = validateTextarea();
					
					// Check for 8
					var statusChkbox8 = validateChkBox8();
					
					// Check for 12
					var statusChkbox12 = validateChkBox12();
					
					// Check for 13
					var statusChkbox13 = validateChkBox13();
					
					// Check for 15 and 23
					var statusChkbox15and23 = validateChkBox15and23();

					// Check for 16
					var statusChkbox16 = validateChkBox16();

					// Check for 20
					var statusChkbox20 = validateChkBox20();
				
					// Check for 21
					var statusChkbox21 = validateChkBox21();
					
					// Check for 24
					var statusChkbox24 = validateChkBox24();

					// Check for 26
					var statusRadio26 = validateRadioSecB26();

					// Check for 29 - 34
					var statusSecC = validateSecC29();

					// Check for 35
					var statusChkbox35 = validateChkBox35();
					
					// Check for 2 Mandatory SecD Contact
					var statusSecDTwoCheck = validateSecD();

					// Check for SecD Contact Fields
					var statusSecDFields = validateSecDFields();

					// Check for Sec E Signature Fields
					var statusSecEFields = validateSecEfields();
					
					if ((statusChkbox16 == 'true-undefined' || statusChkbox16 == 'true-true')
							&& (statusChkbox24 == 'true-undefined' || statusChkbox24 == 'true-true')
							&& (statusChkbox8 == 'true-undefined' || statusChkbox8 == 'true-true')
							&& (statusChkbox12 == 'true-undefined' || statusChkbox12 == 'true-true')
							&& (statusChkbox20 == 'true-undefined' || statusChkbox20 == 'true-true')
							&& (statusChkbox21 == 'true-undefined-undefined'
									|| statusChkbox21 == 'true-true-true'
									|| statusChkbox21 == 'true-true-undefined' || statusChkbox21 == 'true-undefined-true')
							&& (statusChkbox13 == 'true-undefined-undefined'
									|| statusChkbox13 == 'true-true-true'
									|| statusChkbox13 == 'true-true-undefined' || statusChkbox13 == 'true-undefined-true')
							&& statusSecC
							&& ((statusChkbox35 == 'true-undefined' || statusChkbox35 == 'true-true'))
							&& statusTextboxAandB
							&& statusTextarea
							&& statusSecDTwoCheck
							&& statusSecDFields
							&& statusSecEFields
							&& statusDropdownAandB
							&& statusChkbox15and23
							&& flag4length
							&& statusRadio26) {

						$('#previewerror').hide();

						$("#realForm").css("display", "none");
						$(".text-container").css("display", "none");

						// Call function to form content obj for preview
						preview_content();
						
						$("#content52").text($('#secE-input-four').val());		// date signed

						var data = {};
						data = form_data();

						$.ajax({
							url : "/attestation/Year/Year3and4/savedata",
							type : "POST",
							contentType : "application/json",
							data : JSON.stringify(data),
							dataType : 'json',
							cache : false,
							timeout : 600000,
							success : function(data) {
							},
							error : function(data) {
							}
						});

						$("#previewForm").css("display", "block");

					} else {
						$('#previewerror').show();

					}

				});

/* 8) -- uc goal -- checkbox */
function validateChkBox8() {

	var sList = "";
	var checkingforclicked = false;
	var secBhidden;

	// Loop thru all checkboxes
	// type0 is class id name for all checkboxes
	$('input[type=checkbox].chkbox-eight').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();

			// Check other text is not empty
			if (checkboxvalue == "Other (please specify)") {
				secBhidden = forSectionBhidden('#secB-input-eight-other');
			}

			checkingforclicked = true;
		}
	});

	if (checkingforclicked) {
		$('#err-msg-eight').hide();
	} else {
		$('#err-msg-eight').show();
	}

	return checkingforclicked + '-' + secBhidden;
}

/* 16) Checkbox sender */
function validateChkBox16() {

	var sList = "";
	var checkingforclicked = false;
	var secBhidden;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-sixteen').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();

			// Check other text is not empty
			if (checkboxvalue == "Other (please specify)") {
				secBhidden = forSectionBhidden('#secB-input-sixteen-other');
			}

			checkingforclicked = true;
		}
	});

	if (checkingforclicked) {
		$('#err-msg-sixteen').hide();
	} else {
		$('#err-msg-sixteen').show();
	}

	return checkingforclicked + '-' + secBhidden;
}

/* 24) Checkbox receiver */
function validateChkBox24() {

	var sList = "";
	var checkingforclicked = false;
	var secBhidden;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-twentyfour').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();

			// Check other text is not empty
			if (checkboxvalue == "Other (please specify)") {
				secBhidden = forSectionBhidden('#secB-input-twentyfour-other');
			}

			checkingforclicked = true;
		}
	});

	if (checkingforclicked) {
		$('#err-msg-twentyfour').hide();
	} else {
		$('#err-msg-twentyfour').show();
	}

	return checkingforclicked + '-' + secBhidden;
}

/* 12) -- type of info sender -- checkbox */
function validateChkBox12() {

	var sList = "";
	var secBhidden;
	var checkingforclicked = false;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-twelve').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();

			// Check other text is not empty
			if (checkboxvalue == "Other (please specify)") {
				secBhidden = forSectionBhidden('#secB-input-twelve-other');
			}

			checkingforclicked = true;
		}
	});

	if (checkingforclicked) {
		$('#err-msg-twelve').hide();
	} else {
		$('#err-msg-twelve').show();
	}

	return checkingforclicked + '-' + secBhidden;
}

/* 20) -- type of info receiver -- checkbox */
function validateChkBox20() {

	var sList = "";
	var secBhidden;
	var checkingforclicked = false;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-twenty').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();

			// Check other text is not empty
			if (checkboxvalue == "Other (please specify)") {
				secBhidden = forSectionBhidden('#secB-input-twenty-other');
			}

			checkingforclicked = true;
		}
	});

	if (checkingforclicked) {
		$('#err-msg-twenty').hide();
	} else {
		$('#err-msg-twenty').show();
	}

	return checkingforclicked + '-' + secBhidden;
}

/* 13) -- format of info -- sender checkbox */
function validateChkBox13() {

	var checkingforclicked = false
	var secBhidden0;
	var secBhidden1;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-thirteen').each(function() {
		if (this.checked) {

			var checkboxvalue = $(this).val();

			// Check HL7 text is not empty
			if (checkboxvalue == "HL7 message (specify type)") {
				secBhidden0 = forSectionBhidden('#secB-input-thirteen-hl7');
			}

			// Check other text is not empty
			if (checkboxvalue == "Other (please specify)") {
				secBhidden1 = forSectionBhidden('#secB-input-thirteen-other');
			}

			checkingforclicked = true;
		}
	});

	if (checkingforclicked) {
		$('#err-msg-thirteen').hide();
	} else {
		$('#err-msg-thirteen').show();
	}

	return checkingforclicked + '-' + secBhidden0 + '-' + secBhidden1;
}

/* 21) -- format of info reveiver -- checkbox */
function validateChkBox21() {

	var checkingforclicked = false
	var secBhidden0;
	var secBhidden1;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-twentyone')
			.each(
					function() {
						if (this.checked) {

							var checkboxvalue = $(this).val();

							// Check HL7 text is not empty
							if (checkboxvalue == "HL7 message (specify type)") {
								secBhidden0 = forSectionBhidden('#secB-input-twentyone-hl7');
							}

							// Check other text is not empty
							if (checkboxvalue == "Other (please specify)") {
								secBhidden1 = forSectionBhidden('#secB-input-twentyone-other');
							}

							checkingforclicked = true;
						}
					});

	if (checkingforclicked) {
		$('#err-msg-twentyone').hide();
	} else {
		$('#err-msg-twentyone').show();
	}

	return checkingforclicked + '-' + secBhidden0 + '-' + secBhidden1;
}

/* 35) -- connecting provider -- checkbox */
function validateChkBox35() {

	var checkingforclicked = false
	var secBhidden = true;

	// Loop thru all checkboxes
	$('input[type=checkbox].chkbox-thirtyfive')
			.each(
					function() {
						if (this.checked) {

							var checkboxvalue = $(this).val();

							// Check other text is not empty
							if (checkboxvalue == "Via some other method (please specify)") {
								secBhidden = forSectionChidden('#secC-input-thirtyfive-other');
							}
							checkingforclicked = true;
						}
					});

	if (checkingforclicked) {
		$('#err-msg-thirtyfive').hide();
	} else {
		$('#err-msg-thirtyfive').show();
	}

	return checkingforclicked + '-' + secBhidden;
}

/*
 * Generic function for all hidden text fields only for section B
 */
function forSectionBhidden(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
	});
	var avoid = "#secB-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}
}

/*
 * Generic function for all hidden text fields only for section C
 */
function forSectionChidden(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
	});
	var avoid = "#secC-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}
}

/* 15 and 23 -- sender / receiver -- Checkbox */
function validateChkBox15and23() {

	var checkingfor15 = false;
	var checkingfor23 = false;

	// chkbox-fifteen is class id name for sender
	$('input[type=checkbox].chkbox-fifteen').each(function() {
		if (this.checked) {
			checkingfor15 = true;
			$('#err-msg-fifteen').hide();
		} else {
			$('#err-msg-fifteen').show();
		}
	});

	// chkbox-twentythree is class id name for receiver
	$('input[type=checkbox].chkbox-twentythree').each(function() {
		if (this.checked) {
			checkingfor23 = true;
			$('#err-msg-twentythree').hide();
		} else {
			$('#err-msg-twentythree').show();
		}
	});

	if (checkingfor15 && checkingfor23) {
		return true;
	}else{
		return false;
	}
}

/* Sec A and B - All dropdowns SELECT */
function validateDropdownSecAandB() {

	var dropdowncheck = true;
	$('select').each(function(i, e) {
		switch ($(e).attr('id')) {
		case 'secA-input-four-a': // SecA-4a
			if (!dropdownforSectionA('#secA-input-four-a')) {
				dropdowncheck = false;
			}
			break;
		case 'secB-input-twentyfive': // SecB-25
			if (!dropdownforSectionB('#secB-input-twentyfive')) {
				dropdowncheck = false;
			}
			break;
		case 'secB-input-twentyseven': // SecB-27
			if (!dropdownforSectionB('#secB-input-twentyseven')) {
				dropdowncheck = false;
			}
			break;
		default:
			// Sec C and D dropdown will be ignored here. There is a seperate
			// section for C and D
		}
	});

	return dropdowncheck;
}

/* Sec A - Validate the dropdown is selected */
function dropdownforSectionA(idname) {

	var flag = false;
	var avoid = "#secA-input-";
	var section = idname.replace(avoid, '');

	$(idname).change(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
	});
	var val = $(idname).val();

	// Select is the default value - treat it as non-selected
	if (val == "Select") {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		flag = false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		flag = true;
	}

	return flag;
}

/* Sec B - Validate the dropdown is selected */
function dropdownforSectionB(idname) {

	var flag = false;
	var avoid = "#secB-input-";
	var section = idname.replace(avoid, '');

	$(idname).change(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
	});
	var val = $(idname).val();

	// Select is the default value - treat it as non-selected
	if (val == "Select") {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		flag = false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		flag = true;
	}

	return flag;

}

/* SecA and B Text areas */
function validateTextarea() {

	var textareacheck = true;
	$('textarea').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secA-input-seven': // SecA -- 7
			if (!forSectionA('#secA-input-seven')) {
				textareacheck = false;
			}
			break;
		case 'secB-input-fourteen': // SecB -- 14
			if (!forSectionB('#secB-input-fourteen')) {
				textareacheck = false;
			}
			break;
		case 'secB-input-fourteen-a': // SecB -- 14a
			if (!forSectionB('#secB-input-fourteen-a')) {
				textareacheck = false;
			}
			break;
		case 'secB-input-twentytwo': // SecB -- 22
			if (!forSectionB('#secB-input-twentytwo')) {
				textareacheck = false;
			}
			break;
		case 'secB-input-twentytwo-a': // SecB -- 22a
			if (!forSectionB('#secB-input-twentytwo-a')) {
				textareacheck = false;
			}
			break;
		default:
			// textarea which are optional will be ignored
		}
	});

	return textareacheck;
}

/* SecA and B Mandatory text box */
function validateTextboxSecAandB() {

	var check = true;

	$('input').each(function(i, e) {
		switch ($(e).attr('id')) {
		case 'secA-input-one': // SecA - 1
			if (!forSectionA('#secA-input-one')) {
				check = false;
			}
			break;
		case 'secA-input-two-a': // SecA -- 2a
			if (!forSectionA('#secA-input-two-a')) {
				check = false;
			}
			break;
		case 'secA-input-two-b': // SecA -- 2b
			if (!forSectionA('#secA-input-two-b')) {
				check = false;
			}
			break;
		case 'secA-input-two-c': // SecA -- 2c
			if (!forSectionA('#secA-input-two-c')) {
				check = false;
			}
			break;
		case 'secA-input-two-d': // SecA -- 2d
			if (!forSectionA('#secA-input-two-d')) {
				check = false;
			}
			break;
		case 'secA-input-three': // SecA -- 3
			if (!forSectionA('#secA-input-three')) {
				check = false;
			}
			break;
		case 'secA-input-four': // SecA -- 4
			if (!forSectionA('#secA-input-four')) {
				check = false;
			}
			break;
		case 'secA-input-five': // SecA -- 5
			if (!forSectionA('#secA-input-five')) {
				check = false;
			}
			break;
		case 'secB-input-nine': // SecB -- 9
			if (!forSectionB('#secB-input-nine')) {
				check = false;
			}
			break;
		case 'secB-input-ten': // SecB -- 10
			if (!forSectionB('#secB-input-ten')) {
				check = false;
			} else {
				var checkDate = isValidDate('#secB-input-ten');

				if (checkDate) {
					$('#secB-input-ten').css("border-color", "");
					$('#err-date-ten').hide();
				} else {
					$('#secB-input-ten').css("border-color", "#eb18f3");
					$('#err-date-ten').show();
					check = false;
				}
			}
			break;
		case 'secB-input-seventeen': // SecB -- 17
			if (!forSectionB('#secB-input-seventeen')) {
				check = false;
			}
			break;			
		case 'secB-input-eighteen': // SecB -- 18
			if (!forSectionB('#secB-input-eighteen')) {
				check = false;
			} else {
				var checkDate = isValidDate('#secB-input-eighteen');

				if (checkDate) {
					$('#secB-input-eighteen').css("border-color", "");
					$('#err-date-eighteen').hide();
				} else {
					$('#secB-input-eighteen').css("border-color", "#eb18f3");
					$('#err-date-eighteen').show();
					check = false;
				}
			}
			break;
		default:
			// Optional textbox is ignored
			// Sec C and D textbox will be ignored here
		}

	});

	return check;
}

/* Vailidate Sec A text to see if its empty */
function forSectionA(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
	});

	var avoid = "#secA-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}
}

/* Vailidate Sec B text to see if its empty */
function forSectionB(idname) {

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
	});

	var avoid = "#secB-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}
}

/* 16a) -- solely */
//function radioCheckingB0() {
//	return true;
//}

/* Sec B -- 26 */
function validateRadioSecB26() {

	var inputValue = $('input[name="secB-radio-twentysix"]:checked').val();

	var flagsectionB1 = false;
	if (inputValue == 'Yes') {
		var len = $('#secB-input-twentysix-a').val();

		if (len.length > 0) {
			flagsectionB1 = true;
			$('#err-msg-twentysix-a').hide();
		} else {
			flagsectionB1 = false;
			$('#err-msg-twentysix-a').show();
		}

		if (flagsectionB1) {
			return true;
		} else {
			return false;
		}

	} else if (inputValue == 'No') {
		$('#secB-input-twentysix-a').val('');
		return true;
	} else{
		// SecB - 25 - 100% 
		var val25 = $('#secB-input-twentyfive :selected').val();
		if (val25 == "100%") {
			return true;
		}else{
			$('#err-msg-twentysix').show();
			return false;
		}
	}
}

/* 18a) -- learning */
// function validateRadioSecB28() {
//
// if ($("input:radio[name='secB-radio-twentyeight']").is(":checked")) {
// return true;
// }
// return false;
// }



/* Sec C - 29 - top level Check */
function validateSecC29() {

	var inputValue = $('input[name="secC-radio-twentynine"]:checked').val();

	if (inputValue == 'Yes') {
		// textbox
		var textboxSecC = validateTextboxSecC();

		// dropdown
		var dropdownSecC = validateDropdownSecC();

		var radioSecC = true;
		// ONC Certified - radio
		if (!$('input[name=secC-radio-thirtyfour]:checked').val()) {
			radioSecC = false;
			$('#err-msg-thirtyfour').show();
		}

		if (textboxSecC && dropdownSecC && radioSecC) {
			return true;
		} else {
			return false;
		}
	} else if (inputValue == 'No') {
		$("#secC-input-thirtytwo").prop('selectedIndex', 0);
		$("#secC-input-thirtythree").prop('selectedIndex', 0);
		$('input[name="secC-radio-thirtyfour"]').prop('checked', false);
		$('#secC-input-thirty').val('');
		$('#secC-input-thirtyone').val('');

		return true;
	}
}

/* Sec C - textbox checking */
function validateTextboxSecC() {

	var label;
	var check = true;

	$('input[type=text].secC').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secC-input-thirty':
			if (!forSectionC('#secC-input-thirty')) {
				check = false;
			}
			break;
		case 'secC-input-thirtyone':
			if (!forSectionC('#secC-input-thirtyone')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Sec C - dropdown checking */
function validateDropdownSecC() {

	var dropdowncheck = true;
	$('select.secC').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secC-input-thirtytwo':
			if (!dropdownforSectionC('#secC-input-thirtytwo')) {
				dropdowncheck = false;
			}
			break;
		case 'secC-input-thirtythree':
			if (!dropdownforSectionC('#secC-input-thirtythree')) {
				dropdowncheck = false;
			}
			break;
		default:
			//return dropdowncheck;
		}
	});
	return dropdowncheck;
}

/* Validate dorpdown for sec C */
function dropdownforSectionC(idname) {

	var avoid = "#secC-input-";
	var section = idname.replace(avoid, '');

	$(idname).change(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();

	});

	var val = $(idname).val();

	if (val == "select") {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}

}

/* Vailidate Sec C text to see if its empty */
function forSectionC(idname) {

	var avoid = "#secC-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
	});

	if (lengthVal == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-' + section).hide();
		return true;
	}
}

/* validate Documentaion of market based ens initiative participation */

// function radioCheckingDocumentation() {
//
// var inputValue = $('input[name="secDoptradio"]:checked').val();
// var practiceType = $('#secA-input-seven-a :selected').val();
//
// if (practiceType == 'Acute Care Hospital') {
// if (inputValue == 'Yes') {
// $('#secD-inputD-two').val('');
// var secDoc = textBoxCheckingDocD();
// return secDoc;
// } else
// (inputValue == 'No')
// {
// $('#secD-inputD-three').val('');
// $('#secD-inputD-four').val('');
// var secDocTextArea = textAreaCheckingD();
// return secDocTextArea;
// }
// } else {
// return true;
// }
// }
//function textBoxCheckingDocD() {
//
//	var label;
//	var check = true;
//
//	$('input[type=text].SECDDOC').each(function(i, e) {
//
//		switch ($(e).attr('id')) {
//		case 'secD-inputD-three':
//			if (!forSectionDDOC('#secD-inputD-three')) {
//				check = false;
//			}
//			break;
//		case 'secD-inputD-four':
//			if (!forSectionDDOC('#secD-inputD-four')) {
//				check = false;
//			} else {
//				var checkDate = isValidDate('#secD-inputD-four');
//
//				if (checkDate) {
//					$('#secD-inputD-four').css("border-color", "");
//					$('#err-date-secDdoc-four').hide();
//				} else {
//					$('#secD-inputD-four').css("border-color", "#eb18f3");
//					$('#err-date-secDdoc-four').show();
//					check = false;
//				}
//			}
//			break;
//		default:
//			return check;
//		}
//	});
//
//	return check;
//}

/* Text areas */
//function textAreaCheckingD() {
//
//	var textareacheck = true;
//	$('textarea').each(function(i, e) {
//
//		switch ($(e).attr('id')) {
//		case 'secD-inputD-two':
//			if (!forSectionDDOC('#secD-inputD-two')) {
//				textareacheck = false;
//			}
//			break;
//		default:
//			// textarea which are optional will be ignored
//		}
//	});
//
//	return textareacheck;
//}

/* Vailidate Sec D Documentation text to see if its empty */
//function forSectionDDOC(idname) {
//
//	$(idname).focus(function() {
//		$(idname).css("border-color", "");
//		$('#err-msg-secDdoc-' + section).hide();
//	});
//
//	var avoid = "#secD-inputD-";
//	var section = idname.replace(avoid, '');
//	var lengthVal = $(idname).val();
//
//	if (lengthVal == 0) {
//		$(idname).css("border-color", "#eb18f3");
//		$('#err-msg-secDdoc-' + section).show();
//		this.focus();
//		return false;
//	} else {
//		$(idname).css("border-color", "");
//		$('#err-msg-secDdoc-' + section).hide();
//		return true;
//	}
//}

/* Check for at-least 2 checks */
function validateSecD() {

	var count = 0;
	$('input[type=checkbox].chkbox-contact').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();
			count = count + 1;
		}
	});

	if (count >= 2) {
		$('#err-msg-contact').hide();
		return true;
	} else {
		$('#err-msg-contact').show();
		return false;
	}

}

/* Check all Sec D fields based on selection */
function validateSecDFields() {
	var aaCheck = true;
	var tcCheck = true;
	var bcCheck = true;
	var ocCheck = true;
	var tcdropdownChk = true;
	var bcdropdownChk = true;

	$('input[type=checkbox].chkbox-contact').each(function() {
		if (this.checked) {
			var checkboxvalue = $(this).val();

			if (checkboxvalue == 'Access Administrator') {
				aaCheck = sectionDonLoadingAA();
			}

			if (checkboxvalue == 'Technical Contact') {
				tcCheck = sectionDonLoadingTC();
				tcdropdownChk = dropdownforSectionD('#secD-input-tc-nine');
			}

			if (checkboxvalue == 'Business Contact') {
				tcCheck = sectionDonLoadingBC();
				bcdropdownChk = dropdownforSectionD('#secD-input-bc-fourteen');
			}

			if (checkboxvalue == 'Other Contact') {
				tcCheck = sectionDonLoadingOC();
			}
		}
	});

	if (aaCheck == true && tcCheck == true && bcCheck == true
			&& ocCheck == true && tcdropdownChk == true
			&& bcdropdownChk == true) {
		return true;
	} else {
		return false;
	}
}

/* Sec D - AA */
function sectionDonLoadingAA() {
	var label;
	var check = true;

	$('input[type=text].secDaa').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secD-input-aa-one':
			if (!forSectionD('#secD-input-aa-one')) {
				check = false;
			}
			break;
		case 'secD-input-aa-two':
			if (!forSectionD('#secD-input-aa-two')) {
				check = false;
			}
			break;
		case 'secD-input-aa-three':
			if (!validationEmail('#secD-input-aa-three')) {
				check = false;
			}
			break;
		case 'secD-input-aa-four':
			if (!validationPhone('#secD-input-aa-four')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Sec D - TC */
function sectionDonLoadingTC() {
	var label;
	var check = true;

	$('input[type=text].secDtc').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secD-input-tc-five':
			if (!forSectionD('#secD-input-tc-five')) {
				check = false;
			}
			break;
		case 'secD-input-tc-six':
			if (!forSectionD('#secD-input-tc-six')) {

			}
			break;
		case 'secD-input-tc-seven':
			if (!validationEmail('#secD-input-tc-seven')) {
				check = false;
			}
			break;
		case 'secD-input-tc-eight':
			if (!validationPhone('#secD-input-tc-eight')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Sec D - BC */
function sectionDonLoadingBC() {
	var label;
	var check = true;

	$('input[type=text].secDbc').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secD-input-bc-ten':
			if (!forSectionD('#secD-input-bc-ten')) {
				check = false;
			}
			break;
		case 'secD-input-bc-eleven':
			if (!forSectionD('#secD-input-bc-eleven')) {
				check = false;
			}
			break;
		case 'secD-input-bc-twelve':
			if (!validationEmail('#secD-input-bc-twelve')) {
				check = false;
			}
			break;
		case 'secD-input-bc-thirteen':
			if (!validationPhone('#secD-input-bc-thirteen')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Sec D - OC */
function sectionDonLoadingOC() {
	var check = true;

	$('input[type=text].secDoc').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secD-input-oc-fifteen':
			if (!forSectionD('#secD-input-oc-fifteen')) {
				check = false;
			}
			break;
		case 'secD-input-oc-sixteen':
			if (!forSectionD('#secD-input-oc-sixteen')) {
				check = false;
			}
			break;
		case 'secD-input-oc-seventeen':
			if (!validationEmail('#secD-input-oc-seventeen')) {
				check = false;
			}
			break;
		case 'secD-input-oc-eighteen':
			if (!validationPhone('#secD-input-oc-eighteen')) {
				check = false;
			}
			break;
		default:
			return check;
		}
	});

	return check;
}

/* Vailidate Sec D text to see if its empty */
function forSectionD(idname) {

	var avoid = "#secD-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + section).hide();
	});

	if ($.trim(lengthVal).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + section).hide();
		return true;
	}
}

/* Sec D - Validate the dropdown is selected */
function dropdownforSectionD(idname) {

	var avoid = "#secD-input-";
	var section = idname.replace(avoid, '');

	// hide the top level validation error
	$(idname).change(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + section).hide();
	});

	var val = $(idname).val();

	if (val == "Select") {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + section).show();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + section).hide();
		return true;
	}
}

/* Sec E -- Signature */
function validateSecEfields() {
	var label;
	var check = true;

	$('input[type=text].secE').each(function(i, e) {

		switch ($(e).attr('id')) {
		case 'secE-input-two': // sig name
			if (!forSectionE('#secE-input-two')) {
				check = false;
			}
			break;
		case 'secE-input-three': // sig title
			if (!forSectionE('#secE-input-three')) {
				check = false;
			}
			break;
		case 'secE-input-five': // sig phone
			if (!validationPhoneE('#secE-input-five')) {
				check = false;
			}
			break;
		case 'secE-input-six': // email
			if (!validationEmailE('#secE-input-six')) {
				check = false;
			}
			break;
		default:
			// Optional fields are ignored
		}
	});

	return check;
}

/* Vailidate Sec E text to see if its empty */
function forSectionE(idname) {

	var avoid = "#secE-input-";
	var section = idname.replace(avoid, '');
	var lengthVal = $(idname).val();

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secE-' + section).hide();
	});

	if ($.trim(lengthVal).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secE-' + section).show();
		this.focus();
		return false;
	} else {
		$(idname).css("border-color", "");
		$('#err-msg-secE-' + section).hide();
		return true;
	}
}

function validationEmail(idname) {

	var avoid = "#secD-input-";
	var section = idname.replace(avoid, '');

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + section).hide();
		$('#err-msg-email-secD-' + section).hide();
	});

	var sEmail = $(idname).val();

	if ($.trim(sEmail).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + section).show();
		return false;
	} else if (validateEmail(sEmail)) {
		$(idname).css("border-color", "");
		return true;
	} else {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-email-secD-' + section).show();
		return false;
	}
}

function validationPhone(idname) {

	var avoid = "#secD-input-";
	var section = idname.replace(avoid, '');

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secD-' + section).hide();
		$('#err-length-secD-' + section).hide();
	});

	var sPhone = $(idname).val();

	if ($.trim(sPhone).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secD-' + section).show();
		return false;
	} else if (!isValidNum(sPhone)){
		$(idname).css("border-color", "#eb18f3");
		$('#err-length-secD-' + section).show();
		return false;
	} else if ($.trim(sPhone).length == 10) {
		$('#err-length-secD-' + section).hide();
		return true;
	} else {
		$(idname).css("border-color", "#eb18f3");
		$('#err-length-secD-' + section).show();
		return false;
	}

}

function validationEmailE(idname) {

	var avoid = "#secE-input-";
	var section = idname.replace(avoid, '');

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secE-' + section).hide();
		$('#err-msg-email-secE-' + section).hide();
	});
	var sEmail = $(idname).val();

	if ($.trim(sEmail).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secE-' + section).show();
		return false;
	} else if (validateEmail(sEmail)) {
		$(idname).css("border-color", "");
		return true;
	} else {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-email-secE-' + section).show();
		return false;
	}
}

function validationPhoneE(idname) {

	var avoid = "#secE-input-";
	var section = idname.replace(avoid, '');

	$(idname).focus(function() {
		$(idname).css("border-color", "");
		$('#err-msg-secE-' + section).hide();
		$('#err-length-secE-' + section).hide();
	});

	var sPhone = $(idname).val();

	if ($.trim(sPhone).length == 0) {
		$(idname).css("border-color", "#eb18f3");
		$('#err-msg-secE-' + section).show();
		return false;
	} else if (!isValidNum(sPhone)){
		$(idname).css("border-color", "#eb18f3");
		$('#err-length-secD-' + section).show();
		return false;
	} else if ($.trim(sPhone).length == 10) {
		$('#err-length-secE-' + section).hide();
		return true;
	} else {
		$(idname).css("border-color", "#eb18f3");
		$('#err-length-secE-' + section).show();
		return true;
	}
}

function validateEmail(sEmail) {
	var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if (filter.test(sEmail)) {
		return true;
	} else {
		return false;
	}
}

// Validates that the input string is a valid date formatted as "mm/dd/yyyy"
function isValidDate(idname) {
	var dateString = $(idname).val();

	// First check for the pattern
	if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString))
		return false;

	// Parse the date parts to integers
	var parts = dateString.split("/");
	var day = parseInt(parts[1], 10);
	var month = parseInt(parts[0], 10);
	var year = parseInt(parts[2], 10);

	// Check the ranges of month and year
	if (year < 1000 || year > 3000 || month == 0 || month > 12)
		return false;

	var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

	// Adjust for leap years
	if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
		monthLength[1] = 29;

	// Check the range of the day
	return day > 0 && day <= monthLength[month - 1];

}

// Validates that the input string is a valid Number
function isValidNum(numString) {
	var regex = /^\d+$/;
	
	// Check for the pattern
	if (!regex.test(numString))
		return false;

	return true;

}


function validatenumeric(evt, arg) {
	var id = arg.getAttribute('id');
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /[0-9\b]|\./;

	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}


function validatealphanumeric(evt, arg) {
	var id = arg.getAttribute('id');

	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /^[a-zA-Z0-9._ \b]+$/;

	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}
