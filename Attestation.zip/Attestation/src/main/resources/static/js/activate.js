$(document).ready(function() {
	$("#err-msg-one").hide();

	$("#accesscode").focus(function() {
		$("#err-msg-one").hide();
	});

	$("#accesscode").keydown(function() {
		$("#err-msg-one").hide();
	});

	$("#btnActivate").click(function() {
		var accCodeValue = $("#accesscode").val();

		var accCode_regex = /^[0-9]{6}[_][\w\W]+$/;

		if (accCodeValue.length == 0) {
			// $("#accesscode").focus();
			$("#err-msg-one").show();
			return false;
		} else if (!accCodeValue.match(accCode_regex)) {
			$("#accesscode").focus();
			$("#err-msg-one").show();

			return false;
		} else {
			return true;
		}

	});

});
