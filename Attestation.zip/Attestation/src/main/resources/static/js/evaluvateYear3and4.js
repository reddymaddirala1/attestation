$(document).ready(
		function() {

			// Section B - 8 -- ucgoal -- others
			$('#secB-table-eight #inlineCheckbox8-6').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-eight-other").css("display", "block");
				} else {
					$("#secB-hidden-eight-other").css("display", "none");
				}
			});

			// Section B - 16 -- category 2 -- others
			$('#secB-table-sixteen #inlineCheckbox16-23').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-sixteen-other").css("display", "block");
				} else {
					$("#secB-hidden-sixteen-other").css("display", "none");
				}
			});

			// Section B - 24 -- others
			$('#secB-table-twentyfour #inlineCheckbox24-23').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-twentyfour-other").css("display", "block");
				} else {
					$("#secB-hidden-twentyfour-other").css("display", "none");
				}
			});

			// Section B -- 20 --type of info -- others
			$('#secB-table-twenty #inlineCheckbox20-6').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-twenty-other").css("display", "block");
				} else {
					$("#secB-hidden-twenty-other").css("display", "none");
				}
			});

			// Section B - 12 -- others
			$('#secB-table-twelve #inlineCheckbox12-6').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-twelve-other").css("display", "block");
				} else {
					$("#secB-hidden-twelve-other").css("display", "none");
				}
			});

			// Section B -- 13 -- format of info -- hl7
			$('#secB-table-thirteen #inlineCheckbox13-5').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-thirteen-hl7").css("display", "block");
				} else {
					$("#secB-hidden-thirteen-hl7").css("display", "none");
				}

			});

			// Section B -- 13 -- format of info -- other
			$('#secB-table-thirteen #inlineCheckbox13-6').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-thirteen-other").css("display", "block");
				} else {
					$("#secB-hidden-thirteen-other").css("display", "none");
				}

			});

			// Section B -- 21 -- hl7
			$('#secB-table-twentyone #inlineCheckbox21-5').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-twentyone-hl7").css("display", "block");
				} else {
					$("#secB-hidden-twentyone-hl7").css("display", "none");
				}
			});

			// Section B -- 21 -- other
			$('#secB-table-twentyone #inlineCheckbox21-6').change(function() {
				if ($(this).prop("checked")) {
					$("#secB-hidden-twentyone-other").css("display", "block");
				} else {
					$("#secB-hidden-twentyone-other").css("display", "none");
				}
			});

			// Section B -- 26 -- OtherMethod -- Yes No
			$('input[type="radio"][name="secB-radio-twentysix"]').click(
					function() {

						var inputValue = $(
								'input[name="secB-radio-twentysix"]:checked')
								.val();

						if (inputValue == 'Yes') {
							$("#reveal-twentysix-yes").css("display", "block");
							$('#err-msg-twentysix-a').hide();
						} else if (inputValue == 'No') {
							$('#secB-input-twentysix-a').val('');
							$("#reveal-twentysix-yes").css("display", "none");
						}
					})

			// Section C -- 29 -- EHREMR - Yes No
			$('input[type="radio"][name="secC-radio-twentynine"]').click(
					function() {

						var inputValue = $(
								'input[name="secC-radio-twentynine"]:checked')
								.val();

						if (inputValue == 'Yes') {

							$("#reveal-twentynine-yes").css("display", "block");
							$("#reveal-twentynine-yesandno").css("display", "block");

							flagsectionc = true;

						} else if (inputValue == 'No') {

							$("#reveal-twentynine-yes").css("display", "none");
							$("#reveal-twentynine-yesandno").css("display", "block");

							$("#secC-input-thirtytwo").prop('selectedIndex', 0);
							$("#secC-input-thirtythree").prop('selectedIndex', 0);
							$('input[name="secC-radio-thirtyfour"]').prop('checked',
									false);
							$('#secC-input-thirty').val('');
							$('#secC-input-thirtyone').val('');
							
							flagsectionc = false;

						}

						if (flagsectionc) {
							$("#sectionctrue").css("display", "block");
							$("#sectioncfalse").css("display", "block");
						} else {
							$("#sectioncfalse").css("display", "block");
							$("#sectionctrue").css("display", "none");
						}
					})

//			$('#secA-input-four-a').change(function() {
//				var practiceType = $('#secA-input-four-a :selected').val();
//				// var inputValueD =
//				// $('input[name="secDoptradio"]:checked').val();
//
//				if (practiceType == 'Acute Care Hospital') {
//					$("#revealmain").css("display", "block");
//					$('input[name="secDoptradio"]').prop('checked', false);
//					$('#err-msg-secDdoc-one').hide();
//					/*
//					 * if (inputValueD == 'Yes') {
//					 * $("#revealD37a").css("display", "none");
//					 * $("#revealD38").css("display", "block"); } else if
//					 * (inputValueD == 'No') { $("#revealD37a").css("display",
//					 * "block"); $("#revealD38").css("display", "none"); }
//					 */
//				} else {
//					$("#revealmain").css("display", "none");
//					$("#revealD37a").css("display", "none");
//					$("#revealD38").css("display", "none");
//					$('#secD-inputD-two').val('');
//					$('#secD-inputD-three').val('');
//					$('#secD-inputD-four').val('');
//					$('input[name="secDoptradio"]').prop('checked', false);
//				}
//
//			})

			// Section D: Documentation of Market-based ENS Initiative
			// Participation
			// $('input[type="radio"][name="secDoptradio"]').click(function()
			// {
			//
			// var inputValue = $('input[name="secDoptradio"]:checked').val();
			//
			// if (inputValue == 'Yes') {
			//
			//			
			// $("#revealD37a").css("display", "none");
			// $("#revealD38").css("display", "block");
			//			
			//		
			// $('#secD-inputD-two').val('');
			//			
			// flagsectionc = true;
			//
			// } else if (inputValue == 'No') {
			//
			// $("#revealD37a").css("display", "block");
			// $("#revealD38").css("display", "none");
			//			
			//			
			// // $("#secC-input-four").prop('selectedIndex', 0);
			// //$("#secC-input-fourr").prop('selectedIndex', 0);
			// //$('input[name="secC1optradio"]').prop('checked', false);
			//
			// $('#secD-inputD-three').val('');
			// $('#secD-inputD-four').val('');
			// flagsectionc = false;
			//
			// }
			//
			// if (flagsectionc) {
			//
			// $("#sectionddoctrue").css("display", "block");
			// $("#sectionddocfalse").css("display", "none");
			//
			// } else {
			//
			// $("#sectionddocfalse").css("display", "block");
			// $("#sectionddoctrue").css("display", "none");
			//
			// }
			//
			// })

			// Section C -- 35 -- connecting provider -- other
			$('#secC-table-thirtyfive #inlineCheckbox35-2').change(function() {
				if ($(this).prop("checked")) {
					$("#secC-hidden-thirtyfive-other").css("display", "block");
				} else {
					$("#secC-hidden-thirtyfive-other").css("display", "none");
					$("#secC-input-thirtyfive-other").css("border-color", "");
					$('#err-msg-thirtyfive-other').hide();
					$("#secC-hidden-thirtyfive-other").val('');
				}
			});

			// 25 and 26
			$('#secB-input-twentyfive').change(function() {
				$('#err-msg-twentyfive').hide();
				 var val25 = $('#secB-input-twentyfive :selected').val();
				if (val25 == "100%") {
					$('#err-msg-twentysix').hide();
				}
			})


//			$('#secB-input-twentyfive').change(function() {
//
//				$('input[name="secBoptradio-0"]').prop('checked', false);
//
//				if (this.selectedIndex == "3" || this.selectedIndex == "0") {
//					$("#secBinputhidden4new").css("display", "none");
//				} else {
//					$("#secBinputhidden4new").css("display", "block");
//				}
//			})

			$('#secD-table-contact #inlineCheckboxsecDaa').change(function() {
				$('#err-msg-contact').hide();

				if ($(this).prop("checked")) {
					$("#secDaahiddenblock").css("display", "block");
				} else {
					$("#secDaahiddenblock").css("display", "none");

					$("#secD-input-aa-one").css("border-color", "");
					$('#err-msg-secD-aa-one').hide();
					$("#secD-input-aa-one").val('');

					$("#secD-input-aa-two").css("border-color", "");
					$('#err-msg-secD-aa-two').hide();
					$("#secD-input-aa-two").val('');

					$("#secD-input-aa-three").css("border-color", "");
					$('#err-msg-secD-aa-three').hide();
					$('#err-msg-email-secD-aa-three').hide();
					$("#secD-input-aa-three").val('');

					$("#secD-input-aa-four").css("border-color", "");
					$('#err-msg-secD-aa-four').hide();
					$('#err-length-aa-four').hide();
					$("#secD-input-aa-four").val('');
				}
			});

			$('#secD-table-contact #inlineCheckboxsecDtc').change(function() {
				$('#err-msg-contact').hide();

				if ($(this).prop("checked")) {
					$("#secDtchiddenblock").css("display", "block");
				} else {
					$("#secDtchiddenblock").css("display", "none");

					$("#secD-input-tc-five").css("border-color", "");
					$('#err-msg-secD-tc-five').hide();
					$("#secD-input-tc-five").val('');

					$("#secD-input-tc-six").css("border-color", "");
					$('#err-msg-secD-tc-six').hide();
					$("#secD-input-tc-six").val('');

					$("#secD-input-tc-seven").css("border-color", "");
					$('#err-msg-secD-tc-seven').hide();
					$('#err-msg-email-secD-tc-seven').hide();
					$("#secD-input-tc-seven").val('');

					$("#secD-input-tc-eight").css("border-color", "");
					$('#err-msg-secD-tc-eight').hide();
					$('#err-length-tc-eight').hide();
					$("#secD-input-tc-eight").val('');

					$("#secD-input-tc-nine").css("border-color", "");
					$('#err-msg-secD-tc-nine').hide();
					$("#secD-input-tc-nine").val('Select');
				}
			});

			$('#secD-table-contact #inlineCheckboxsecDbc').change(function() {
				$('#err-msg-contact').hide();

				if ($(this).prop("checked")) {
					$("#secDbchiddenblock").css("display", "block");
				} else {
					$("#secDbchiddenblock").css("display", "none");

					$("#secD-input-bc-ten").css("border-color", "");
					$('#err-msg-secD-bc-ten').hide();
					$("#secD-input-bc-ten").val('');

					$("#secD-input-bc-eleven").css("border-color", "");
					$('#err-msg-secD-bc-eleven').hide();
					$("#secD-input-bc-eleven").val('');

					$("#secD-input-bc-twelve").css("border-color", "");
					$('#err-msg-secD-bc-twelve').hide();
					$('#err-msg-email-secD-bc-twelve').hide();
					$("#secD-input-bc-twelve").val('');

					$("#secD-input-bc-thirteen").css("border-color", "");
					$('#err-msg-secD-bc-thirteen').hide();
					$('#err-length-bc-thirteen').hide();
					$("#secD-input-bc-thirteen").val('');

					$("#secD-input-bc-fourteen").css("border-color", "");
					$('#err-msg-secD-bc-fourteen').hide();
					$("#secD-input-cb-fourteen").val('Select');
				}
			});

			$('#secD-table-contact #inlineCheckboxsecDoc').change(function() {
				$('#err-msg-contact').hide();

				if ($(this).prop("checked")) {
					$("#secDochiddenblock").css("display", "block");
				} else {
					$("#secDochiddenblock").css("display", "none");

					$("#secD-input-oc-fifteen").css("border-color", "");
					$('#err-msg-secD-oc-fifteen').hide();
					$("#secD-input-oc-fifteen").val('');

					$("#secD-input-oc-sixteen").css("border-color", "");
					$('#err-msg-secD-oc-sixteen').hide();
					$("#secD-input-oc-sixteen").val('');

					$("#secD-input-oc-seventeen").css("border-color", "");
					$('#err-msg-secD-oc-seventeen').hide();
					$('#err-msg-email-secD-oc-seventeen').hide();
					$("#secD-input-oc-seventeen").val('');

					$("#secD-input-oc-eighteen").css("border-color", "");
					$('#err-msg-secD-oc-eighteen').hide();
					$('#err-length-oc-eighteen').hide();
					$("#secD-input-oc-eighteen").val('');
				}
			});

			// Section E checkbox to toggle
			$('#sigIsChecked').click(
					function() {
						if ($(this).prop("checked")) {
							$("#show").css("display", "block");
							$(':input[type="button"][name="btnValidate"]')
									.prop('disabled', false);
						} else {
							$("#show").css("display", "none");
							$(':input[type="button"][name="btnValidate"]')
									.prop('disabled', true);
						}
						// $("#show").toggle(this.checked);
					});

			// $('#inlineCheckbox1,#inlineCheckbox2,#inlineCheckbox3,#inlineCheckbox4,#inlineCheckbox5')
			// .click(function() {
			// });

			// $('#secC-input-five').on('change', function() {
			// if (this.selectedIndex == "2") {
			// $("#secEtexthidden").css("display", "block");
			// } else {
			// $('#secC-input-six').val('');
			// $("#secEtexthidden").css("display", "none");
			// }
			// })

			// $('#secD-input-five').on('change', function() {
			// if (this.selectedIndex == "4") {
			// $("#secDtexthidden1").css("display", "block");
			// } else {
			// $('#secD-input-six').val('');
			// $("#secDtexthidden1").css("display", "none");
			// }
			// })
			//
			// $('#secD-input-eleven').on('change', function() {
			// if (this.selectedIndex == "4") {
			// $("#secDtexthidden2").css("display", "block");
			// } else {
			// $('#secD-input-twelve').val('');
			// $("#secDtexthidden2").css("display", "none");
			// }
			// })
			//
			// $('#secD-input-seventeen').on('change', function() {
			// if (this.selectedIndex == "4") {
			// $("#secDtexthidden3").css("display", "block");
			// } else {
			// $('#secD-input-eighteen').val('');
			// $("#secDtexthidden3").css("display", "none");
			// }
			// })
		});
