$(document).ready(function() {
	var TrueFunc = function(element, renderer) {
		return true
	};

	var specialElementHandlers = {
		'#editor' : TrueFunc,
		'#myModal' : TrueFunc
	};

	$("#btnSubmit").click(function(e) {

		e.preventDefault();
		$(':input[type="button"][name="btnSubmit"]').prop('value', 'Submitting');
		$(':input[type="button"][name="btnSubmit"]').prop('disabled', true);
		
		var data = {};

		data = form_data();
			
		data["submitionflag"] = 'Submitted';

		$.ajax({

			url : "/attestation/Year/Year5/insertmasterdata",
			type : "POST",
			contentType : "application/json",
			data : JSON.stringify(data),
			dataType : 'json',
			success : function(data) {

				$('#myModal').modal('show');
				$('#myModal').click(function() {

					var x = location.protocol;

					if (x == 'https:') {
						location.protocol = location.protocol.replace('https:', 'http:');
						window.location = "https://www.masshiway.net/";
					} else {
						window.location = "https://www.masshiway.net/";
					}
				});
			},
			error : function(data) {
				alert("Error");
			}
		});
	});
});
