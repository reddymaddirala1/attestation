$('input')
		.each(
				function(i, e) {

					var label;

					switch ($(e).attr('id')) {
						case 'secA-input-one':
							label = 'Example : George Washington Hospital';
							break;
						case 'secA-input-two-a':
							label = 'Number and Street Name';
							break;
						case 'secA-input-two-b':
							label = 'City of the Provider Organization';
							break;
						case 'secA-input-two-c':
							label = 'Default set as MA';
							break;
						case 'secA-input-two-d':
							label = '5 digits zip code eg. 12345';
							break;
						case 'secA-input-three':
							label = '9 digit Tax ID / TIN as eg. 999999999';
							break;
						case 'secA-input-four':
							label = '10 digits Organization NPI ';
							break;
						case 'secA-input-five':
							label = 'This is the part of the Direct address to the right of the @ sign, such as "direct.orgname.masshiway.net" or "1234.direct.hispname.com"). Either a Mass HIway or HISP address is acceptable. Please send all domain names currently in use by the Provider Organization. Please use ; when entering multiple domain(s)';
							break;
						case 'secA-input-six':
							label = 'Example : George Washington Hospital';
							break;
							
						// Section B
						case 'secB-input-nine':
							label = 'Example: Transmission of hospital discharge summaries to Primary Care Practice X';
							break;
						case 'secB-input-ten':
							label = 'Example : 03/20/2020 (MM/DD/YYYY)';
							break;
						case 'secB-input-seventeen':
							label = 'Example: Transmission of hospital discharge summaries to Primary Care Practice X';
							break;
						case 'secB-input-eighteen':
							label = 'Example : 03/20/2020 (MM/DD/YYYY)';
							break;
							
						// Section C
						case 'secC-input-thirty':
							label = 'Name of EMR / EHR System';
							break;
						case 'secC-input-thirtyone':
							label = 'Version of EMR / EHR System';
							break;
	
	
						// Section E
	
						case 'secE-input-two':
							label = 'Authorized person First  and Last Name';
							break;
						case 'secE-input-three':
							label = 'Authorized person Title';
	
							break;
						case 'secE-input-four':
							label = 'Authorized person Signed Date';
	
							break;
						case 'secE-input-five':
							label = 'Authorized person phone number';
	
							break;
						case 'secE-input-six':
							label = 'Authorized person email address';
							break;
					}
					$(e).tooltip({
						'trigger' : 'focus',
						'title' : label
					});
				});
