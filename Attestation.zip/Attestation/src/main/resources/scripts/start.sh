#!/bin/sh

nohup java -jar /webapps/attestation/hie-attestation.jar >/dev/null 2>&1 &
