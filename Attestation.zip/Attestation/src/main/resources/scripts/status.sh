#!/bin/bash

URL="http://localhost:7012/manage/health"
USER="admin"
PASS="secret"

######
result="curl -u $USER:$PASS -i -H 'Accept:application/json' -k $URL"
echo $result

response=`$result`
echo $response

######
