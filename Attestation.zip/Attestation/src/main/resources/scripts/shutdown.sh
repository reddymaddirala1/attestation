#!/bin/bash

URL="https://localhost:7012/manage/shutdown"
USER="admin"
PASS="monitor"

#####
result="curl -u $USER:$PASS -i -H 'Accept:application/json' -k -X POST $URL"
echo $result

response=`$result`
echo $response
#####
