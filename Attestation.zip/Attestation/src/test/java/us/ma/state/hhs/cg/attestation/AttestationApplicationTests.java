package us.ma.state.hhs.cg.attestation;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AttestationApplicationTests {

	@Test
	public void contextLoads() {
	}

}

